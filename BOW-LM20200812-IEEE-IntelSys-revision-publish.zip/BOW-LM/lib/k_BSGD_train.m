function [model output]= k_BSGD_train(X,Y,model)  

st = cputime;
n = length(Y);   % number of training samples

if isfield(model,'iter')==0
    model.iter=0;
    model.iternum=0;
    model.alpha=[];
    model.errTot=0;
    model.numSV=zeros(numel(Y),1);
    model.aer=zeros(numel(Y),1);
    model.pred=zeros(numel(Y),1);
    model.eta=1;
    model.gamma=1;
    model.lambda=1/numel(Y)^2;
end


for i=1:n
    model.iter=model.iter+1;
     
    if numel(model.S)>0
        if isempty(model.ker)
            K_f=X(model.S,i);
        else
            K_f=feval(model.ker,model.SV,X(:,i),model.kerparam);
                     
        end
        val_f=model.alpha.*Y(model.S)*K_f;

    else
        val_f=0;
    end

    Yi=Y(i);
    model.errTot=model.errTot+(sign(val_f)~=Yi);
    model.aer(model.iter)=model.errTot/model.iter;

    model.pred(model.iter)=val_f;
    
    if Yi*val_f<1
         model.iternum=model.iternum+1;
        if numel(model.S)==model.maxSV
            sample=unifrnd(0,1,1,length(model.S));
            mn_idx=find(min(model.alpha));
            model.alpha=((1-model.lambda*model.eta)./(1-sample)).*model.alpha;
            model.alpha=sort([model.alpha; model.gamma*model.eta*ones(1,length(model.alpha))],1);
            model.alpha=model.alpha(1,:);            
            model.alpha(mn_idx)=model.eta;
            
            model.S(mn_idx)=model.iter;
            if ~isempty(model.ker)
                model.SV(:,mn_idx)=X(:,i);
            end
            
        else
            model.alpha(end+1)=model.eta;
            model.S(end+1)=model.iter;
            model.SV(:,end+1)=X(:,i);
        end

    else   %%  Yi*val_f>=1
           model.alpha=(1-model.lambda*model.eta)*model.alpha;
        
    end

   model.numSV(model.iter)=numel(model.S);
    
    if mod(i,model.step)==0
%       fprintf('#%.0f SV:%5.2f(%d)\tAER:%5.2f\n', ...
%             ceil(i/1000),numel(model.S)/model.iter*100,numel(model.S),model.aer(model.iter)*100);
    end    
end
  model.YY=Y(model.S);
 sgnoutput = sign(model.pred);
 
   TP=0;
   TN=0;
   FP=0;
   FN=0;
   %%%%%%
    for ii=model.maxSV+1:length(Y)
       if sgnoutput(ii)==1& Y(ii) == 1
           TP=TP+1;
       elseif sgnoutput(ii)==-1& Y(ii) == -1
           TN=TN+1;
       elseif sgnoutput(ii)==1& Y(ii) == -1
           FP=FP+1;
       elseif sgnoutput(ii)==-1& Y(ii) == 1
           FN=FN+1;
       end
       model.aer(ii)=[sqrt((TP*TN)/((TP+FN)*(TN+FP)))];
    end
 
   

   model.G=model.aer(n)*100;
model.time = cputime - st;
output=model.pred;
