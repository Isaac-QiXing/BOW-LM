function [model output]= k_LSSVM_train(X,Y,model)  
% banquet chunk update LS-SVM  --- Similarity criteria
%
% Argument Inputs
%         X: inputs of samples
%         Y: output of samples
%         model: a structure
%          
% Output
%        model.acc:  correct classification rate for classifcation
%        model.time: runing time
% versions
%   * 2020.2 
%       fix a bug of the initialization of model.S   
  
%%%%%%%%%%% Macro definition

if isfield(model,'iter')==0
    model.iter=0;
    model.pred=[];    
end

if isfield(model,'type')==0
    model.type=1;
end
if isfield(model,'nu')==0
    model.nu=1;
end
if isfield(model,'block')==0  % block is the chunk size
    model.block=10;
end
if ~isfield(model,'maxSV') || isempty(model.maxSV)
    model.maxSV = 100;
end
st = cputime; 

n_sample = size(X,2); % number of samples
model.maxSV= min( ceil(n_sample/3),model.maxSV);

model.S = [1:model.maxSV];
model.SV = X(:,model.S); 

K_f = feval(model.ker,model.SV,model.SV,model.kerparam);

A_old = [K_f+model.nu*eye(model.maxSV) ones(model.maxSV,1);  ones(1,model.maxSV) 0];
% initial saddle point matrix
B_old = [Y(model.S);0]; % initial right column vector
inv_A_old = pinv(A_old);
QRE = sum(K_f,2);   %  compute the quadratic renyi entropy

model.alphab = inv_A_old*B_old;
model.pred = [K_f ones(model.maxSV,1)]*model.alphab;  % prediction outputs
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%  predict  procedure %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  for n = model.maxSV+1 : model.block : length(Y)
      
         
    if (n+model.block) > length(Y)
        X_temp = X(:,n:length(Y));    Y_temp = Y(n:length(Y));
        model.block = size(X_temp,2);      %%%% correct the block size
   else
        index_temp = n:(n+model.block-1);
        X_temp = X(:,n:(n+model.block-1));    Y_temp = Y(n:(n+model.block-1));
    end
    
    K_f_temp = feval(model.ker,X_temp,model.SV,model.kerparam);
    output_temp = [K_f_temp ones(model.block,1)]*model.alphab;
    model.pred = [model.pred; output_temp];
    
    addin_index = index_temp(sign(output_temp)~=Y_temp); % the index of new chunk samples
    if ~isempty(addin_index)
        model.iter = model.iter+1;   % iteration BOLSSVM one time
        addin_num = length(addin_index);
        X_in = X(:,addin_index);
        KernelColumn_in = feval(model.ker,X_in,model.SV,model.kerparam);
        U = zeros(model.maxSV+1,addin_num);
        [a old_index] = sort(QRE);
  
    out = old_index(1:addin_num);
    out_index = model.S(out); % the numbers of out samples
    X_out = X(:,out_index);
    
    KernelColumn_out =  feval(model.ker,X_out,model.SV,model.kerparam);%%    
    V = KernelColumn_in - KernelColumn_out;%%%    
    
    
    for ii = 1:addin_num
       U(old_index(ii),ii) = 1;               %%%
       V(ii,old_index(ii)) = (feval(model.ker,X_in(:,ii),X_in(:,ii),model.kerparam) - feval(model.ker,X_out(:,ii),X_out(:,ii),model.kerparam))/2;%%%
       model.S(old_index(ii)) = addin_index(ii);% update the SV index    
       aa = sum(KernelColumn_in,2);
       QRE(ii) = aa(ii);
    end
    V = [V'; zeros(1,addin_num)];
    UU = inv_A_old*U;
    inv_Q = inv_A_old - UU*pinv(eye(addin_num)+V'*UU)*V'*inv_A_old;% compute inv_Q  
    VV = inv_Q*V;
    inv_A_old = inv_Q - VV*pinv(eye(addin_num)+U'*VV)*U'*inv_Q;% compute inv_Q 
    B_old = [Y(model.S);0];
    model.SV = X(:,model.S); 
    model.alphab = inv_A_old*B_old;
    end
      
  end
  
 sgnoutput = sign(model.pred);
 
   TP=0;
   TN=0;
   FP=0;
   FN=0;
   %%%%%%
    for ii=model.maxSV+1:length(Y)
       if sgnoutput(ii)==1&& Y(ii) == 1
           TP=TP+1;
       elseif sgnoutput(ii)==-1&& Y(ii) == -1
           TN=TN+1;
       elseif sgnoutput(ii)==1&& Y(ii) == -1
           FP=FP+1;
       elseif sgnoutput(ii)==-1&& Y(ii) == 1
           FN=FN+1;
       end
       model.aer(ii)=sqrt((TP*TN)/((TP+FN)*(TN+FP)));

    end
 
   

   model.G=model.aer(end)*100;

     
   model.time = cputime - st;
   output=model.pred;