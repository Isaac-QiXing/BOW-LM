function model = k_BWOSELM2_train(X,Y,model)
  
% Rank-k updating Online training algorithm of prune mechanism
% Argument Inputs
%         X: inputs of samples
%         Y: output of samples
%         Type: 0 for regression; 1 for classification
%         kernelName: kernel name, such as 'gaussian','poly', 'lin', or 'laplacian'
%         para: kernel parameter 
%         nu:  tradeoff parameter for LS-SVM, nu=1/C
%         N0: Number of initial training data, i.e. the scale of work set
%         Block: Size of block of data learned in each step, i.e. chunk's scale
%          
% Output
%        Accuracy: RMSE for regression or correct classification rate for classifcation
%        time: cpu runing time

%%%%%%%%%%% Macro definition

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%  predict  procedure %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 

% Argument Inputs
%         X: inputs of samples
%         Y: output of samples
%         model: a structure
%          
% Output
%        model.acc:  correct classification rate for classifcation
%        model.time: runing time

%%%%%%%%%%% Macro definition
if isfield(model,'iter')==0
    model.iter=0;
    model.pred=[];
end
if isfield(model,'type')==0
    model.type=1;
end
if isfield(model,'nu')==0
    model.nu=1;
end
if isfield(model,'block')==0  % block can be modify(10)
    model.block=5;
end
if isfield(model,'para')==0  % para
    model.para=50;
end
if isfield(model,'IW')==0  % para
    model.IW=[];
end
if isfield(model,' Bias')==0  % para
    model. Bias=0;
end
if isfield(model,' G')==0  %G-means
    model. G=0;
end

st = cputime; 

[TotalNum InputDim] = size(X);
nHiddenNeurons =model.para; 
ActivationFunction = 'sig'; 
error=0;
st = cputime;
active_index= [1:model.maxSV];
model.S = [1:model.maxSV];
model.SV = X(model.S,:); 

X_active =  X(model.S,:); 
Y_active =  Y(model.S,:);
%%%%%%%%%%%%%%%%%%%%  weighted W
num_P=length(find(Y_active==1));
num_N=length(find(Y_active==-1));
w=[];
for u=1:length(Y_active)
    if Y_active(u)==1
        w(u)=1/num_P;
    else
        w(u)=1/num_N;
    end
    W0=diag(w);
end
%%%%%%%%%%%%%%%%%%%%

model.IW = rand(nHiddenNeurons,InputDim)*2-1;

switch lower(ActivationFunction)
    case{'rbf'}
        model.Bias = rand(1,nHiddenNeurons);
        H0 = RBFun(X_active,model.IW ,model.Bias);
    case{'sig'}
       model.Bias = rand(1,nHiddenNeurons)*2-1;
        H0= SigActFun(X_active,model.IW ,model.Bias);
    case{'sin'}
        model.Bias = rand(1,nHiddenNeurons)*2-1;
        H0 = SinActFun(X_active,model.IW ,model.Bias);
    case{'hardlim'}
        model.Bias = rand(1,nHiddenNeurons)*2-1;
        H0 = HardlimActFun(X_active,model.IW ,model.Bias);
       H0 = double(H0);
end

M = pinv(H0'*W0*H0+eye(size(H0'*W0*H0))/2^20);
model.alphab =M*H0'*W0* Y_active;
model.pred = Y_active; 

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%  predict  procedure %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  for n = model.maxSV+1 : model.block : length(Y)
      
         
    if (n+model.block) > length(Y)
        X_temp = X(n:length(Y),:);    Y_temp = Y(n:length(Y));
        model.block = size(X_temp,2);      %%%% correct the block size
   else
        index_temp = n:(n+model.block-1);
        X_temp = X(n:(n+model.block-1),:);    Y_temp = Y(n:(n+model.block-1));
    end
    
    switch lower(ActivationFunction)
        case{'rbf'}
            H = RBFun(X_temp,model.IW,model.Bias);
        case{'sig'}
            H = SigActFun(X_temp,model.IW,model.Bias);
        case{'sin'}
            H = SinActFun(X_temp,model.IW,model.Bias);
        case{'hardlim'}
            H = HardlimActFun(X_temp,model.IW,model.Bias);
    end
   
   
     output_temp = H*model.alphab;
     model.pred = [model.pred; output_temp];
     
     addin_index = index_temp(Y_temp~=sign(output_temp));
     addin_num = length(addin_index);
     
     cut_index=[];
     c=[];
     for jj=1:addin_num
        % K_active = abs(SigActFun(X_active,model.IW,model.Bias)*model.alphab);
         K_active = Y_active.*(SigActFun(X_active,model.IW,model.Bias)*model.alphab);
         c=find(K_active==max(K_active));
         if length(c)>0
         cut_index=[cut_index c(1)];
         active_index(c(1))= addin_index(jj); 
         end
     end
     
     %%%%%%%
     num_P=num_P+length(find(Y(addin_index,:)==1))-length(find(Y(cut_index,:)==1));
     num_N=num_N+length(find(Y(addin_index,:)==-1))-length(find(Y(cut_index,:)==-1));
     w11=[];
     w12=[];
     Y(addin_index,:);
    for u=1:length(Y(addin_index,:))
       if Y(addin_index,:)==1
         w11(u)=1/num_P;
       else
         w11(u)=1/num_N;
       end
    end
    Y(cut_index,:);
     for u=1:length(Y(cut_index,:))
       if Y(cut_index,:)==1
         w12(u)=1/num_P;
       else
         w12(u)=1/num_N;
       end
     end
    W1=diag([w11 w12]);
     %%%%%%%
     
     H = [SigActFun(X(addin_index,:),model.IW,model.Bias);SigActFun(X(cut_index,:),model.IW,model.Bias)];
     H1= [SigActFun(X(addin_index,:),model.IW,model.Bias)' -SigActFun(X(cut_index,:),model.IW,model.Bias)'];
     
     if(addin_num)>0        
        error=error+addin_num;   
        M = M - M * H1 * (W1 + H * M * H1)^(-1) * H * M; 
        model.alphab = model.alphab + M * H1 * W1 * (Y([addin_index cut_index]) - H * model.alphab);
       % active_index=[active_index(numel(addin_index)+1:end);addin_index'];
       model.S=[active_index];
        X_active =  X(model.S,:); 
        Y_active =  Y(model.S,:);
        model.SV =X_active; 
     end
  end

  
   sgnoutput = sign(model.pred);
   err_num = 0; err = zeros(length(model.pred),1);
   TP=0;
   TN=0;
   FP=0;
   FN=0;
   %%%%%%
    for ii=model.maxSV+1:length(Y)
       if sgnoutput(ii)==1& Y(ii) == 1
           TP=TP+1;
       elseif sgnoutput(ii)==-1& Y(ii) == -1
           TN=TN+1;
       elseif sgnoutput(ii)==1& Y(ii) == -1
           FP=FP+1;
       elseif sgnoutput(ii)==-1& Y(ii) == 1
           FN=FN+1;
       end
       model.aer(ii)=[sqrt((TP*TN)/((TP+FN)*(TN+FP)))];
    end
            model.G=model.aer(n)*100;
   
   model.time = cputime - st;