function [acc,num,varargout] = accuracyIndex_0(indexRank,y)
% calculate the accuracy index
%
% Inputs:
%  indexRank: the predicted discriminant function value of the samples;
%  y: a column vector consisting of the labels,  consisting of +1 and -1;
% Outputs:
%  num: array of accuracy structure with the same length as
%    arg.selectedTarget
%   .TP : number of true positives
%   .FP : number of false positives
%   .FN : number of false negative
%   .TN : number of true negative
%  acc: array of accuracy structure
%   .FDR: false discovery rate: FP/(FP+TP)
%   .TPR: true positive rate:  TP/(TP+FN)
%   .FPR: false positive rate: FP/(FP+TN)
%   .kappa: kappa index       
%   .auc: AUC value 
%   .bm: Bookmarker Informedness metric
%   .gmean: g-mean 
%  varargout{1}: id, array of a structure with the same fields as NUM; indexing the
%      selected samples
%  versions:
%   * 2020.2.28
%       ** add  new fields of the output acc
%           .accuracy, .precision, .F,   .TP,  .FP,  .TN, .FN 
%   * 2019.6.21 
%       ** check whether y consists of 1 and -1
%   * 2019.6.7 the first version

if   length(y)~=length(indexRank)
    error('The length of the #1 and #2 should equal.');
end
y = int32(y); 
if   nnz(y==1) + nnz(y==-1)< length(y)
    error('The vector Y shoud consist of 1  and -1.');
end

% calculate the accuracies based on the value of arg.selectdTarget
len_sel = 1;
num = struct('TP',num2cell(zeros(len_sel,1)),'FP',0,'FN',0,'TN',0);
id =  struct('TP',cell(len_sel,1),'FP',[],'FN',[],'TN',[]);
acc = struct('FDR',num2cell(zeros(len_sel,1)),'TPR',0,'FPR',0);

fieldname_num = fieldnames(num);

if nargout>=3
    id(1).TP = find(indexRank>=0 & y ==1);
    id(1).FP = find(indexRank>=0 & y ==-1);
    id(1).TN = find(indexRank<0  & y ==-1);
    id(1).FN = find(indexRank<0  & y == 1 );
    varargout{1} = id;
    % assign num(1)
    for k=1:length(fieldname_num)
        fieldName = fieldname_num{k};
        num(1).(fieldName) = length(id(1).(fieldName));
    end
else % nargour<=2
    % calculate the field values of NUM
    num(1).TP = nnz(indexRank>=0 & y ==1);
    num(1).FP = nnz(indexRank>=0 & y ==-1);
    num(1).TN = nnz(indexRank<0 & y ==-1);
    num(1).FN = nnz(indexRank<0 & y == 1 );     
end


% assign acc(1)
acc(1).FDR = num(1).FP/(num(1).FP + num(1).TP);
acc(1).TPR = num(1).TP/(num(1).TP + num(1).FN); % TPR, recall
acc(1).FPR = num(1).FP/(num(1).FP + num(1).TN);
acc(1).TNR = num(1).TN/(num(1).TN + num(1).FP); % true negative rate 
acc(1).accuracy = (num(1).TP + num(1).TN)/length(y);
            % accuracy, (TP + TN) / (TP + FN + TN + FP  )
acc(1).precision = num(1).TP/(num(1).TP + num(1).FP);
             % precision, TP / ( TP + FP)  
acc(1).F =  2 * acc(1).TPR * acc(1).precision / (acc(1).TPR+ acc(1).precision);
    % F metric, 2 * TPR * precision / (TPR + precision)
acc(1).TP = num(1).TP; 
acc(1).FP = num(1).FP;
acc(1).TN = num(1).TN; 
acc(1).FN = num(1).FN; 

acc(1).gmean = sqrt(acc(1).TPR*acc(1).TNR ); % g-mean 
acc(1).bm = acc(1).TPR+acc(1).TNR-1 ; % Bookmarker Informedness metric

% calculate kappa
num_p = num(1).TP + num(1).FN; % number of positives 
num_n = num(1).TN + num(1).FP; % number of negatives 
%num_total = num_p  + num_n;  % total number of samples
num_total = length(y);  % total number of samples
r_p  = num_p / num_total;

p0 =  (num(1).TP + num(1).TN)/num_total;
pc = r_p * (num(1).TP + num(1).FP)/num_total + (1-r_p)*(num(1).TN + num(1).FN)/num_total;

acc(1).kappa = (p0-pc)/(1-pc); 

% calculate AUC 
[~,ind] = sort(indexRank,'descend');
vv = (num_total:-1:1)';
rank_pos_sum = sum( vv(y(ind)==1) ); 
% acc(1).auc = (rank_pos_sum - num(1).TP* (num(1).TP+1)*0.5     )/   (num(1).TP*num(1).FP) ;
acc(1).auc = (rank_pos_sum - ( num(1).TP+num(1).FN)* (num(1).TP+num(1).FN+1)* 0.5     )/ [  ( num(1).TP+num(1).FN)*(num(1).FP+num(1).TN) ];
end














