function arg = completeArg(arg0,arg_cell,arg_default_val,i_arg,mode_compulsory)
% complete values and items of a struture (or structure array) with given values
% Inputs:
%  arg0: a structure or a structure array;
%  arg_cell: a string cell array, indicating the fields to complete;
%  arg_default_val: 
%    (1) a cell array with the same size as arg_cell, indicating
%        the values of the corresponding fields;
%    (2) or a structure, indicating the values with corresponding items;
%  i_arg: Optional, a vector of indices indicating the struct to complete
%     when arg0 is a struct array;
%     i.e.
%     the function complete the struct array arg0 as follows:
%     for all k = 1,2,...
%     if arg0(k).item_i is not set and k belongs to i_arg
%       then complete the value of arg(k).item_i;
%     elseif arg0(k).item_i is not set and k does not belongs to i_arg
%       then set arg(k).item_i = [];
%     Default value of i_arg: 1:length(arg); 
%   mode_compulsory: 1 or 0, default value: 0
%      0:  only update the item when arg0(k).ITEM is not exist or has empty  value, k in i_arg.
%      1:  reset all the items of arg0 specified by arg_cell, 
%           the original values would be cleared; 
% Outputs:
% arg: a struct (array); 
%  * if mode_compulsory ==0: 
%   for each field, ITEM, indicated by arg_cell{i}, i =1,2,... 
%   if arg0(k).ITEM is not exist or has empty value,  assign
%       arg(k).ITEM = arg_default_val{i}; for all k in i_arg
%   otherwise
%       arg(k).ITEM = arg0(k).ITEM.
%   end
%  
%  * if mode_compulsory ==1: 
%   for each field, ITEM, indicated by arg_cell{i}, i =1,2,... 
%     assign
%       arg(k).ITEM = arg_default_val{i}; for all k in i_arg.
%
%  Usage 
% arg = struct('n',20,'k',5);
% arg_field_cell = {'k','val'};
% arg_val_cell = {4,'job'};
% arg2 = completeArg(arg, arg_field_cell,arg_val_cell);
% arg4 = completeArg(arg, arg_field_cell,arg_val_cell,[],0); 
%   these two commands are equivalent
%==>
% arg2.n	= 20	
% arg2.k	= 5	
% arg2.val	= job
%
%  arg4 is equal to arg2
%
% arg3 = completeArg(arg, arg_field_cell,arg_val_cell,[],1);
%==>
% arg3.n	= 20	
% arg3.k	= 4	
% arg3.val	= job





if isempty(arg0)
    arg0 = struct();   % this initialization should be previous than Line 29: i_arg = 1:length(arg0); 
end
if nargin<=3 || isempty(i_arg)
    i_arg = 1:length(arg0); % set default value of i_arg
end
if nargin<=4 
    mode_compulsory = 0;
end

arg = arg0; 

if mode_compulsory
    % set the values of specified items empty
    for ii=1:length(arg_cell)
        fieldName = arg_cell{ii};
        for k_arg = 1:length(arg)
            in_i_arg = ismember(k_arg,i_arg);       
            if in_i_arg && isfield(arg,fieldName)
                arg(k_arg).(fieldName) = [];
            end
        end
    end
end

flag_is_cell_default_val = iscell(arg_default_val);
for ii=1:length(arg_cell)
    fieldName = arg_cell{ii};
    for k_arg = 1:length(arg)
        in_i_arg = ismember(k_arg,i_arg);       
        if in_i_arg && (~isfield(arg,fieldName) || isempty(arg(k_arg).(fieldName)))
            if flag_is_cell_default_val
                arg(k_arg).(fieldName) = arg_default_val{ii};
            else % arg_default_val is struct
                if isfield(arg_default_val,fieldName)
                    arg(k_arg).(fieldName) = arg_default_val.(fieldName);
                else
                    arg(k_arg).(fieldName) = [];
                end
            end
        elseif ~in_i_arg && ~isfield(arg,fieldName) 
            arg(k_arg).(fieldName) = [];
        end
    end
end

end