function H = distMatrix(A,B,arg)
% calculate the pointwise  distance/similarities of the samples in matrix A and B
%   H(i,j) = k(A(:,i),B(:,j))
% or
%   H(i,j) = k(A(i,:),B(j,:))
% Inputs:
%   A, B: two matrix with the same number of rows; each column represents
%       a sample;
%   arg:  Optional,   argument;  default  value 1;
%     .dim:
%       1 : each column  (1st dimension) of A and B is a sample,
%       2:  each row (2nd dimension) of A and B is a sample;
%     .dist:
%       'norm':  2-norm distance, default value
%       'norm1': 1-norm distnace
%       'product': dist(x,x') = <x,x'>
% Outputs:
%  H: a m-by-n matrix, where m,n are the samples of A and B, resp.

if nargin<=2
    arg = struct();
end
arg = completeArg(arg,{'dim','dist'},{1,'norm'});

if arg.dim == 1
    [k,m] = size(A);
    [k2,n] = size(B);
else % arg.dim ==2
    [m,k] = size(A);
    [n,k2] = size(B);
end
if k~=k2
    error('The number of rows of input matices do not coincide');
end

switch lower(arg.dist)
    case 'norm'
        H = zeros(m,n,'like',A);
        if arg.dim == 1
            for i = 1:n
                U = bsxfun(@minus,A,B(:,i)); % U is a k-by-m array (the same size as A)                 
                H(:,i) = sqrt(sum(U.*U,1))';
            end
        else %arg.dim ==2            
            for i = 1:n
                U = bsxfun(@minus,A,B(i,:)); % U is a k-by-m array (the same size as A)                 
                H(:,i) = sqrt(sum(U.*U,2));
            end
        end
    case 'norm1' % 1-norm distance
        H = zeros(m,n,'like',A);
        if arg.dim == 1
            for i = 1:n
                U = bsxfun(@minus,A,B(:,i)); % U is a k-by-m array (the same size as A)                 
                H(:,i) =  sum(abs(U),1)';
            end
        else %arg.dim ==2            
            for i = 1:n
                U = bsxfun(@minus,A,B(i,:)); % U is a k-by-m array (the same size as A)                 
                H(:,i) =  sum(abs(U),2);
            end
        end
    case 'linear'
         
        %H = zeros(m,n,'like',A);
        if arg.dim == 1 
            H = A'*B ;
        else
            H = A*B';
        end
    otherwise
        error('do not support specified distance/similarity metric.');
end

end



