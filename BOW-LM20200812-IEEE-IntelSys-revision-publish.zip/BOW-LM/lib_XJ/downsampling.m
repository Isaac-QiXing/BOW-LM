function data2_st   = downsampling(data_st,variable_c,n_row_down)
%   downsampling the rows of a group of   matrices with the same number of
%   rows
% inputs��
%  data_st: a (scalar)  struct with all each field a matrix of data item,
%  variable_c: a string cell array, indicating the downsampling fields 
%       all the  data matrices specified by var_c should have the identical number of rows;
%  n_row_down: number of rows of each downsampled data matrix
%
% outputs:
%   data_st2: a struct with the same fields as data_st, the struct after
%   downsampling
%


% 0. check  whether all the specified variable matrix have the same number of rows
%variable_c = fieldnames(data_st);
n_row_v = zeros(size(variable_c));
for ii=1:length(n_row_v)
    var_str = variable_c{ii};
    n_row_v(ii) =  size(data_st.(var_str),1);
    % n_row_v(ii): the number of rows of ii-th specified variable
end
n_row =  max(n_row_v);
 
if max(n_row_v)~=min(n_row_v)
    error('All the specified variables should have the same number of rows.');
end
% 1. downsampling
if  n_row_down < n_row
    %data2_st = data_st;
    v = randi_unique(n_row,n_row_down);
    for ii=1:length(n_row_v)
        var_str =   variable_c{ii};
        data2_st.(var_str)=   data_st.(var_str)(v,:) ;
    end
else
    for ii=1:length(n_row_v)
        var_str =   variable_c{ii};
        data2_st.(var_str)=   data_st.(var_str);
    end
end


end
