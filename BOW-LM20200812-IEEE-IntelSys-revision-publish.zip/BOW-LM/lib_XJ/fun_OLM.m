function acc_t = fun_OLM(data_st,arg)
%   interface of several online learning methods
%  Inputs:
%   data_st: a struct of data fields
%       .x: feature matrices, each row is a record;
%       .y: a column vector of labels
%   arg: a struct of parameters
%      .solver: a string of solvers, supported solvers:
%           'BSGD'| 'BOGD' |  'perceptron' | 'LS-SVM'
%      .kerparam, a struct of kernel parameters
%           .type: a string indicating of kernel parameters
%           .gamma: kernel parameter
%               e.g., kerparam =struct('type','rbf','gamma',1/InputDim);
%       .maxSV: a positive integer, maximum number of support vectors
%       .nu:
%       .block: a positive integer, block size, indicating the number of samples received
%           at each online round
%
%       .S
%       .SV
%       .ker
%       .b
%       .b2
%       .step: the above 6 parameters  are initialized by model_init()
%   itetInf_t:
%       a struct of the outputs of the online learning method;

x_tran = transpose(data_st.x);
y = data_st.y;
clear('data_st');


switch lower(arg.solver)
    case 'bsgd' %BSGD
        [~,y_predict]= k_BSGD_train(x_tran, y', arg);
    case 'bogd' % BOGD
        [~,y_predict]= k_BOGD_train(x_tran, y', arg);
    case 'perceptron'
        [~,y_predict]=  k_perceptron_train(x_tran, y',arg);
    case {'ls-svm','ls'} % LS-SVM
        [~,y_predict] = k_LSSVM_train(x_tran, y, arg);
    otherwise
        error('Only  ''BSGD'', ''BOGD'', ''perceptron'', ''LS-SVM'' solver supported.');
end

clear('x_tran');

[acc_t ] = accuracyIndex_0(y_predict, y);


end