function [prob_v, prob_old_v,arg2] = fval2prob(f_v,y_v,arg)
% transform discriminant function values of binary classification to probabilistic output 
% Inputs:
%   f_v: a column vector of discriminant function values of the samples
%   y_v: a column vector of corresponding true labels of the samples, consisting of 1s and -1s, with the same
%       lenght as f_v; 
%   arg:   parameter struct 
%     arg.AB: a 1-by-2 vector consisting of the  coefficient A and B, default value [];
%            P(y_i = 1|x_i) = 1/(1+exp(A*f(x_i)+B))
%            B is set 0. 
%     arg.ite: the index of current sample, used to calculate the stepsizes to update A and B,
%            defaulte vlaue 1; 
%     arg.f_old: a column vector of discriminant function values, defaut value [];  
%     arg.N_pos: number of positive training samples, default value nnz(y_v==1) 
%     arg.N_neg: number of negative training samples, default value nnz(y_v==-1) 
% Outputs: 
%   prob_v:   
%       a columnv vector of scalars in [0,1] indicatings the probabilistics of P(y_i = 1|x_i)
%       corresponding to the samples of f_v
%   prob_old_v:   
%       a columnv vector of scalars in [0,1] indicatings the probabilistics of P(y_i = 1|x_i)
%       corresponding to the samples of arg.f_old
%   arg2: 
%       the updated parameters, with the same struct as arg
%       arg2.AB: a vector of the updated parameter values A and B 
%       arg2.N_pos: = arg.N_pos + nnz(y_v==1)
%       arg2.N_neg: = arg.N_neg + nnz(y_v==-1)
%       arg2.ite = arg.ite + length(y);

% Ref. [1] Lin, Hsuan-Tien, etal. A note on Platt's probabilistic outputs for support vector
%    machines , Machine Learning 2007. 

debug_on = 0;
% 0. initialization
prob_v = [];
prob_old_v = [];
arg2 = []; 

if isempty(f_v) && isempty(arg.f_old)
    return
end

% 0.1 set defaut value of arg
if isempty(y_v) && (~isfield(arg,'N_pos') || ~isfield(arg,'N_neg'))
    error('arg.N_pos and arg.N_neg should be set if y_v ==[].');
end

%arg = completeArg( arg, {'AB','f_old','N_pos','N_neg','ite'},{[],[],nnz(y_v==1),nnz(y_v==-1),1});
if ~isfield(arg,'AB')  
    arg.AB = [];
end
if ~isfield(arg,'f_old')  
    arg.f_old = [];
end
if ~isfield(arg,'N_pos') ||isempty(arg.N_pos) 
    arg.N_pos = nnz(y_v==1);
end
if ~isfield(arg,'N_neg') ||isempty(arg.N_neg) 
    arg.N_neg = nnz(y_v==-1);
end
if ~isfield(arg,'ite') ||isempty(arg.ite) 
    arg.ite = 1;
end
% 0.2 initialize coefficient A and B

if isempty(arg.AB)
    coef_AB = [-1;0];
else
    coef_AB = columnVec(arg.AB);
end

% 0.3 
    
ti_pos = (arg.N_pos+1)/(arg.N_pos+2);
ti_neg = 1/(arg.N_neg+2);
is_pos_v = y_v==1; 

if debug_on
    fwritef(1,'ti_pos',ti_pos,'', 'ti_neg',ti_neg,'');
end

% 0.4 log-exp loss and its derivative 
ell =  @(t) log(1+exp(t));
grad_ell = @(t) 1-1./(1+exp(t)); % derivative of ell(t)
sigmoid_h = @(t) 1./(1+exp(t));

% 1. train/update the coefficents A and B
% 1.1 parameters
tolX_min = 1E-4; % minimum step size
ite = arg.ite + 10;   

if ~isempty(f_v)
    % A, B is claculated by minimizing 
    %          \min_{z = (A,B)}^{}   -\sum_{i=1}^{l} (t_i \log(p_i) + (1-t_i) \log (1-p_i) ),
    %  with  p_i^{} = P_{A,B}^{}(f_i),
    %   t_i = (N_pos +1)/(N_pos +2)   if  y_i = +1 
    %   t_i =  1/(N_neg+2)      if   y_i = -1 
   
    for ii=1:length(f_v)
        fi = f_v(ii);
        is_pos = is_pos_v(ii);
        alpha_k = max(1/(ite+ii),tolX_min); % set step size 
        grad =   grad_loss(fi,is_pos); % calculate the gradient 
        coef_AB = coef_AB - alpha_k * grad;
        coef_AB(2) = 0; %%% constantly set B = 0
        if debug_on
            zz = coef_AB(1)*fi+coef_AB(2);
            pz = sigmoid_h(zz);
            %fwritef(1,'ite',ii,'','p(A*fi+B)',pz,'','coef',coef_AB','','is_pos',is_pos*1.0,'','grad',grad,'');            
        end
    end   
    
end
A = coef_AB(1);
B = coef_AB(2); 


    function gd = grad_loss(fi,is_pos)
        % gradient of the  loss function at current sample 
        % step A. calculate ti
        if is_pos
            ti =  ti_pos;
        else
            ti =  ti_neg;
        end
        % step B. calculate the gradient 
        gd = [fi;1];
        z = coef_AB(1)*fi+coef_AB(2);
        gd = (ti*grad_ell(z) - (1-ti)*grad_ell(-z)) *gd; % ti*grad_ell(z)*gd + (1-ti)*grad_ell(-z)*(-gd);
    end

% 2. calculate the probabilistic outputs 

if ~isempty(f_v)
    %%%
%     A
%     B 
%     f_v
%     prob_v = sigmoid_h( A*f_v+B)
%     %%%
    prob_v = sigmoid_h( A*f_v+B);
end
if ~isempty(arg.f_old)
    prob_old_v = sigmoid_h( A* arg.f_old+B);
end

% set arg2 
arg2 = arg; 
arg2.AB = coef_AB; 
arg2.f_old = [];
arg2.N_pos = arg.N_pos + nnz(is_pos_v);
arg2.N_neg = arg.N_neg + nnz(~is_pos_v);
arg2.ite   = arg.ite + length(y_v);

end