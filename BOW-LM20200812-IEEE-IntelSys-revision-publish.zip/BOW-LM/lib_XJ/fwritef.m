function pos = fwritef(fid,varargin)
%write some variables to a text file (or command line)
%Input Arguments:
%   fid: the handle of the file
%   varargin: in the form: {labelOfVar1,var1,'format1', labelOfVar2, var2,'format2',...,parameterStr}
%           the default format of variables which type is 'double' is
%           '%8.4f\t'
%     the variable can be 
%        (1)  a (real or complex) matrix 
%        (2)  a string or a numeric scalar
%        (3)  a string/numeric cell matrix, with each cell consisting of a 
%               single string or each cell consisting of a numeric,
%               indicated by the format 'c' 
%        (4)  a structure (or strcture array) with  the value of each
%               fields described by (1) -- (2) 
%        (5)  a cell array with each cell described by (1) -- (2)
%   Format: may 
%       (1) a format string: apply the formats for printing each elements; for
%           instance '%d\t', '%.2f\t';
%       (2) '': determine the formats automatically;
%       (3) 'c***': indicating the variable is a string/numeric cell matrix;
%               '***' indicates a format string for printing each elements,
%               for instance 'c%d\t' indicate this is a cell matrix, and
%               print each element with format '%d\t'
%                   
%       (4) {format_str,pos_start}: 
%        * format_str: a string beginning with a format string described in
%           the above item (1) (2) or (3), and ended with
%           '+':  put out the variabel by appending the end of
%               each following lines, starting from end of the current
%               line; (if it is a newline character at pos_start, start
%               writing  at the end of the next line); 
%           '-': put out the variable at the beginning of the followings 
%               lines at the NEXT line; 
%        * pos_start: an integer indicating a position of current line;
%        * Note that for the 'appendLine' format, the user should ensure
%           that the field FID can be read and write, i.e. use the
%           permision 'r+', 'w+' or 'a+' to open the file.
%  ParameterStr: Optional,
%       The last input can be a parameter (string) indicating some style 
%           for put out:
%       '-rowVector': put out all numeric vector values as row vectors
%          regardless it is a column or a row vector;
% Outputs:
%   pos: an integer inidcating the position at the moment finished to
%       writing


    fileName_temp = sprintf('./temp_%s.txt',datestr(date));
    
    function fid2 = prepareNewFile(pos_current)
        % prepare a new file for inserting characters into file fid
        
        % creat a new file for reading and writing        
        fid2 = fopen(fileName_temp,'w+');        
        % read the characters from file fid, put them to the new file 
        fseek(fid,pos_current,-1);
             % move to the specified location in the file fid
        movePos2EndLine(fid);
        while ~feof(fid)
            tline = fgets(fid); % reserve the newline character
            if ischar(tline)
                fprintf(fid2,tline);
            end
        end
        % move the position of file fid2 at the beginning of the file 
        frewind(fid2);        
        % move the position of file fid to pos_current
        fseek(fid,pos_current,-1);
        movePos2EndLine(fid);
    end

    

    function movePos2EndLine(myfid)
        % move the position to the end of the current line (at the position
        % of '\n' )
        % * if current position is a newline character, do not move
        % * if current position is 0, do not move
        % Inputs: id of an open file
        if ftell(myfid)==0 % if current position is 0, do not move
            return
        end
        if ~feof(myfid)
            fseek(myfid,-1,0); %  get back 1 character: consider the case 
                               %    that the character of the current
                               %    position itself is a newline character;
            fgets(myfid); % read one row;            
            fseek(myfid,0,0); % prepare for reading or writing 
        end
    end

    function writeAheadLineStr2fid()
        % write one line of file fid2 to file  fid
        if flag_append_line && ~feof(fid2)
            tline = fgetl(fid2); % fgetl: remove the newline character
            if ischar(tline)
                fprintf(fid,tline);            
            end
        end
    end

    function writeEndLineStr2fid()
        % write the end line string to file fid
        if flag_ahead_line 
            % write one line to file fid
            if ~feof(fid2)
                tline = fgets(fid2); % fgets: reserve the newline character                
                if ischar(tline)
                    fprintf(fid,tline);
                end
            else
                fprintf(fid,'\n');
            end
        else
            fprintf(fid,'\n');
        end        
    end


default_numeric_format = '%.4f\t'; 
    % default format for real numeric scalar;
    
% determine whether the last input is a parameter    
flag_rowVector = 0; % whether to put out the numeric vector values as row vector
option_str = ''; % option string
n_format_field = floor((nargin-1)/3)*3; % number of fields to set the formats and values
if mod(nargin-1,3)~=0 && ~isempty(varargin{end})
    option_str = varargin{end};
    flag_rowVector = strcmpi(option_str,'-rowvector');       
end

for i=1:3:n_format_field
    nm=varargin{i};
    var=varargin{i+1};
    format=varargin{i+2};
    
    % initialization
    flag_cell_array = 0; % whether the format is set 'c';
    flag_append_line = 0; % whether the format is set append to lines: '+';
    flag_ahead_line = 0; % whether the format is set put ahead of the the 
                         %   lines: '-';  
            
    % set format_str, flag_append_line, flag_ahead_line
    format_str = format;
    if iscell(format) && ischar(format{1})
        format_str = strtrim(format{1});     
        len_format_str = length(format_str);
        if len_format_str >0
            flag_append_line = format_str(len_format_str)=='+';
            flag_ahead_line = format_str(len_format_str)=='-';
            if (flag_append_line || flag_ahead_line) &&  len_format_str>1
                format_str = format_str(1:len_format_str-1);
            elseif flag_append_line || flag_ahead_line
                format_str = '';
            end
        end
    end       
    
    % set format_str, flag_cell_array    
    if ischar(format_str) && ~isempty(format_str);    
        format_str = strtrim(format_str);        
        len_format_str = length(format_str);    
        if len_format_str > 0
            flag_cell_array = (format_str(1)=='c');
            if flag_cell_array && len_format_str>1
                format_str = format_str(2:len_format_str);
            elseif flag_cell_array
                format_str = '';
            end
        end
    end    
    
    flag_no_format_str = isempty(format_str);
        % whether the format string is not set;
        
    % set pos, prepare a temporary file 
    if flag_append_line || flag_ahead_line
        if length(format)<2
            error('it should be given the position of a line for ''+'' or ''-'' format');
        end
        pos = format{2};        
        fid2 = prepareNewFile(pos);        
    end
    
    % print variable name        
    writeAheadLineStr2fid(); % print the strings before the line
    if ~isempty(nm) && (ischar(var)||isnumeric(var)||flag_cell_array)
        % nm is not empty and var is basic type of variables (1) --(3)
        fprintf(fid,'%s',nm); % start to write contents to file
        fprintf(fid,'\t');
    end
    
    %print variable values
    if isempty(var)        
        writeEndLineStr2fid(); % end to print variable values
        continue;
    end
        % construct a temparary varable NM1: add a tab space before NM
    if iscell(var) && ~flag_cell_array
        nm1 = sprintf('\t');
        if isempty(strtrim(nm))
            nm1 = sprintf('\t%s',nm);
        end
    end    
    
    if ischar(var) % var is a string (character array)
        if flag_no_format_str
            fprintf(fid,var);
        else
            fprintf(fid,format_str,var);
        end        
        writeEndLineStr2fid();
    elseif isnumeric(var)
        if flag_no_format_str
            if isIntegerVal(var)
                format_str = '%d\t';
            elseif isreal(var)
                format_str = default_numeric_format;
            else % iscomplex
                format_str = '%.3f + %.3fi\t';
            end
        end
        % deal the case: flag_rowVector==1
        if flag_rowVector && isvector(var) && size(var,1)>1
                % var is a column vector
            var = var';
        end
        row_num = size(var,1);
        for dim=1:row_num
            if isreal(var)
                fprintf(fid,format_str,var(dim,:));
            else                
                fprintf(fid,format_str,real(var(dim,:)),imag(var(dim,:)));
            end
            writeEndLineStr2fid();  
            if dim< row_num
                writeAheadLineStr2fid();
            end
        end        
    elseif isstruct(var)
        fn = fieldnames(var);        
        if length(var)==1
            % put out the names and values of each fields            
            for ii=1:length(fn)
                nm1 = sprintf('%s.%s',nm,fn{ii});                    
                fprintf(fid,'%s\t= ',nm1);
                if isstruct(var.(fn{ii})) || iscell(var.(fn{ii}))
                    writeEndLineStr2fid();
                    writeAheadLineStr2fid();
                    nm1 = sprintf('\t%s',nm1);                                        
                    fwritef(fid,nm1,var.(fn{ii}),format,option_str);
                else        
                    fwritef(fid,'',var.(fn{ii}),format,option_str);   
                end                
            end
        else
            size_v = size(var);
            n = length(size_v);
            if n==2 && (size_v(1)==1 || size_v(2)==1) % var is a one-dimensional struct array 
                % reset N and SIVE_V
                n=1;
                size_v = length(var);
            end
            ind = 0;                        
            while 1
                v = decimal2general(size_v,ind);
                if v(n)>=size_v(n) % size_v: from left to right: low dight --> high digit
                    break;
                end
                % put out the values of each fields                
                for ii=1:length(fn)                                        
                    nm1 = sprintf('%s(',nm);
                    if n>1
                        nm1 = strcat(nm1,sprintf('%d,',v(1:n-1)+1));
                    end
                    nm1 = strcat(nm1,sprintf('%d)',v(n)+1),sprintf('.%s',fn{ii}));                    
                    fprintf(fid,'%s\t= ',nm1);
                    if isstruct(var(ind+1).(fn{ii})) || iscell(var(ind+1).(fn{ii}))
                        writeEndLineStr2fid();
                        writeAheadLineStr2fid();
                        nm1 = sprintf('\t%s',nm1);
                        fwritef(fid,nm1,var(ind+1).(fn{ii}),format,option_str);
                    else
                        fwritef(fid,'',var(ind+1).(fn{ii}),format,option_str);                     
                    end
                end
                ind = ind + 1;
            end
        end
    elseif iscell(var) && flag_cell_array 
        % print the strings in the cell array (or matrix)             
        if flag_no_format_str
            if isnumeric(var{1})
                format_str = default_numeric_format;
            else
                format_str = '%s\t'; %  string cell array (or matrix)
            end
        end
        row_num = size(var,1);
        col_num = size(var,2);
        for dim=1:row_num
            for col = 1:col_num
                fprintf(fid,format_str,var{dim,col});            
            end            
            writeEndLineStr2fid();
            if dim<row_num
                writeAheadLineStr2fid();
            end
        end        
    elseif iscell(var) && ~flag_cell_array     
        if length(var)==1
            % put out the value of the cell            
            if ~isempty(strtrim(nm))                
                fprintf(fid,'%s =',nm);
                writeEndLineStr2fid();            
                writeAheadLineStr2fid();            
            else
                fprintf(fid,'%s',nm);
            end
            fwritef(fid,nm1,var{1},format,option_str);            
        else
            size_v = size(var);
            n = length(size_v);
            if n==2 && (size_v(1)==1 || size_v(2)==1) % var is a one-dimensional cell array 
                % reset N and SIVE_V
                n=1;
                size_v = length(var);
            end
            ind = 0;                        
            while 1                
                v = decimal2general(size_v,ind);
                if v(n)>=size_v(n)
                    break;
                end
                % put out the values of each cell
                fprintf(fid,'%s{',nm);
                if n>1
                    fprintf(fid,'%d,',v(1:n-1)+1);
                end                
                fprintf(fid,'%d} = ',v(n)+1);  
                writeEndLineStr2fid();
                writeAheadLineStr2fid();
                fwritef(fid,nm1,var{ind+1},format,option_str); 
                ind = ind + 1;
            end
        end
        
    end % end to print out the values of the variable
    
    if flag_append_line || flag_ahead_line
        % put out the remain contents of file fid2 to file fid
        while ~feof(fid2)
            tline = fgets(fid2);
            if ischar(tline)
                fprintf(fid,tline);
            end
        end
    end
    
    if flag_append_line || flag_ahead_line
         % close and delete the temparay file fid2
        fclose(fid2);
        if exist(fileName_temp,'file')
            delete(fileName_temp);
        end
    end
end

pos = ftell(fid);
end % end of the function fwritef()

function  v = decimal2general(size_v,ind)
% transfrom a decimal integer to a general digit
%  Inputs: 
%   size_v: a vector consists positive integers, indicating the n-ary digits
%      e.g. size_v(i) = 3 means 3-1 = 2  is the maximum number for the i-th digits
%  Outputs:
%   v: a vector with the same length as SIVE_V consisting nonnegative
%       integers
n = length(size_v);
v = zeros(n,1);
base = prod(size_v);
for ii=n:-1:1 %  ii iterates from the high (right) digit to low (left) digit    
    base = base/size_v(ii);    
    v(ii) = floor(ind/base);
    ind = ind - v(ii)*base;    
end    
end

function flag = isIntegerVal(x)
% determine whether the value of a scalar is integer
% Inputs:
%  x: a scalar or an array;
% Outputs:
%  flag: an array with the same size as x, consisting of 1 or 0, indicating
%       whether the value of each element of x is integer;
    flag = x==round(x);
end