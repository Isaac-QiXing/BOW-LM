function [data_st] = getDataRecords(arg)
% put out data of classification
% Inputs:
%  arg
%    .dataFile: mat data file name (including the paths) consisting one or
%    several data matrices (or vectors);
%               each row is a record, each column is a feature (or a label)
%    .variable_outlier: a string, variable (contained in arg.dataFile) to add outliers
%    .variable_std: a string or a cell of strings, variables (contained in
%        arg.dataFile) to standarize
%    .variable_shuffle: a string or a cell of strings, variables (contained in
%        arg.dataFile) to shuffle, all the specified variables should have
%        the same number of records (rows). The rows/records of specified variables
%         would be shuffled;
%    .ratio_outlier: optional, a scaler in [0,1]  proportion of the data records
%       which are incorporated outliers, default [];
%    .mean_outlier: optional, a scalar or a 1-by-d vector, indicating the mean value(s)
%       of the normal distribution of the outliers; default [];
%           with d the number of features of the data variables
%    .variance_outlier: optional, a scalar or a d-by-d symmetric positive semi-definite matrix,
%           indicating the variance the normal distribution of the outliers; default [];
%       if both .mean_outlier and .variance are   scalars, then all the feature values of a record
%       enjoys a common normal distribution;
%
% versions
%   * 2020.2.24
%    remove the parameters .standarize, .shuffle
%     .standarize: optional, 1 or 0, whether standarize the data matrix
%        (records) contained in the specified dataFile, arg.(variable_std); default 0;
%    .shuffle: optional, 1 or 0, whether shuffle the specified records in
%       the variable arg.(variable_shuffle); default 0;
%   * 1st version. 2020.2.20

% ----------- future version ------
%    .n_max_records: optional, maximum number of records to return
%           it need to be consistent with shuffling and outlier  operation
%   *  support multiple files to incorporate outliers
% ----------------------------------

% 0. load data�� standarize the feature values and shuffle the  records

% 0.1 load data
data_st = struct();
if exist(arg.dataFile,'file')
    data_st = load(arg.dataFile);
else
    error('the specified dataFile %s is not found.',arg.dataFile);
end

arg = completeArg(arg,...
    { 'variable_outlier','variable_shuffle','variable_std','ratio_outlier','mean_outlier','variance_outlier'},...
    { '',                '',                  '',             1.0,                 [],             []     });

% check whether the specified variables exist
    function flag = varExist(var_str)
        flag = 1;
        if isempty(var_str) || ~isfield(data_st,var_str)
            warning('there is no data variable ,%s, is specified to deal with.',var_str);
            flag = 0;
        end
    end

% 0.2 standarization
if   ~isempty(arg.variable_std)
    % check arg.variable_std
    if ischar(arg.variable_std)
        variable_std_c = {arg.variable_std};
    elseif iscell(arg.variable_std)
        variable_std_c = arg.variable_std;
    else % arg.variable_std is not a cell or a string
        warning('arg.variable_std should be a string or a cell of strings');
    end
    % standarize the specified variables
    for ii=1:length(variable_std_c)
        var_str = variable_std_c{ii};
        if varExist(var_str)
            data_st.(var_str) = standardize(data_st.(var_str));
            % make each column of the data matrix zero-mean and unit-variance
        end
    end
end

% 0.3 shuffle the records
ind_shuffle= [];
if   ~isempty(arg.variable_shuffle)
    % check arg.variable_shuffle
    if ischar(arg.variable_shuffle)
        variable_shuffle_c = {arg.variable_shuffle};
    elseif iscell(arg.variable_shuffle)
        variable_shuffle_c = arg.variable_shuffle;      
    else % arg.variable_std is not a cell or a string
        warning('arg.variable_shuffle should be a string or a cell of strings');
    end
    % check  whether all the specified variable matrix should have the same number of rows 
    if iscell(arg.variable_shuffle)
        n_row_v = zeros(size(variable_shuffle_c));
        for ii=1:length(n_row_v)
            var_str = variable_shuffle_c{ii};
            n_row_v(ii) =  size(data_st.(var_str),1); 
                % n_row_v(ii): the number of rows of ii-th specified variable
        end
        if max(n_row_v)~=min(n_row_v)
             error('All the specified variables should have the same number of rows (records).');
        end
    end
    % get the number of records
    n_row = size(data_st.(variable_shuffle_c{1}),1);  
    % shuffle the records
    ind_shuffle = randperm(n_row); 
    for ii=1:length(variable_shuffle_c)
        var_str = variable_shuffle_c{ii};
        if varExist(var_str)
            data_st.(var_str) =   data_st.(var_str)(ind_shuffle,:);            
        end
    end
end

% 1. incorporate  outliers
var_str = arg.variable_outlier;
n_sample_outlier= 0;
v= [];
epsilon = [];
if ~isempty(arg.mean_outlier) && ~isempty(arg.variance_outlier) ...
        && ~isempty(arg.variable_outlier) && arg.variable_outlier >0
    [n_sample,n_dim] = size(data_st.(var_str));
    arg.ratio_outlier = max(min(arg.ratio_outlier,1),0);
    n_sample_outlier = floor(n_sample*arg.ratio_outlier);
    if isscalar(arg.mean_outlier)
        mean_outlier_v = ones(1,n_dim)*arg.mean_outlier;
    else
        if isvector(arg.mean_outlier) && length(arg.mean_outlier) == n_dim
            error('arg.mean_outlier should be a scalar or a vector with length == #features');
        end
        mean_outlier_v =arg.mean_outlier;
    end
    if isscalar(arg.variance_outlier)
        variance_m = diag(ones(1,n_dim)* arg.variance_outlier);
    else
        if  size(arg.variance_outlier,1) == n_dim &&  size(arg.variance_outlier,2) == n_dim
            error('arg.mean_outlier should be a scalar or a positive semidefinite matrix with order == #features');
        end
        variance_m =arg.variance_outlier;
    end
    epsilon = mvnrnd(mean_outlier_v,variance_m, n_sample_outlier );
    v = randi_unique(n_sample,n_sample_outlier);
    data_st.(var_str)(v,:) = data_st.(var_str)(v,:) + epsilon;
end

% 2. put out related information
data_st.n_sample_outlier = n_sample_outlier;
data_st.index_outlier = v; % indices of the records that incorporated outliers
data_st.data_outlier = epsilon; %  incorporated outliers
data_st.arg = arg;
data_st.ind_shuffle = ind_shuffle; % index of shuffle 
    % data_st.(var_shuffled) =  var(ind_shuffle,:)
    %   with var the original variable, var_shuffled the shuffled variable
 
end