function  [ center_v, thresh_outlier,dist_v] = getThresh_outlier(H,arg)
% calculate the center of a group of samples and the
%   threshod of the distance to the center for identifying outliers 
% Inputs:
%   H: data matrix, each row or column is a record
%  arg: an optional struct of parameters 
%  arg.dim:  
%       1: each column of H_temp is a record
%       2: each row of H_temp is a record
%  arg.iqr, an optional positive scalar to determine thresh_outlier , default value 1.5; 
%    the threshold of an outlier is calculated as 
%     threshold = 75% quartile + arg.iqr * interquartile range
%   arg.prctile, an optional positve scalar to determine thresh_outlier;
%     Either one of arg.iqr or arg.prctile need to be provided
%      threshold = arg.prctile% quartile  
%  arg.dist: 
%       'norm': use 2-norm to measure the distance of two records
%       'norm1': use 1-norm ot measure the distance of two records
% outputs:
%   center_v: a vector indicating the center point, with the same
%       number of featurs as  H
%       if arg.dim==1, center_v is a column vector; 
%       if arg.dim==2, center_v is a row vector;
%   thresh_outlier: a positive scalar, indicating the threshod of the distance to the center
%       for identifying the outliers 
%   dist_v: a vector of the distances of each data sample to the center 

arg = completeArg(arg,{'dim','dist'},{1, 'norm'});
 
if arg.dim==2
    dim_feature = 1; % the 1st dimension (each column) of H is a  feature
else % arg.dim = 1 
    dim_feature = 2; % the 2nd dimensin (each row) of H is a feature 
end
     
center_v = median(H,dim_feature); % centre of the transformed samples
 
% calculate the distances of the samples to center_v 
dist_v = distMatrix(H,center_v,arg);

% calculate the threshold of an outlier:
coef_iqr = 1.5;
if isfield(arg,'prctile') && ~isempty(arg.prctile)
    thresh_outlier = prctile(dist_v,arg.prctile);
elseif isfield(arg,'iqr') && ~isempty(arg.iqr)
    %    threshold = 75% quartile + 1.5* interquartile range 
    thresh_outlier = prctile(dist_v,75) +  arg.iqr * iqr(dist_v);
else    
    thresh_outlier = prctile(dist_v,75) +  coef_iqr * iqr(dist_v);
end