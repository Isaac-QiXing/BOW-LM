function [isOutlier_v,dist_v] = isOutlier(H_temp, arg)
% Identify ouliers based on the given center point
% Inputs:  
%  H_temp: data matrix, each row or column is a record
%  arg: an optional struct of parameters 
%  arg.dim:  
%       1: each column of H_temp is a record
%       2: each row of H_temp is a record
%  arg.center: a  vector with the same number of features in H_temp, the center point
%  arg.thresh: a positive scalar, a record is identified as an oulier if its distance 
%       to the center point is greater than arg.thresh
%  arg.dist: 
%       'norm': use 2-norm to measure the distance of two records
%       'norm1': use 1-norm ot measure the distance of two records
% Outputs: 
%  is_outlier_v: a logical vector with the length of the number of sample records,
%       indicating whether the corresponding record is an outlier
%  dist_v: a vector of the distances of each data sample to the center  

debug_on = 0;
% get default parameters of arg
if nargin<=1
    arg = struct();
end
arg = completeArg(arg,{'dim','thresh','center','dist'},{1,[],[],'norm'});
if debug_on
    fwritef(1,'thresh',arg.thresh,'%f','isempty_center',int8(isempty(arg.center)),'');
end
if isempty(arg.thresh)  || isempty(arg.center)
    arg.iqr = 1.5;
    [ center_v, thresh] = getThresh_outlier(H_temp,arg);
    arg = completeArg(arg,{'thresh','center'},{thresh,center_v});
end

if isvector(H_temp)   % only one sample   in H_temp
    switch lower(arg.dist)
        case 'norm1'
            dist_v = norm(H_temp-arg.center,1);
        otherwise % 2- norm
            dist_v = norm(H_temp-arg.center,2);
    end
else
    if arg.dim == 1
        arg.center = columnVec(arg.center);
    else
        arg.center = rowVec(arg.center);
    end
    dist_v = distMatrix(H_temp,arg.center,arg);
end
isOutlier_v = dist_v >= arg.thresh;
end