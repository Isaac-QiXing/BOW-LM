function isOutlier_v = isOutlierNumber(x_v,varargin)
% find outliers in a vector
% Inputs:
%   x_v: a vector of numbers
%   varargin{1}: r, a positive scalar, default value = 1.5
%       a number x is identified as an outlier if
%       x >    75% quartile +   r * interquartile range
% Outputs: a logical vector with the same size as x_v,
%       indicating whether the corresponding number is an outlier

if nargin<=1
    r = 1.5;
else
    r = varargin{1};
end

thresh  = prctile(x_v,75) +   r * iqr(x_v);
isOutlier_v = x_v >=  thresh;
end