function flag = isRowVector(v)  
    flag = isvector(v)&&size(v,1)<=1;
end