function [acc_t,num_t,time_v,num_outlier_t] = k_BWOSELM(X,Y,model,rule,rule_addin)
% Budgeted weighting online learning algorithm  
% Argument Inputs
%         X: inputs of samples
%         Y: output of samples
%   model: struct of parameters, with the following fields
%       .cleanPeriod: an integer indicating the period of training samples to excute CLEAN
%          operation
%       .para:  nHiddenNeurons
%       .block: Size of block of data learned in each step, i.e. chunk's scale
%       .C:  a positive real number indicating the weight of the losses; 
%       .repeat: number of repeat times
%       .parfor: 1 or 0, whether employ parfor mode for repeat
%       .gcp_delete: optional, 1 or 0, whether close parpool after
%           repeating, default 1; 
%       .noiseResilient:1 or 0, whether to detect and deal with outliers, default 1; 
%  
% % % %       .thresh_outlier: a parameter in (0,1), a sample (x_i,y_i) is identified as outliers 
% % % %           if  p_i >= model.thresh_outlier, 
% % % %           where p_i is the probability that (x_i,y_i) be an outlier; 
%      .iqr_outlier: a positive number, a sample is identified as an
%            outlier if its distance to the center of the active samples >=thresh_outlier,
%           thresh_outlier = prctile(dist_v,75) + model.iqr_outlier * iqr(dist_v);
%      .is_outlier_v: optional, a vector of booleans, with the same length as Y, 
%           indicating whether an instance is outlier 
%      .mode_update_w: mode to updte the weighting matrix W, 0 or 1
%          0: normal mode
%               w_ii = 1/num_P, if y_i==1;  
%               w_ii = 1/num_N, if y_i==-1;  
%          1: active online-weighted mode (proposed by Hualong Yu  TNNLS 30(4),2019)
%               w_ii = num_P/(num_P+num_N) if y_i ==-1; 
%               w_ii = num_N/(num_P+num_N) if y_i ==1; 
%
%   rule: rule to add samples in the active set
%           rule=-1: no budget maintenance strategy
%           rule=0: maximum similarity criterion
%           rule=1: forgetron
%           rule=2: maximum judgement criterion
%           rule==3: probability-based criterion
%   rule_addin: rule to select samples to add into the online training process
%        0: add the sample into training, if predicte incorrectly
%        1: add the sample into training, if predicte incorrectly, and the sample locates not
%          too near the discriminant hyperplane;
%        2: add the sample into training, if predicte incorrectly, and the sample locate
%          neither too near nor too far away from the discriminant hyperplane;
% Output
%     acc_t: struct array of accuracies in each repeat, acc_t has length == model.repeat
%     num_t: struct array of TP, TN, FP, FN number in each repeat;
%     time_v: vector of  elapsed seconds in each repeat
%     num_outlier_t: struct array of TP, TN, FP, FN, indicating the number
%       of correctly/incorrectly identified outliers
%        .TP: the correctly identified outliers
%        
%%%%     iteInf: struct of iteration information at the last repeat   
%
% Versions.
%
%   * 2020.8.4 
%     ** count the correctly/incorrectly identified  outliers
%     ** add field .is_outlier_v for the input   model
%     ** add field .C for the input   model      
%     ** add output num_outlier_t
%       
%   * 2020.2.29-3.2
%   remove the model.thresh_outlier parameter, identify outliers by based on the distance
%     to the center of the transformed samples in ``feature space''.%
%  *2020.2.8
%      ** add a paramter model.gcp_delete
%   * 2020.1.21 
%       ** revise the setting of W to deal with outliers
%       Add parameter model.noiseResilient
%   * 2019.6.21
%       ** adjust the variable setting of block_sample
%   * 2019.6.12-15 by Xijun
%      ** support model.repeat in parfor mode
%      ** add model.repeat parameter: the number of repeat times
%      **  remove the original first output parameter MODEL
%      ** the 4th input parameter RULE_ADDIN is required to set
%   * 2019.6.9 by Xijun
%       ** add rule==3: probability-based  active set update criterion
%       ** add varargin{1}: 2 or 3: probability-based  add-in rule
%       ** fix a bug of H_pool
%   * 2019.6.8 by Qi-Kai, Xijun
%       ** fix a bug of H_pool
%   * 2019.6.5 by Xi-Jun Liang
%      ** fix a bug of CLEAN operation to update the active set
%   * 2019.6.3 by Xi-Jun Liang
%       ** update active set periodically
%       ** add a new budget maintenance strategy: based on probability (to be completed)
%   * 2019.6.3 by Qi-Kai
%       ** add Input parameter rule

% debug_on = 1;
debug_on = 0;
% defaut case
if ~isfield(model,'repeat') || isempty(model.repeat)
    model.repeat = 1;
end
% if ~isfield(model,'parfor') || isempty(model.parfor)
%     model.parfor = 1; % model.repeat>=2;
% end

model = completeArg(model,{'parfor','gcp_delete'},{1,1});

% if ~isfield(model,'maxSV') || isempty(model.maxSV)
%     model.maxSV = 800;
% end

Y = double(int32(Y));
if nnz(Y==1) + nnz(Y==-1)<length(Y)
    error('The labels Y should be either 1 or -1.');
end

time_v = zeros(1,model.repeat);
if model.repeat==1
    model.reset = 1;
    tic 
    [iteInf0] = k_BWOSELM_0(X,Y,model,rule,rule_addin);
    prob_outlier = iteInf0.prob_outlier;
    [acc_t,num_t]= accuracyIndex_0(iteInf0.pred,Y);
    time_v(1) = toc; 
    if debug_on
        saveData('temp20190619_repeat1.mat','pred',iteInf0.pred,'Y',Y,'iteInf',iteInf0);        
    end 
    if isfield(model,'is_outlier_v') && ~isempty(prob_outlier)
            % calculate the number of identified outliers    
            is_outlier_v = model.is_outlier_v;
%             is_outlier_v = is_outlier_v * 1.0; 
%             is_outlier_v(~is_outlier_v) = -1;            
%              
%             % set pred_is_outlier_v: 1: prediced as outlier; -1: normal instance
%             pred_is_outlier_v = ones(size(prob_outlier))*(-1); 
%             pred_is_outlier_v((prob_outlier*1.0)>0.5) = 1; 
%             [~,num_outlier_t]=accuracyIndex_0(pred_is_outlier_v,is_outlier_v);          
            true_outlier_v = -1*ones(size(model.is_outlier_v));
            true_outlier_v(model.is_outlier_v) = 1;
            % set pred_is_outlier_v: 1: prediced as outlier; -1: normal instance
            pred_is_outlier_v = ones(size(prob_outlier))*(-1);
            pred_is_outlier_v((prob_outlier*1.0)>0.5) = 1;
            [~,num_outlier_t  ]=accuracyIndex_0(pred_is_outlier_v,true_outlier_v);
    end
    return
end

%n_file = 100;

% 1. split files

n_sample  = length(Y);
%n_file = min( ceil(n_sample/100),n_file);

%block_sample = ceil(n_sample/n_file);
block_sample = 1000; 
block_sample = max(min(n_sample,block_sample),ceil(n_sample/100));

if isfield(model,'maxSV') && ~isempty(model.maxSV)
    n_train_initial = min(model.maxSV,n_sample);% number of training samples to train a initial solution
    block_sample = max(block_sample,n_train_initial);
end
n_file = ceil(n_sample/block_sample);

if isfield(model,'verbose')&&model.verbose
    fwritef(1,'n_file',n_file,'');
end

% 1.1 file names
pathstr = './data_temp/';
file_c = cell(1,n_file);
stamp = datestr(now,30);
for ii=1:n_file
    file_c{ii}= sprintf('%sdata_split_sample_%d_%s_%s' ,pathstr,n_sample, stamp, num2str(ii,'%4d'));
end
fileY = sprintf('%sdata_split_sample_%d_%s_Y' ,pathstr,n_sample, stamp);  %name of file to save Y

if ~exist(pathstr,'dir')
    mkdir(pathstr);
end

% 1.2 save the splitted data to  files
for ii=1:n_file
    ind_start = block_sample * (ii-1)+1;
    ind_end =  min(block_sample * ii, n_sample);
    ind_v = ind_start:ind_end;
    fileName = file_c{ii};
    saveData(fileName,'X',X(ind_v,:),'Y',Y(ind_v));
end
% save the variable Y
if isfield(model,'is_outlier_v') 
    saveData(fileY,'Y',Y,'is_outlier_v',model.is_outlier_v);
else
    save(fileY,'Y');
end

% 1.3 clear variables X ,Y
clear('X','Y');

if model.parfor
    if isempty(gcp('nocreate'))
        parpool;
    end
elseif model.gcp_delete
    if ~isempty(gcp('nocreate'))
        delete(gcp('nocreate'))
    end
end

% 2. train the model and repeat multiple times  in parfor mode
if model.repeat >1
    model.IW = [];
    model.Bias = [];
end

if model.parfor
    parfor i_repeat = 1:model.repeat
        tStart=tic;
        model_i = model;
        for i_file = 1:n_file
            fileName = file_c{i_file};
            dt = load(fileName);
            if i_file ==1
                model_i.reset = 1;
            else
                model_i.reset = 0;
            end
            
            [iteInf] = k_BWOSELM_0(dt.X,dt.Y,model_i,rule,rule_addin);
            pred_v = iteInf.pred;
            prob_outlier = iteInf.prob_outlier; 
            % calculate accuracy
            %[acc(i_file),num(i_file)]= accuracyIndex_0(iteInf.pred,Y(1:iteInf.n_receive));
        end
        t = toc(tStart);
        % calculate accuracy
        %dt = load(fileY,'Y');
        dt = load(fileY);
        [acc_t(i_repeat),num_t(i_repeat)]= accuracyIndex_0(pred_v,dt.Y);
        time_v(i_repeat) = t;
           % count the number of correctly/incorrectly identified outliers
        %%%num_outlier_t = struct(); 
        if isfield(dt,'is_outlier_v') && ~isempty(prob_outlier)
            % calculate the number of identified outliers   
            true_outlier_v = -1*ones(size(dt.is_outlier_v));
            true_outlier_v(dt.is_outlier_v) = 1;
            % set pred_is_outlier_v: 1: prediced as outlier; -1: normal instance
            pred_is_outlier_v = ones(size(prob_outlier))*(-1);
            pred_is_outlier_v((prob_outlier*1.0)>0.5) = 1;
            [~,num_outlier_t(i_repeat) ]=accuracyIndex_0(pred_is_outlier_v,true_outlier_v);
        end
        fprintf(1,'=');
    end
    
else
    for i_repeat = 1:model.repeat
        tStart=tic;
        model_i = model;
        for i_file = 1:n_file
            fileName = file_c{i_file};
            dt = load(fileName);
            if i_file ==1
                model_i.reset = 1;
            else
                model_i.reset = 0;
            end
            
            [iteInf] = k_BWOSELM_0(dt.X,dt.Y,model_i,rule,rule_addin);
            pred_v = iteInf.pred;
            prob_outlier = iteInf.prob_outlier;
            % calculate accuracy
            %[acc(i_file),num(i_file)]= accuracyIndex_0(iteInf.pred,Y(1:iteInf.n_receive));
        end
        t = toc(tStart);
        % calculate accuracy
        %%%dt = load(fileY,'Y');
        dt = load(fileY);
        if debug_on            
            saveData('temp20190619_repeat2.mat','pred',pred_v,'dt',dt,'iteInf',iteInf);        
        end
        [acc_t(i_repeat),num_t(i_repeat)]= accuracyIndex_0(pred_v,dt.Y);
        time_v(i_repeat) = t; 
        % count the number of correctly/incorrectly identified outliers
        %%%num_outlier_t = struct(); 
        if isfield(dt,'is_outlier_v') && ~isempty(prob_outlier)
            % calculate the number of identified outliers            
%             dt.is_outlier_v(~dt.is_outlier_v) = -1; 
%             dt.is_outlier_v = dt.is_outlier_v * 1.0; 
%             % set pred_is_outlier_v: 1: prediced as outlier; -1: normal instance
%             pred_is_outlier_v = ones(size(dt.is_outlier_v))*(-1); 
%             pred_is_outlier_v((prob_outlier*1.0)>0.5) = 1; 
%             [~,num_outlier_t(i_repeat)]=accuracyIndex_0(pred_is_outlier_v,dt.is_outlier_v);    
            true_outlier_v = -1*ones(size(dt.is_outlier_v));
            true_outlier_v(dt.is_outlier_v) = 1;
            % set pred_is_outlier_v: 1: prediced as outlier; -1: normal instance
            pred_is_outlier_v = ones(size(prob_outlier))*(-1);
            pred_is_outlier_v((prob_outlier*1.0)>0.5) = 1;
            [~,num_outlier_t(i_repeat) ]=accuracyIndex_0(pred_is_outlier_v,true_outlier_v);
        end
        fprintf(1,'=');
    end
end


fprintf(1,'\n');

if ~isempty(gcp('nocreate')) && model.gcp_delete
    delete(gcp('nocreate'));
end
 

% 3. clear the files
for ii=1:n_file
    fileName = file_c{ii};
    if exist(fileName,'file')
        delete(fileName);
    end
end
if exist(fileY,'file')
    delete(fileY);
end
% if exist(pathstr)
%     rmdir(pathstr)
% end

end