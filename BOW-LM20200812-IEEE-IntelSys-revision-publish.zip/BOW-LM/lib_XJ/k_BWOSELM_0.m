function [iteInf,model_out] = k_BWOSELM_0(X,Y,model,rule,varargin)
% Budgeted weighted online training algorithm of ELM
% Inputs
%   X: inputs of samples
%   Y: output of samples
%   model: struct of parameters, with the following fields
%       .cleanPeriod: an integer indicating the period of training samples to excute CLEAN
%          operation
%       .para:  nHiddenNeurons%
%       .block: Size of block of data learned in each step, i.e. chunk's scale
%       .C:  a positive real number indicating the weight of the losses; 
%       .reset: 1 or 0, whether reset the parsistent variables
%       .batchUpdate: 0 or a positive number, indicating the period to update the solution by the samples in the
%           active set in  ``batch'' mode, default value 0 (do not execute batch update); effective
%           when RULE = 0, 1, 2 or 3;
%       .classPrior: a scalar in (0,0.5] indicating the expected ratio of postive samples (or
%           the negative samples) in active set, effective when the RULE =  3
%           default value = 0.3;
%       .noiseResilient:1 or 0, whether to detect and deal with outliers, default 1;
% % %       .thresh_outlier: a parameter in (0,1), a sample (x_i,y_i) is identified as outliers
% % %           if  p_i >= model.thresh_outlier,
% % %           where p_i is the probability that (x_i,y_i) be an outlier;
%      .iqr_outlier: a positive number, a sample is identified as an
%           outlier if its distance to the center of the active samples >=thresh_outlier,
%           thresh_outlier = prctile(dist_v,75) + model.iqr_outlier * iqr(dist_v);
%      .mode_update_w: optional, mode to updte the weighting matrix W, 0 or 1
%          0: normal mode
%               w_ii = 1/num_P, if y_i==1;  
%               w_ii = 1/num_N, if y_i==-1;  
%          1: active online-weighted mode (proposed by Hualong Yu  TNNLS 30(4),2019)
%               w_ii = num_P/(num_P+num_N) if y_i ==-1; 
%               w_ii = num_N/(num_P+num_N) if y_i ==1; 
%  rule=-1: no budget maintenance strategy
%  rule=0: maximum similarity criterion
%  rule=1: forgetron
%  rule=2: maximum judgement criterion
%  rule==3: probability-based criterion
%     varargin{1}: rule to select samples to add into the online training process
%       0: add the sample into training, if predicte incorrectly
%       1: add the sample into training, if predicte incorrectly, and the sample locates not
%          too near the discriminant hyperplane;
%       2: add the sample into training, if predicte incorrectly, and the sample locate
%          neither too near nor too far away from the discriminant hyperplane;
% Output
%  iteInf: struct of iterate information
%    .numP: number of positives
%    .numN: number of negatives
%    .pred: vector of predicted discriminant function values
%    .n_receive: number of received samples
%    .n_train:  number of samples that add into the training process 
%    .arg_outlier: struct, parameter for detecting the outliers 
%    .prob_outlier: vector, with length = .n_receive, indicating the
%        probabilities that  an instance is  outlier      
% Versions. 
%   * 2020.8
%     * count the number of identified outliers
%     * add an alternative mode to calcuate the weighting matrix W 
%   * 2020.2.29-3.2
%   remove the model.thresh_outlier parameter, identify outliers by based on the distance
%     to the center of the transformed samples in ``feature space''.%
%   * 2020.1.21
%       ** revise the setting of W to deal with outliers
%       Add parameter model.noiseResilient
%   * 2019.6.22
%       ** add a parameter model.batchUpdate: periodically calculate the solution in batch-mode
%       ** add a parameter model.classPrior: refine the active set maintain strategy
%   * 2019.6.12 by Xijun
%       ** revised a function to be called by k_BWOSELM()
%       ** this version fits for training by samples in multiple data files
%   * 2019.6.9 by Xijun
%       ** add rule==3: probability-based  active set update criterion
%       ** add varargin{1}: 2 or 3: probability-based  add-in rule
%       ** fix a bug of H_pool
%   * 2019.6.8 by Qi-Kai, Xijun
%       ** fix a bug of H_pool
%   * 2019.6.5 by Xi-Jun Liang
%      ** fix a bug of CLEAN operation to update the active set
%   * 2019.6.3 by Xi-Jun Liang
%       ** update active set periodically
%       ** add a new budget maintenance strategy: based on probability (to be completed)
%   * 2019.6.3 by Qi-Kai
%       ** add Input parameter rule

persistent model_p par_p   act_p  iteInf_p
% model_p: struct of iterated model
%   .alpha: vector of coefficients
%   .M: matrix K^(-1)
%   .IW
%   .Bias
% par_p: iterated state variables
%   .numP: number of positives
%   .numN: number of negatives
%   .pred: vector of predicted discriminant function values
%   .... : many other state variables
% act_p: struct of active set variables
%  .S: indices of the active set
%  .X: matrix of the samples of the active  set
%  .Y: vector of the lables of the active  set
%  .H:  matrix corresponding samples in the active set
% iteInf_p: struct of iterate information
%  .acc: a struct array of the accuracies in each call of this function;
%  .n_train: a vector of the numbers of samples that adds into the training process



debug_on = 0;
debug_temp = [];

if nargin>=5
    rule_addin = varargin{1};
else
    rule_addin = 0;
end

if ~isfield(model,'verbose')|| isempty(model.verbose)
    model.verbose=0;
end

if isfield(model,'iter')==0
    model.iter=0;
end
if ~isfield(model,'mode_update_w')|| isempty(model.mode_update_w)
    model.mode_update_w=0;
end

% % % if isfield(model,'type')==0
% % %     model.type=1;
% % % end
% % % if isfield(model,'nu')==0
% % %     model.nu=1;
% % % end


if isfield(model,'para')==0  % nHiddenNeurons
    model.para=50;
end
if ~isfield(model,'C')   % nHiddenNeurons
    model.C=2^(-10);
end

nHiddenNeurons =model.para;
[n_sample,InputDim] = size(X);
 
if ~isfield(model,'maxSV') || isempty(model.maxSV)
    model.maxSV = 800;
end
model.maxSV = min(model.maxSV,length(Y));

if isfield(model,'block')==0  %
    model.block=100;
end
model.block=min(ceil(model.maxSV/4),model.block);

if ~isfield(model,'cleanPeriod') || isempty(model.cleanPeriod)
    model.cleanPeriod = 400;
end
model.cleanPeriod = min(model.cleanPeriod, ceil(model.maxSV/4));
% ensure model.cleanPeriod + model.block < model.maxSV (active set size )
 
% [n_sample,InputDim] = size(X);
if ~isfield(model,'kerparam') || isempty(model.kerparam)
    model.kerparam =struct('type','rbf','gamma',1/InputDim);
end
if ~isfield(model,'ker') || isempty(model.ker)
    model.ker = @compute_kernel;
end
if ~isfield(model,'noiseResilient') || isempty(model.noiseResilient)
    model.noiseResilient = 1;
end
 
if ~isfield(model,'iqr_outlier') || isempty(model.iqr_outlier)
    model.iqr_outlier = 3.0;
end



% other parameters
if length(Y)<1000
    update_addin_thresh_period = 10;
    % period of receid samples to update parameters for addin_rule==1 or 2 and rule ==3
else
    update_addin_thresh_period = min(200,ceil(length(Y)/100));
end

if ~isfield(model,'batchUpdate') || isempty(model.batchUpdate)
    model.batchUpdate = 0;
end
if ~isfield(model,'classPrior') || isempty(model.classPrior)
    model.classPrior = 0.18;
end



if length(Y)~=n_sample
    error('the number of rows of X should equal to the length of Y.');
end
% nHiddenNeurons =model.para;
ActivationFunction = 'sig';

 

% 0 initialization
if isfield(model,'reset')&& model.reset
    model_p = [];
    act_p = [];
    par_p = [];
    iteInf_p = [];
    if model.verbose>=2
        fprintf(1,'persistent variables have been reset.\n');
    end
end
if isempty(model_p)
    % 0.0 initialize the persistent variables
    model_p = struct('alphab',[],'M',[],'IW',[],'Bias',[]);
    act_p = struct('S',[],'X',[],'Y',[],'H',[],'w',[]); % struct of active set variables
    %     par_p = struct('numP',[],'numN',[],'pred',[],'prob',[]); % par_p: iterated state variables
    % 0.1 initialize active set
    act_p.S = 1:model.maxSV; % act_p.S: indices of the samples in the active set
    act_p.X =  X(act_p.S,:);
    act_p.Y =  Y(act_p.S);
    
    % 0.2 initialize the  weighting matrix  W
    par_p.numP=nnz(act_p.Y==1);  % number of positive samples in the active set
    par_p.numN=nnz(act_p.Y==-1); % number of negative samples in the active set  
    
    W0 = getW(act_p.Y,par_p.numP,par_p.numN,model.mode_update_w);
    act_p.w  = diag(W0);
    % 0.3 set the parameters w_i randomly
    if isfield(model,'IW') && ~isempty(model.IW)
        model_p.IW = model.IW ;
    else
        model_p.IW = rand(nHiddenNeurons,InputDim)*2-1;
    end
    if isfield(model,'Bias') && ~isempty(model.Bias)
        model_p.Bias = model.Bias;
    else
        model_p.Bias= rand(1,nHiddenNeurons)*2-1;
    end
    
    if debug_on
        fwritef(1,'model_p.IW(1:3)',rowVec(model_p.IW(1:3,1)),'','W0(1)',(W0(1)),'');
    end
    % 0.4 set model_p.Bias, calculate act_p.H
    % size of act_p.H: N0-by-nHiddenNeurons, N0 ==length(act_p.S) : the active set (budget) size
    switch lower(ActivationFunction)
        case{'rbf'}
            %             model_p.Bias = rand(1,nHiddenNeurons);
            act_p.H = RBFun(act_p.X,model_p.IW ,model_p.Bias);
        case{'sig'}
            %             model_p.Bias = rand(1,nHiddenNeurons)*2-1;
            act_p.H= SigActFun(act_p.X,model_p.IW ,model_p.Bias);
        case{'sin'}
            %             model_p.Bias = rand(1,nHiddenNeurons)*2-1;
            act_p.H = SinActFun(act_p.X,model_p.IW ,model_p.Bias);
        case{'hardlim'}
            %             model_p.Bias = rand(1,nHiddenNeurons)*2-1;
            act_p.H = HardlimActFun(act_p.X,model_p.IW ,model_p.Bias);
            act_p.H = double(act_p.H);
    end 
    
    % 0.5 calculate model_p.M, model_p.alphab
    H_t = act_p.H';
    %%%model_p.M = pinv(H_t*W0*act_p.H + eye(nHiddenNeurons)/2^20);
    model_p.M = pinv(H_t*W0*act_p.H + eye(nHiddenNeurons)*model.C);
    model_p.alphab =model_p.M* (H_t * (W0* act_p.Y));
    
    % 0.6 initialize par_p.pred, par_p.prob
    par_p.pred = zeros(n_sample,1);
    pred_initial_v =act_p.H*model_p.alphab;
    par_p.pred(1:length(act_p.Y)) =    pred_initial_v;
    if model.noiseResilient
        % calculate par_p.prob_outlier
        arg_outlier.dim = 2; % each row of H is a record
        arg_outlier.iqr = model.iqr_outlier; 
        arg_outlier.dist = 'norm1'; 
        [arg_outlier.center,arg_outlier.thresh] = getThresh_outlier(1./act_p.H,arg_outlier);        
        par_p.arg_outlier = arg_outlier; 
        par_p.prob_outlier=zeros(n_sample,1);
        par_p.prob_outlier(1:length(act_p.Y)) = isOutlier(1./act_p.H, arg_outlier);
    else
        par_p.prob_outlier=[];
    end
    
    % 0.7 initialize parameters of the active set update rules and addin rules
    %if rule==3
    par_p.pi_neg = 1.0;
    par_p.pi_pos = 1.0;
    par_p.npos = 0;
    par_p.nneg = 0;
    %end
    %if rule_addin==1 || rule_addin==2 % probability-based add-in rule
    par_p.pu_pos = 1.0;
    par_p.pl_pos = 0;
    par_p.pu_neg = 1.0;
    par_p.pl_neg = 0;
    %end
    %if (rule_addin==1 || rule_addin==2)
    par_p.p_maxpos = 0;
    par_p.p_minpos = 1.0;
    par_p.p_sumpos = 0.0;
    par_p.p_meanpos = 0;
    par_p.p_maxneg = 0;
    par_p.p_minneg = 1.0;
    par_p.p_sumneg = 0.0;
    par_p.p_meanneg = 0;
    par_p.n_wrongpos = 0 ;
    par_p.n_wrongneg = 0 ;
    %end
    par_p.arg_prob = struct();
    par_p.n_receive = 0;  % number of received samples
    par_p.n_train = 0;  % number of samples that add into the training process
    par_p.n_batchUpdate = 0; % number of batch update of the solution
    par_p.reachedClassPrior = 0; % whether reached specified class prior
    par_p.classPrior =   getClassPrior(); % current class prior
    par_p.rareClass = getRareClass();
    ind_start = model.maxSV+1; % start index of training
    % initialize intInf_p
    iteInf_p = struct('n_train',[]);
else % model_p has been set by prior training process
    par_p.pred = [par_p.pred; zeros(n_sample,1)]; % enlarge par_p.pred
    if model.noiseResilient
        par_p.prob_outlier= [par_p.prob_outlier; zeros(n_sample,1)];
    end
    ind_start = 1; % start index of training 
 
end

% 2. predict  procedure
ind_pool = []; % the indices of newly received samples
npos_pool = 0; % number of positive samples in the pool
nneg_pool = 0; % number of negative samples in the pool
H_pool = zeros(model.cleanPeriod+model.block,nHiddenNeurons);
% store the elements of H of the newly received samples

i_clean = 0; % number of clean operations
i_receive = 0;

prob_receive = zeros(update_addin_thresh_period + model.block,1);
pred_receive = zeros(update_addin_thresh_period + model.block,1);

if debug_on
    fwritef(1,'ind_start',ind_start,'','alphab',model_p.alphab','',...
        'model.block' ,model.block,'', 'n_sample', n_sample,'');   
end

if model.verbose>=2
    fwritef(1,'par_p.n_receive',par_p.n_receive,'');
end

for n = ind_start : model.block : n_sample
    % 2.1 receive the new block
    if (n+model.block) > n_sample
        index_temp = n:n_sample;
    else
        index_temp = n:(n+model.block-1);
    end
    index_temp_global = index_temp + par_p.n_receive; % global indices
    X_temp = X(index_temp,:);
    Y_temp = Y(index_temp);
    n_temp = length(index_temp);
    i_receive = i_receive + n_temp; % note that i_receive would be reset in the loops
    n_current = index_temp(end); %  number of curently received examples of X and Y
    % 2.2 calculate the matrix H_temp, and the discriminant function values
    % 2.2.1 calculate H_temp
    switch lower(ActivationFunction)
        case{'rbf'}
            H_temp = RBFun(X_temp,model_p.IW,model_p.Bias);
        case{'sig'}
            H_temp = SigActFun(X_temp,model_p.IW,model_p.Bias);
        case{'sin'}
            H_temp = SinActFun(X_temp,model_p.IW,model_p.Bias);
        case{'hardlim'}
            H_temp = HardlimActFun(X_temp,model_p.IW,model_p.Bias);
    end
    % 2.2.2 calculate the discriminant function values
    output_temp = H_temp*model_p.alphab;
    par_p.pred(index_temp_global) = output_temp;
    pred_receive(i_receive-n_temp+1:i_receive) = output_temp;
    % pred_receive: predicted function values of examples received recently
    
    % 2.2.3 calculate the probabilities P(y_i=1|x)
    if  rule ==3 || rule_addin==1 || rule_addin==2  % rule = 3: clean rule is the probability based rule
        [prob_temp, ~,par_p.arg_prob] = fval2prob(output_temp,Y_temp,par_p.arg_prob);
        prob_receive(i_receive-n_temp+1:i_receive) = prob_temp;
        % prob_receive: probabilities P(y=1|x) of examples received recently
    end
    % 2.3 determine the indices to be added into the active set
    i_incorrect = Y_temp~=sign(output_temp);
    i_candidate = i_incorrect;
    
    % identify and exclude outliers
    if  model.noiseResilient
        %isOutlier_temp_v = isOutlier(H_temp,act_p.center,act_p.thresh_outlier);
        isOutlier_temp_v = isOutlier(1./H_temp,par_p.arg_outlier); 
        par_p.prob_outlier(index_temp_global) =   isOutlier_temp_v;
        i_candidate = i_candidate & ~isOutlier_temp_v;
        % do  not  update act_p.center,act_p.thresh_outlier 
% % %         if nnz(mod(index_temp,period_update_H_center) == 1)>0
% % %             [act_p.center,act_p.thresh_outlier]  = getThresh_outlier(act_p.H,model.iqr_outlier);
% % %             if model.verbose>=3
% % %                 fwritef(1,'thesh_outlier',act_p.thresh_outlier ,'');
% % %             end
% % %         end
    end  
    
    if rule == 3 && model.classPrior>0 && par_p.classPrior < model.classPrior %%&& ~par_p.reachedClassPrior
        i_candidate = (Y_temp == par_p.rareClass)| i_incorrect;
    elseif  rule == 3 && model.classPrior>0 && par_p.classPrior >= model.classPrior
        par_p.reachedClassPrior = 1;
    end
    
    if nnz(i_candidate)==0
        continue
    end
    
    if rule_addin==0
        addin_index = index_temp(i_candidate);
        i_act = i_candidate;
    else
        if rule_addin==1        
            i_act =  i_candidate & ( (Y_temp==1 & prob_temp < par_p.pu_pos) | (Y_temp==-1 & prob_temp > par_p.pl_neg));
        else % rule_addin==2
            i_act =  i_candidate & ( (Y_temp==1 & prob_temp > par_p.pl_pos & prob_temp < par_p.pu_pos ) ...
                | (Y_temp==-1   & prob_temp > par_p.pl_neg & prob_temp < par_p.pu_neg));
        end
        addin_index = index_temp(i_act);
    end
    
    if isempty(addin_index)
        continue
    end
    
    % 2.3.1 update par_p.pu_pos, par_p.pl_pos, par_p.pu_neg , par_p.pl_neg (for rule_addin==1 or 2),
    %   par_p.pi_pos, par_p.pi_neg (for rule==3) periodically
    if (rule_addin==1 || rule_addin==2 || rule ==3 ) && i_receive>= update_addin_thresh_period
        % rule_addin ==1 or 2: probability-based budget maintain strategy
        %   rule ==3: add-in rule: probability-based rule
        
        ind_new_receive = n_current-i_receive+1:n_current; % indices of newly receive examples
        % length(ind_new_receive) == i_receive
        % update par_p.pi_pos, par_p.pi_neg (for rule==3) periodically
        if rule ==3
            par_p.npos = par_p.npos + nnz(Y(ind_new_receive)==1);
            par_p.nneg = par_p.nneg + nnz(Y(ind_new_receive)==-1);
            ratio_pos = par_p.npos/(par_p.npos+par_p.nneg);
            ratio_neg = 1-ratio_pos;
            ratio_mean = sqrt(ratio_pos*ratio_neg); % note that ratio_mean<=0.5
            if ratio_pos <=ratio_neg
                par_p.pi_pos = max(1E-10,ratio_mean);
            else
                par_p.pi_pos = 1-ratio_mean;
            end
            par_p.pi_neg = 1-par_p.pi_pos;
            if model.verbose>=4
                fprintf(1,'----\n');
                fwritef(1,'n_current',n_current,'','par_p.pi_pos',par_p.pi_pos,'');
                %fwritef(1,'par_p.npos',par_p.npos,'','par_p.nneg',par_p.nneg,'');
                fwritef(1, 'nnz(act_p.Y==1)',nnz(act_p.Y==1),''); %,'nnz(act_p.Y==-1)',nnz(act_p.Y==-1),'');
                fwritef(1, 'ratio_pos_act',nnz(act_p.Y==1)/(length(act_p.Y)),'');
                %fwritef(1,'arg_prob',par_p.arg_prob,'');
            end
        end
        % update par_p.pu_pos, par_p.pl_pos, par_p.pu_neg , par_p.pl_neg (for rule_addin==1 or 2)
        if (rule_addin==1 || rule_addin==2)
            is_incorrect_pos = pred_receive(1:i_receive) < 0 & Y(ind_new_receive)==1;
            is_incorrect_neg = pred_receive(1:i_receive) > 0 & Y(ind_new_receive)==-1;
        
            prob_receive_2 = prob_receive(1:i_receive);
            if  nnz(is_incorrect_pos)>0
                par_p.p_maxpos =  max(par_p.p_maxpos,max(prob_receive_2(is_incorrect_pos)));
                par_p.p_minpos =  min(par_p.p_minpos,min(prob_receive_2(is_incorrect_pos)));
                par_p.p_sumpos =  par_p.p_sumpos +   sum(prob_receive_2(is_incorrect_pos));
                par_p.n_wrongpos = par_p.n_wrongpos +  length(is_incorrect_pos);
                par_p.p_meanpos = par_p.p_sumpos/par_p.n_wrongpos;
            end
            if  nnz(is_incorrect_neg)>0
                par_p.p_maxneg =  max(par_p.p_maxneg,max(prob_receive_2(is_incorrect_neg)));
                par_p.p_minneg =  min(par_p.p_minneg,min(prob_receive_2(is_incorrect_neg)));
                par_p.p_sumneg =  par_p.p_sumneg +   sum(prob_receive_2(is_incorrect_neg));
                par_p.n_wrongneg = par_p.n_wrongneg +  length(is_incorrect_neg);
                par_p.p_meanneg = par_p.p_sumneg/par_p.n_wrongneg;
            end
            par_p.pu_pos = 0.9  *par_p.p_maxpos + 0.1 * par_p.p_meanpos;
            par_p.pu_neg = 0.95 *par_p.p_maxneg + 0.05 * par_p.p_meanneg;
            par_p.pl_pos = 0.95 *par_p.p_minpos + 0.05 * par_p.p_meanpos;
            par_p.pl_neg = 0.9  *par_p.p_minneg + 0.1 * par_p.p_meanneg;
           
        end % end rule_addin==1 || rule_add
        i_receive = 0; % reset i_receive
    end
    
    % update ind_pool
    addin_num = length(addin_index);
    ind_pool = [ind_pool addin_index]; % indices of the received samples in the pool
    n_pool = length(ind_pool);  % n_pool: current length of the pool
    par_p.n_train=par_p.n_train+addin_num;
    
    % 2.3.2 update par_p.numP, par_p.numN
    if rule==-1
        par_p.numP=par_p.numP+ nnz(Y(addin_index)==1);
        par_p.numN=par_p.numN+ nnz(Y(addin_index)==-1);
    end
    % 2.3.3 calculate W1
    W1 = getW(Y(addin_index),par_p.numP,par_p.numN,model.mode_update_w);
    
    % 2.4  update model_p.M and the solution
    % calculate H
    H =  H_temp(i_act,:);
    if rule~=-1 % 0,1,2 or 3
        H_pool(n_pool-length(addin_index)+1:n_pool,:) = H; % save the elements of H into matrix H_pool
    end
    % update M
    M_times_Ht = model_p.M * H'; % note that M is a symmetic matrix
    model_p.M = model_p.M - M_times_Ht* (W1 + H * M_times_Ht)^(-1) * M_times_Ht';
    %model_p.M = model_p.M - model_p.M * H'* (W1 + H * model_p.M * H')^(-1) * H * model_p.M;
    
    model_p.alphab = model_p.alphab + model_p.M * (H' * W1 * (Y(addin_index) - output_temp(i_act)));
    % model_p.alphab = model_p.alphab + model_p.M * H' * W1 * (Y(addin_index) - H * model_p.alphab);
    
    if debug_on
        fwritef(1,'n',n,'','alphab(1:3)',model_p.alphab(1:3)','','addin_index',addin_index,'');
    end
    
    % 2.5 clean the active set periodically
    if rule~=-1 && n_pool >= model.cleanPeriod    % rule = 0, 1, 2 or 3
        i_clean = i_clean +1;
        % 2.5.1 determine the indices (saved in cut_index) to be removed   the active set
        %  not that cut_index has length N_POOL
        n_active = length(act_p.S);
        if n_pool>=n_active
            error('Improper setting of the block size, clean period or the budget size.');
        end
        if rule==0 % maximum similarity criterion
            K_active = feval(model.ker,X(ind_pool,:)',act_p.X',model.kerparam);
            cut_index = zeros(1,n_pool); %indices of the elements in act_p.S
            ind_act =  1:n_active ;
            % find the maximum k similarities
            for kk =1:n_pool % n_pool < n_active
                [~,ii_max] = max(K_active(kk,ind_act));
                i_max = ind_act(ii_max);
                cut_index(kk) = i_max;  % set cut_index: the indices to be removed from the active set
                ind_act(ii_max) = [];
            end
        elseif rule==1 % forgotron
            cut_index=1:n_pool;
        elseif rule==2 % maximum judgement criterion
            f_active = act_p.Y.*(act_p.H*model_p.alphab);  % f_active has length == length(act_p.S)
            % find the largest k lements of f_active
            [~,ind_f] = sort(f_active,'descend');
            cut_index = ind_f(1:n_pool);
        elseif rule==3 % probability-based criterion
            % calculate the probability of P(y_i = 1 |x_i) of the samples in the active set
            f_active = act_p.Y.*(act_p.H*model_p.alphab);  % f_active
            arg_clean = par_p.arg_prob;
            arg_clean.f_old = f_active;
            [~, prob_active] = fval2prob([],[],arg_clean);
            % set the probabilty distribution to select samples to remove from the active set
            prob_recast = prob_active;
            % set the selection rate  of positive and negative samples to remove
            if par_p.classPrior < model.classPrior
                p_pos = par_p.pi_pos;
                p_neg = par_p.pi_neg;
            else
                n_pos_pool = max(1,nnz(Y(ind_pool)==1));
                n_neg_pool = max(1,nnz(Y(ind_pool)==-1));
                p_pos = min(n_pos_pool/par_p.numP,1.0);
                p_neg = min(n_neg_pool/par_p.numN,1.0);
            end
            prob_recast(act_p.Y==1) =   prob_active(act_p.Y==1)*p_pos;
            prob_recast(act_p.Y==-1) = (1- prob_active(act_p.Y==-1))*p_neg;
            prob_recast = prob_recast ./sum(abs(prob_recast)); % normalization
            
            % determine the indices to be removed from the active set
           
            cut_index =  mnrnd_unique(n_pool,prob_recast);
            
            if model.verbose>=4
                fwritef(1,'n_cut_act_p.Y==1', nnz(act_p.Y(cut_index)==1) ,'',...
                    'n_cut_act_p.Y==-1', nnz(act_p.Y(cut_index)==-1),'' );
            end
        end
        
        
        % 2.5.2 update model_p.M and the solution
        for jj = 1: length(cut_index) %  removing one sample each time
            i_cut = cut_index(jj);
            yi = act_p.Y(i_cut); %%Y(act_p.S(i_cut));
            % cut_index consists of some indices in {1,...,N0}, N0 is the budget size
            H = act_p.H(i_cut,:);
            W1 = getW(yi,par_p.numP,par_p.numN,model.mode_update_w);
            M_times_Ht = model_p.M * H';
            model_p.M = model_p.M + M_times_Ht * (W1 - H * M_times_Ht)^(-1) * M_times_Ht';
            model_p.alphab = model_p.alphab - model_p.M *( H' * W1 * (yi - H * model_p.alphab));
            %             H1 = -H';
            %             model_p.M = model_p.M - model_p.M * H1 * (W1 + H * model_p.M * H1)^(-1) * H * model_p.M;
            %             model_p.alphab = model_p.alphab + model_p.M * H1 * W1 * (yi - H * model_p.alphab);
            % % %             if debug_on
            % % %                 fwritef(1,'i_cut',i_cut,'','alphab',model_p.alphab','','W1',W1,'');
            % % %             end
        end
        
        if debug_on
            fwritef(1,'cut_index',rowVec(cut_index),'','alphab',model_p.alphab','');
        end
        % 2.5.3 update par_p.numP, par_p.numN
        par_p.numP=par_p.numP + nnz(Y(ind_pool)==1)  - nnz( act_p.Y(cut_index)==1);
        par_p.numN=par_p.numN + nnz(Y(ind_pool)==-1) - nnz( act_p.Y(cut_index)==-1);
        par_p.numP = max(1,par_p.numP);
        par_p.numN = max(1,par_p.numN);
        % 2.5.4 update act_p.H
        if rule~=1 % rule==2 || rule==0 || rule==3
            act_p.H(cut_index,:) = H_pool(1:n_pool,:);
        else% rule == 1
            act_p.H(cut_index,:) = [];
            act_p.H = [act_p.H;
                H_pool(1:n_pool,:)];
        end
        % 2.5.5 update act_p.S, act_p.X, act_p.Y
        if rule~=1 % rule==2 || rule==0  || rule ==3
            act_p.S(cut_index) = par_p.n_receive + ind_pool;
            % replace the indices of the active set with those in ind_pool
            % NOTE that the rows of matrix act_p.H should corresponds to act_p.S
            act_p.X(cut_index,:) = X(ind_pool,:);
            act_p.Y(cut_index) = Y(ind_pool);% update the matrix  X and the vector Y
        else %rule ==1 %   forgotron
            act_p.S(cut_index) = [];
            act_p.S = [act_p.S par_p.n_receive+ind_pool];
            % update the matrix  X and the vector Y
            act_p.X(cut_index,:) = [];
            act_p.X = [act_p.X
                X(ind_pool,:)];
            act_p.Y(cut_index) = [];
            act_p.Y = [act_p.Y
                Y(ind_pool)];% update the matrix  X and the vector Y
        end
        
        % 2.5.6 batch update the solution
        if model.batchUpdate &&  floor(index_temp_global(end)/model.batchUpdate )>par_p.n_batchUpdate
            alpha_v = alphaUpdate_batch();
            par_p.n_batchUpdate = par_p.n_batchUpdate + 1;
            if model.verbose>=3
                fwritef(1,'par_p.n_batchUpdate',par_p.n_batchUpdate,'');
            end
            if model.verbose>=4
                fwritef(1,'norm(model.alphab-alpha_v)',norm(model_p.alphab-alpha_v),'',...
                    'model.alphab(1:4)',rowVec(model_p.alphab(1:8)),'',...
                    'alpha_v(1:4)',rowVec(alpha_v(1:8)),''      );
            end
            model_p.alphab = alpha_v;
        end
        % 2.5.7 update state variables
        par_p.classPrior =   getClassPrior();
        par_p.rareClass = getRareClass();
        % 2.5.8
        ind_pool = []; % clean the pool
        if model.verbose>=3
            fprintf('i_clean:%d\t | |act_p.S: %d\t| par_p.numP: %d \t | par_p.numN: %d\t| par_p.classPrior: %.3f',...
                i_clean,length(act_p.S),par_p.numP,par_p.numN,par_p.classPrior);
            fprintf(1,'\n');
        end
        if model.verbose>=4
            if rule==2
                fprintf('f_cut(1): %.4f\t|',f_active(cut_index(1)));
            end
            if rule==3
                %fprintf('par_p.pi_neg: %.4f prob_recast: %.4f \t|',par_p.pi_neg, prob_recast);
                fwritef(1,'par_p.pi_neg',par_p.pi_neg,'',  'prob_active',prob_active','');
            end
        end
    end % end of the clean operation
    
end % end of the online loops

% 3. outputs

% 3.1 update state parameters
par_p.n_receive = par_p.n_receive + n_sample;  % number of received samples
iteInf_p.n_train =  [iteInf_p.n_train par_p.n_train];

iteInf = par_p;
iteInf.n_train = iteInf_p.n_train;
model_out = model_p;
 
    function alpha_v = alphaUpdate_batch()
        Ht = act_p.H';
        W0 = getW(act_p.Y,par_p.numP,par_p.numN,model.mode_update_w);         
        %%%MM =  Ht*W0*act_p.H + eye(nHiddenNeurons)/2^20;
        MM =  Ht*W0*act_p.H + eye(nHiddenNeurons)*model.C;
        alpha_v = linsolve(MM,Ht * (W0* act_p.Y));
    end
    function p = getClassPrior()
        rpos = nnz(act_p.Y==1)/length(act_p.Y);
        p = min(rpos,1-rpos);
    end
    function y_rare = getRareClass()
        % whether positive samples in the active set are less than the negative sampels
        rpos = nnz(act_p.Y==1)/length(act_p.Y);
        if rpos<0.5
            y_rare = 1;
        else
            y_rare = -1;
        end
    end

end  % end of the main function

function W1 = getW(y,num_P,num_N,varargin)
% inputs: 
%   varargin{1}: 0 or 1
%    0: normal mode
%       w_ii = 1/num_P, if y_i==1;  
%       w_ii = 1/num_N, if y_i==-1;  
%    1: active online-weighted mode (proposed by Hualong Yu  TNNLS 30(4),2019)
%       w_ii = num_P/(num_P+num_N) if y_i ==-1; 
%       w_ii = num_N/(num_P+num_N) if y_i ==1; 
    if nargin<=3
        mode = 0;
    else 
        mode = varargin{1};
    end
    addin_num =length(y);
    num_P = max(num_P,1);
    num_N = max(num_N,1);
    if mode==0        
        if addin_num==1
            if y==1
                W1 = 1/num_P;
            else
                W1 = 1/num_N;
            end
        else %addin_num> 1
            w11 = ones(addin_num,1)/num_P;
            w11(y==-1) = 1/num_N;
            W1 = diag(w11);
        end
    else % mode = 1 
        num_total = num_P + num_N; 
        num_total = num_total*num_total ; 
        if addin_num==1
            if y==1
                W1 = num_N/num_total;
            else
                W1 = num_P/num_total;
            end
        else %addin_num> 1
            w11 = ones(addin_num,1)*(num_N/num_total);
            w11(y==-1) = num_P/num_total;
            W1 = diag(w11);
        end
    end       
        
end

function prob_v = fval2prob_outlier(output_v,y_v)
% output_v: a vector of predicted function values
% y_v: a vector of the labels

t_v  = abs(output_v -y_v);
prob_v = 1./(1+exp(-t_v));

end

