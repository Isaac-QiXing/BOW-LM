function [model,acc] = k_BWOSELM(X,Y,model,rule)
% X=x;
% Y=y;
% model=model_bak;
% rule=1;
%Rank-k updating Online training algorithm of prune mechanism
%Argument Inputs
%         X: inputs of samples
%         Y: output of samples
%   model:
%       .cleanPeriod: an integer indicating the period of training samples to excute CLEAN
%          operation
%         Type: 0 for regression; 1 for classification
%         para:
%         N0: Number of initial training data, i.e. the scale of work set
%         Block: Size of block of data learned in each step, i.e. chunk's scale
%  rule=-1: no budget maintenance strategy
%  rule=0: maximum similarity criterion
%  rule=1: forgetron
%  rule=2: maximum judgement critersion
% Output
%        model.acc:  correct classification rate for classifcation
%        model.time: runing time
%        acc: struct of accuracies     
% Versions.
%   * 2019.6.8 by Qi-Kai, Xijun 
%       ** fix a bug of H_pool 
%   * 2019.6.5 by Xi-Jun Liang
%      ** fix a bug of CLEAN operation to update the active set
%   * 2019.6.3 by Xi-Jun Liang
%       ** update active set periodically
%       ** add a new budget maintenance strategy: based on probability (to be completed)
%   * 2019.6.3 by Qi-Kai
%       ** add Input parameter rule

%debug_on = 1; 
if ~isfield(model,'verbose')|| isempty(model.verbose)
    model.verbose=0;    
end


if isfield(model,'iter')==0
    model.iter=0;    
end

if isfield(model,'type')==0
    model.type=1;
end
if isfield(model,'nu')==0
    model.nu=1;
end
if isfield(model,'block')==0  % 
    model.block=1;
end
if isfield(model,'para')==0  % nHiddenNeurons
    model.para=50;
end
if isfield(model,'IW')==0
    model.IW=[];
end
if isfield(model,'Bias')==0
    model.Bias=0;
end
if isfield(model,'G')==0  %
    model.G=0;
end
if ~isfield(model,'maxSV') || isempty(model.maxSV)
    model.maxSV = 800;
end
if ~isfield(model,'cleanPeriod') || isempty(model.cleanPeriod)
    model.cleanPeriod = 400;
end
model.cleanPeriod = min(model.cleanPeriod,ceil(model.maxSV/4));

[n_sample,InputDim] = size(X);
if ~isfield(model,'kerparam') || isempty(model.kerparam)
    model.kerparam =struct('type','rbf','gamma',1/InputDim);
end
if ~isfield(model,'ker') || isempty(model.ker)
    model.ker = @compute_kernel;
end

 
if length(Y)~=n_sample
    error('the number of rows of X should equal to the length of Y.');
end
nHiddenNeurons =model.para;
ActivationFunction = 'sig';

st = cputime; 

% % % if rule==2
% % %     active_index= [1:model.maxSV];
% % % end

% 0.1 initialize active set
model.S = 1:model.maxSV; % model.S: indices of the samples in the active set
X_active =  X(model.S,:);
Y_active =  Y(model.S,:);

% 0.2 initialize the  weighting matrix  W
num_P=length(find( int32(Y_active)==1));
num_N=length(find( int32(Y_active)==-1));
w=[];
for u=1:length(Y_active)
    if Y_active(u)==1
        w(u)=1/num_P;
    else
        w(u)=1/num_N;
    end
    W0=diag(w);
end
% 0.3 set the parameters w_i randomly
model.IW = rand(nHiddenNeurons,InputDim)*2-1;

% 0.4 calculate H0
switch lower(ActivationFunction)
    case{'rbf'}
        model.Bias = rand(1,nHiddenNeurons);
        H0 = RBFun(X_active,model.IW ,model.Bias);
    case{'sig'}
        model.Bias = rand(1,nHiddenNeurons)*2-1;
        H0= SigActFun(X_active,model.IW ,model.Bias);
    case{'sin'}
        model.Bias = rand(1,nHiddenNeurons)*2-1;
        H0 = SinActFun(X_active,model.IW ,model.Bias);
    case{'hardlim'}
        model.Bias = rand(1,nHiddenNeurons)*2-1;
        H0 = HardlimActFun(X_active,model.IW ,model.Bias);
        H0 = double(H0);
end

% calculate M, model.alphab
M = pinv(H0'*W0*H0+eye(size(H0'*W0*H0))/2^20);
model.alphab =M*H0'*W0* Y_active;
% initialize pred_v
pred_v = zeros(n_sample,1);
pred_v(1:length(Y_active)) = Y_active; % ?

% 2. predict  procedure
ind_pool = []; % the indices of newly received samples
H_pool = zeros(model.cleanPeriod+model.block,nHiddenNeurons);
    % store the elements of H of the newly received samples
n_addin = 0; 
i_clean = 0; % number of clean operations
for n = model.maxSV+1 : model.block : length(Y)
    % 2.1 receive the new block    
    if (n+model.block) > length(Y)       
        index_temp = n:length(Y);
    else
        index_temp = n:(n+model.block-1);
    end
    X_temp = X(index_temp,:);
    Y_temp = Y(index_temp);
    % 2.2 calculate the matrix H, and the discriminant function values
    switch lower(ActivationFunction)
        case{'rbf'}
            H_temp = RBFun(X_temp,model.IW,model.Bias);
        case{'sig'}
            H_temp = SigActFun(X_temp,model.IW,model.Bias);
        case{'sin'}
            H_temp = SinActFun(X_temp,model.IW,model.Bias);
        case{'hardlim'}
            H_temp = HardlimActFun(X_temp,model.IW,model.Bias);
    end
    output_temp = H_temp*model.alphab;    
    pred_v(index_temp) = output_temp;
    
    % 2.3 determine the indices to be added into the active set
    i_incorrect = Y_temp~=sign(output_temp);
    
    addin_index = index_temp(Y_temp~=sign(output_temp));
    if isempty(addin_index)
        continue
    end
    addin_num = length(addin_index);
    ind_pool = [ind_pool addin_index]; % indices of the received samples in the pool 
    n_pool = length(ind_pool);  % n_pool: current length of the pool 
    n_addin=n_addin+addin_num;
    
    % 2.3.2 update num_P, num_N 
    if rule==-1
        num_P=num_P+ nnz(Y(addin_index)==1);
        num_N=num_N+ nnz(Y(addin_index)==-1);
    end
    % 2.3.3 calculate W1    
    W1 = getW(Y(addin_index),num_P,num_N);
    
    % 2.4  update M and the solution
    % calculate H  
    %%% H = SigActFun(X(addin_index,:),model.IW,model.Bias); % a k-by-L matrix, with k = addin_num
    H =  H_temp(i_incorrect,:);
    
    %%%if rule==2
    H_pool(n_pool-length(addin_index)+1:n_pool,:) = H; % save the elements of H into matrix H_pool
    %%%end 
    M = M - M * H'* (W1 + H * M * H')^(-1) * H * M;
    model.alphab = model.alphab + M * H' * W1 * (Y(addin_index) - H * model.alphab);     
    
    % 2.5 clean the active set periodically    
    
    if rule~=-1 && n_pool >= model.cleanPeriod        
        i_clean = i_clean +1; 
        % 2.5.1 determine the indices (saved in cut_index) to be removed   the active set
        %  not that cut_index has length N_POOL
        n_active = length(model.S);
        if n_pool>=n_active
                error('Improper setting of the block size, clean period or the budget size.');
        end
        if rule==0 % maximum similarity criterion             
            K_active = feval(model.ker,X(ind_pool,:)',X(model.S,:)',model.kerparam);            
            cut_index = zeros(1,n_pool); %indices of the elements in model.S
            ind_act =  1:n_active ; 
            % find the maximum k similarities
            for kk =1:n_pool % n_pool < n_active
                [~,ii_max] = max(K_active(kk,ind_act));
                i_max = ind_act(ii_max);
                cut_index(kk) = i_max;  % set cut_index: the indices to be removed from the active set
                ind_act(ii_max) = [];
            end
        elseif rule==1 % forgotron           
            cut_index=1:n_pool;
        elseif rule==2 % maximum judgement criterion 
            f_active = Y(model.S,:).*(H0*model.alphab);  % f_active has length == length(model.S)
            % find the largest k lements of f_active
            [~,ind_f] = sort(f_active,'descend');
            cut_index = ind_f(1:n_pool);
        end        
        % 2.5.2 update M and the solution
        for jj = 1: length(cut_index) %  removing one sample each time
            i_cut = cut_index(jj);
            yi = Y(model.S(i_cut));
            % cut_index consists of some indices in {1,...,N0}, N0 is the budget size
            H = H0(i_cut,:);
            H1 = -H';
            W1 = getW(yi,num_P,num_N);
            M = M - M * H1 * (W1 + H * M * H1)^(-1) * H * M;
            model.alphab = model.alphab + M * H1 * W1 * (yi - H * model.alphab);
        end
        % 2.5.3 update num_P, num_N  
        num_P=num_P + nnz(Y(ind_pool)==1)  - nnz(Y(model.S(cut_index))==1);
        num_N=num_N + nnz(Y(ind_pool)==-1) - nnz(Y(model.S(cut_index))==-1);
        % 2.5.4 update H0   
        if rule==2 || rule==0
            H0(cut_index,:) = H_pool(1:n_pool,:);
            %%H_pool =  zeros(model.cleanPeriod,nHiddenNeurons); % re-initialize  H_pool
        elseif rule == 1 
            H0(cut_index,:) = [];
            H0 = [H0; 
                  H_pool(1:n_pool,:)];
        end
        % 2.5.5 update model.S, ind_pool
        if rule==2 || rule==0 % rule==0: maximum similarity criterion, rule==2: maximum judgement criterion
            model.S(cut_index) = ind_pool; % NOTE that the rows of matrix H0 should corresponds to model.S
        elseif rule ==1 %   forgotron 
            model.S(cut_index) = [];
            model.S = [model.S ind_pool];
        end        
        ind_pool = []; % clean the pool 
        if model.verbose>=2
            fprintf('i_clean:%d\t | |model.S: %d\t| num_P: %d \t | num_N: %d\t|    ',...
                i_clean,length(model.S),num_P,num_N);
            if rule==2
                fprintf('f_cut(1): %.4f\t|',f_active(cut_index(1)));
            end
            fprintf('\n');
        end
    end % end of the clean operation
    
end % end of the online loops

% 3. outputs
[acc]= accuracyIndex_0(pred_v,int32(Y)); % calculate accuracies 
%model = assign_struct(model, [], acc);   % assign the accuracies to the output MODEL struct

model.addin = n_addin; % number of trained samples 
model.G = acc.gmean; % value of G-mean 

model.time = cputime - st;

end  % end of the main function

function W1 = getW(y,num_P,num_N)
addin_num =length(y);
if addin_num==1
    if y==1
        W1 = 1/num_P;
    else
        W1 = 1/num_N;
    end
else %addin_num> 1
    w11 = ones(addin_num,1)/num_P;
    w11(y==-1) = 1/num_N;
    W1 = diag(w11);
end
end