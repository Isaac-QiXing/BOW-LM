function r_v = mnrnd_unique(k,p)
% find unique k numbers from {1,2,..,n} according multinormial distribution
% Inputs: 
%   k: number of n unique elements, k<=n
%   p: a n-by-1 vector with the sum = 1, indicating the parameter of multinormial distribution
%       p<n
% Outputs: 
%   r_v: vector of the selected elements 

debug_on =  0;
n = length(p);
if sum(p)>1.02 || sum(p)<=0.98
    error('the input  parameter of probabilities should have sum of 1. ');
end

if k>=n
    r_v = 1:n;
    return
end

n_repeat = 10;

pi = p;
ki = k;
r_v = [];
ind_i = 1:n; % the remain candidate indices
ite = 0; 
while 1
    % select kii  unique elements 
    R = mnrnd(ki,pi,n_repeat);
    [ni_select, i_row] = max(sum(R>0,2)); % ki_unique: current number of indices 
    ii_select =  R(i_row,:)>0;
    ind_i_select = ind_i(ii_select); 
    r_v  = [r_v    ind_i_select];
    if ni_select == ki
        break
    end
    % update ki: the remain number of elements  to select
    ki = ki - ni_select;
    % update ind_i
    ind_i(ii_select) = [];
    % update the probability parameters     
    pi(ii_select) = [];
    pi = pi./sum(pi); % normalize pi
    ite = ite+1;
    
    if debug_on
        fprintf('ite: %d select %d numbers.\n',ite,ni_select);
    end
    
    if ite> k
        error('failed to find specified number of scalars. ');
    end
end

end