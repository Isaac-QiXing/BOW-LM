function [R] =mytiedrank(X,tol)
% inputs:
%   X: data matrix, highest value would have 1st order 
%   tol: tolerence, 
% outputs: 
%   R: ranks along each row

% [X2,I] = sort(X,2,'descend');

[nrow, ncol]= size(X);
R = zeros(nrow,ncol);
for ii=1:nrow
     R(ii,:) = tiedrank_vec(X(ii,:),tol);
end

end

function r= tiedrank_vec(v,tol)
    % v : a vector
    % r: the rank under the given tol
     [v2,ind]= sort(v,'descend'); 
     [~,iv] = sort(ind,'ascend');
     len = length(v);
% % %      %%%
% % %      v
% % %      v2
% % %      ind
% % %      iv
% % %      %%%
     r = 1:len; 
     for ii=1:len 
         % determine the rank of ii-th element of v2
         p = ii; 
         for jj=ii+1:len  
             p = jj;
             if abs(v2(jj)-v2(ii)) >tol                 
                 p = jj-1;
                 break;
             end
         end
         % assign the rank of ii-th element to p-th element of v2       
         r(ii:p) = mean(r(ii:p));
     end
     r = r(iv); 
end 