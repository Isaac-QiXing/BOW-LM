function [h,n_outlier] = plotNumer(x1_v,format1_s,varargin)
% plot a group of numbers in a 2-dimsional plane, adding a dimension of random numbers  
% Inputs 
%   x1_v: a vector of real numbers 
%   format1_s: format string for plot x1, refer to the format string of plot() for detail
%       append a character 'z' at the end of the format str to remove outlier numbers 
%       
%   varargin{:}: optinal groups of numbers and vectors and argument struct 
%     varargin = {x2,format2_s, ...., xk, formatK_s}
%           
%  Outputs 
%   h:  returns the current figure handle
%   n_outlier: number of removed outliers 

% future version: 
%varargin = {x2,format2_s, ...., xk, formatK_s, arg}
%    the last optinal input, ARG, is a struct
%       arg.thresh: a scalar indicating a thresh 


[n_outlier,x1_v, format1_s] = dealOutlier(x1_v,format1_s);
plot(x1_v,rand(size(x1_v)),format1_s);

if nargin>2
   n_group_var = floor((nargin - 2)/2);
   hold on
   for ii=1:n_group_var
       x2_v = varargin{ii};
       format2_s = varargin{ii+1};
       
       [n2_outlier,x2_v, format2_s] = dealOutlier(x2_v,format2_s); 
       plot(x2_v,rand(size(x2_v)),format2_s);
       
       n_outlier = n_outlier + n2_outlier;
   end
   hold off
end

h = gcf; 

end

function [n_outlier,x2_v, format2_s] = dealOutlier(x_v,format_s)
% remove outliers and remove 'z' from format_s 

n_outlier = 0;
format2_s = strtrim(format_s);
x2_v = x_v;
if  'z'==format2_s(end)
    iqr_par = 100; % default value 1.5
    isOutlier_v = isOutlierNumber(x_v);
    n_outlier = nnz(isOutlier_v);
    x2_v = x_v(~isOutlier_v);
    format2_s(end) = [];
end

end