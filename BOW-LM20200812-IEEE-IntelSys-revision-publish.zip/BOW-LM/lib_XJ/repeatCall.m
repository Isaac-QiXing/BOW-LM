function  [iteInf_st,elapsed_seconds_v ]= repeatCall(getData,fun,arg_fun_c,arg_repeat_t,varargin)
% call a function repeatedly for a specified numbers, support parfor mode
% Inputs:
%   getData: a string  of mat data file name, or a function handle with the format
%           data_st = getData(arg_getData_st)
%       with arg_getData_st a struct of parameters, DATA_ST a struct of data
%       fields;
%   fun:  handle of the function to repeat several times, it has the following format
%             iteInf = fun(data_st,arg_fun_c{:})
%       with
%           data_st: a stuct of data fields, load or output from GETDATA;
%           arg_fun_c{:} the input parameters, iteInf a struct of output
%       fields;
%   arg_fun_c: a cell array of the input parameters of FUN
%   arg_repeat_t: a struct of parameters 
%       .repeat: a positile integer, indicating the number of repeat times to
%           call FUN;
%       .parfor: 1 or 0, whether employ parfor mode for repeat
%       .gcp_delete: optional, 1 or 0, whether close parpool after
%           repeating, default 1; 
%   varargin{1}:
%       this parameter is only required when GETDATA is a function handle,
%           it is a  struct of parameters of getData()
% Outputs:
%   itetInf_st:
%       a struct array, with length repeat,  of the outputs by calling FUN;
%   elapsed_seconds_v: a row vector with length repeat, indicating the number of
%       seconds for each call;
%
% Future version:
%   optimize the parfor usage,  to avoid open and close parallel workers
%     frequently
%
% versions:
%  * 2020.2.26 the first call
 
arg_repeat_t = completeArg(arg_repeat_t,{'parfor','gcp_delete'},{1,1});

if arg_repeat_t.parfor
    if isempty(gcp('nocreate'))
        parpool;
    end
elseif arg_repeat_t.gcp_delete
    if ~isempty(gcp('nocreate'))
        delete(gcp('nocreate'))
    end
end

% 0.1 check the 1st input  `getData'
is_fun_getData = isa(getData,'function_handle');
if  ischar(getData)
    if ~exist(getData,'file')
        error('The specified data file %s is not found',getData);
    end
elseif ~is_fun_getData
    error('The provided 1st input ''getData'' should be a data file name or a function handle');
end

% 0.2 get input parameter of varargin{1}
par_getData = [];
if is_fun_getData
    if nargin <= 4
        error('The 5th input parameter should be provided if getData is function handle.');
    end
    par_getData = varargin{1};
end

n_repeat = arg_repeat_t.repeat;
elapsed_seconds_v = zeros(1,n_repeat);

if arg_repeat_t.parfor
    parfor i_repeat = 1:n_repeat
        % 1. load data
        if ischar(getData)
            data_st = load(getData);
        elseif isa(getData,'function_handle')
            % getData is a function handle
            data_st = getData(par_getData);
        end
        % 2. repeat calling FUN
        tStart=tic;
        iteInf_st(i_repeat) = fun(data_st,arg_fun_c{:});
        elapsed_seconds_v(i_repeat) = toc(tStart);
        fprintf(1,'=');
    end
    
else
    for i_repeat = n_repeat:-1:1
        % 1. load data
        if ischar(getData)
            data_st = load(getData);
        elseif isa(getData,'function_handle')
            % getData is a function handle
            data_st = getData(par_getData);
        end
        % 2. repeat calling FUN
        tStart=tic;
        iteInf_st(i_repeat) = fun(data_st,arg_fun_c{:});
        elapsed_seconds_v(i_repeat) = toc(tStart);
        fprintf(1,'=');
    end
    
end


fprintf(1,'\n');

if ~isempty(gcp('nocreate')) && arg_repeat_t.gcp_delete
    delete(gcp('nocreate'));
end

end