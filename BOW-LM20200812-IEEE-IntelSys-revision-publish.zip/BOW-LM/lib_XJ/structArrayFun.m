function x0_t = structArrayFun(x_t,fun)
% apply a specified function to the specified dimension of a struct array
% Inputs:
%   x_t: a 1-dimensional struct array
%   fun:  a function handle with the format: 
%           y = fun(x_v)
%   with x_v a 1-dimensional array, and only 1 output     
% Outputs:
%  x0_t: a struct with the same fields as x_t 

% Future version: apply a specified function to the specified dimension of a struct array
% 2020.8.7 first version
field_c = fieldnames(x_t);
x0_t = struct();

for ii = 1:length(field_c)
    field = field_c{ii};
    x0_t.(field) = fun([x_t(:).(field)]);
%     acc_b = struct2table(x_t);
%     Acc =   table2array(acc_b);
%     average_acc = mean(Acc,1);
end

end