clc;clear;close all;

fid=fopen('wisconsin-5-1tra.dat','r');
% a=textscan(fid,'%s %s %s %s %s %s %s %s %s %s','HeaderLines',14);
a=textscan(fid, repmat('%s',[1  10 ]),'HeaderLines',14);
fclose(fid);

x=[str2num(char(a{1,1})) str2num(char(a{1,2})) str2num(char(a{1,3}))  str2num(char(a{1,4})) str2num(char(a{1,5})) str2num(char(a{1,6})) str2num(char(a{1,7}))  str2num(char(a{1,8})) str2num(char(a{1,9}))];
 
negative=-1;
positive=1;
y=cellfun(@eval,a{1,10});

fid=fopen('wisconsin-5-1tst.dat','r');
a=textscan(fid,'%s %s %s %s %s %s %s %s %s %s','HeaderLines',14);
fclose(fid);

x_test=[str2num(char(a{1,1})) str2num(char(a{1,2})) str2num(char(a{1,3})) str2num(char(a{1,4})) str2num(char(a{1,5})) str2num(char(a{1,6})) str2num(char(a{1,7}))  str2num(char(a{1,8})) str2num(char(a{1,9}))];
 negative=-1;
 positive=1;
y_test=cellfun(@eval,a{1,10}); 


maxSVs=[250]; %600 600 600]

for kk=1:length(maxSVs)   
           
    maxSV = maxSVs(kk); gamma=1/size(x,2);
        
[n m] = size(x); rp = randperm(n);x = x(rp,:);y = y(rp,:);
tra_num = n;
x_tr = x(1:tra_num,:)'; 
y_tr = y(1:tra_num)';


% select kernel
hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
hp.gamma = gamma;

% inizialize an empty model
model_bak = model_init(@compute_kernel,hp);
model_bak.nu = 1;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV;  start  = model_bak.maxSV+100;


% train BOS-ELM algorithm
 mm=100;
    fprintf('Training Budgeted OS-ELM-Unweighted model...\n');
    E=[];
	for pp=1:mm
        model_BOSELM = k_BOSELM2_train(x_tr',y_tr',model_bak); 
        G= k_test(x_test,y_test,model_BOSELM);
        E=[E G];
    end
     Gmeans=sum(E)/mm
tic;
    fprintf('Done!\n');
    fprintf('Training Budgeted OS-ELM-W1 model...\n');
    E=[];
	for pp=1:mm
         model_BOSELM = k_BWOSELM2_train(x_tr',y_tr',model_bak);   
         G= k_test(x_test,y_test,model_BOSELM);
         E=[E G];
    end 
    Gmeans=sum(E)/mm
    fprintf('Done!\n');
    toc;
    time=toc-tic;
    
    fprintf('Training Budgeted OS-ELM-W2 model...\n');
    E=[];
    for pp=1:mm
        model_BOSELM = k_BW2OSELM2_train(x_tr',y_tr',model_bak); 
        G= k_test(x_test,y_test,model_BOSELM);
        E=[E G];
	end
    fprintf('Done!\n');
    Gmeans=sum(E)/mm

end
    



