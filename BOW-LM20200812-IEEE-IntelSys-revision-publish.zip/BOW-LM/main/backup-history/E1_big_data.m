clc;clear;close all;

xlsx_name='Agrawal.csv';
[num]=xlsread(xlsx_name); 
num(1,:)=[];

[n,m]=size(num);
x=num(:, 1:m-1);
y=num(:, m);
clear num;

tic;
maxSV=[25000]; 

% select kernel
hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
% hp.gamma = gamma;

% inizialize an empty model
model_bak = model_init(@compute_kernel,hp);
model_bak.nu = 1;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV;  start  = model_bak.maxSV+100;


% train BOS-ELM algorithm
 mm=1;
    fprintf('Training Budgeted k_BWOSELM-1,1,2,3 model...\n');
    E=[];
     
	for pp=1:mm
        [model,acc] = k_BWOSELM(x, y, model_bak,1); 
        E=[E acc];
    end
     Gmeans=sum(E)/mm
    fprintf('Done!\n');

  
toc;
toc-tic


