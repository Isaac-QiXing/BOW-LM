% DEMO for budget algorithms
% The following algorithms are used: 
% - k_forgetron_st
% - k_perceptron_train
% - k_BOGD_train
% - BudgetedSVM_train
% - k_LSSVM_train

clc;clear;close all;

fid=fopen('segment0-5-5tra.dat','r');
a=textscan(fid,'%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s ','HeaderLines',24);
fclose(fid);

x=[str2num(char(a{1,1})) str2num(char(a{1,2})) str2num(char(a{1,3}))  str2num(char(a{1,4})) str2num(char(a{1,5})) str2num(char(a{1,6})) str2num(char(a{1,7}))  str2num(char(a{1,8})) str2num(char(a{1,9})) str2num(char(a{1,10})) str2num(char(a{1,11})) str2num(char(a{1,12})) str2num(char(a{1,13}))  str2num(char(a{1,14})) str2num(char(a{1,15})) str2num(char(a{1,16})) str2num(char(a{1,17}))  str2num(char(a{1,18})) str2num(char(a{1,19})) ];
 negative=-1;
 positive=1;
y=cellfun(@eval,a{1,20});

fid=fopen('segment0-5-5tst.dat','r');
a=textscan(fid,'%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s ','HeaderLines',24);
fclose(fid);

x_test=[str2num(char(a{1,1})) str2num(char(a{1,2})) str2num(char(a{1,3}))  str2num(char(a{1,4})) str2num(char(a{1,5})) str2num(char(a{1,6})) str2num(char(a{1,7}))  str2num(char(a{1,8})) str2num(char(a{1,9})) str2num(char(a{1,10})) str2num(char(a{1,11})) str2num(char(a{1,12})) str2num(char(a{1,13}))  str2num(char(a{1,14})) str2num(char(a{1,15})) str2num(char(a{1,16})) str2num(char(a{1,17}))  str2num(char(a{1,18})) str2num(char(a{1,19})) ];
 negative=-1;
 positive=1;
y_test=cellfun(@eval,a{1,20}); 

maxSVs=[1000]; %600 600 600];

for kk=1:length(maxSVs)    
         
    
    
    maxSV = maxSVs(kk); gamma=1/size(x,2);

        
[n m] = size(x); rp = randperm(n);x = x(rp,:);y = y(rp,:);
tra_num = n;
x_tr = x(1:tra_num,:)'; 
y_tr = y(1:tra_num)';


% select kernel
hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
hp.gamma = gamma;

% inizialize an empty model
model_bak = model_init(@compute_kernel,hp);
model_bak.nu = 1;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV;  start  = model_bak.maxSV+100;

mm=10;
 

                                    
% train BudgetedSVM model  

fprintf('Training BSGD model...\n');
G=[];T=[];
	for pp=1:mm
        t1=cputime;
        model_BudgetedSVM = k_BSGD_train(x_tr,y_tr,model_bak);
       G1= k_test3(x_test',y_test',model_BudgetedSVM);
       t2=cputime-t1;
       T=[T t2];
       G=[G G1];
    end
     Gmeans=sum(G)/mm
    Time=sum(T)/mm
fprintf('Done!\n');


% train BOGD
fprintf('Training BOGD...\n');
G=[];T=[];
	for pp=1:mm
        t1=cputime;
       model_BOGD = k_BOGD_train(x_tr,y_tr,model_bak);
       G1= k_test3(x_test',y_test',model_BOGD);
       t2=cputime-t1;
       T=[T t2];
       G=[G G1];
    end
     Gmeans=sum(G)/mm
    Time=sum(T)/mm
fprintf('Done!\n');

% train Random Bduget Perceptron algorithm
fprintf('Training Random Bduget Perceptron model...\n');
G=[];T=[];
	for pp=1:mm
        t1=cputime;
       model_perceptron = k_perceptron_train(x_tr,y_tr,model_bak);
       G1= k_test2(x_test',y_test', model_perceptron);
       t2=cputime-t1;
       T=[T t2];
       G=[G G1];
    end
     Gmeans=sum(G)/mm
    Time=sum(T)/mm
%fprintf('Number of support vectors last solution:%d\n',numel(model_perceptron.beta));
fprintf('Done!\n');


% train BOS-ELM algorithm
fprintf('Training Budgeted OS-ELM (W1) model...\n');
G=[];T=[];
	for pp=1:mm
        t1=cputime;
   model_BOSELM = k_BWOSELM2_train(x_tr',y_tr',model_bak);  
           %model_BOSELM = k_BWOSELM(x_tr',y_tr',model_bak,2);  

       G1= k_test(x_test,y_test,model_BOSELM);
       t2=cputime-t1;
       T=[T t2];
       G=[G G1];
    end
     Gmeans=sum(G)/mm
    Time=sum(T)/mm
fprintf('Done!\n');

fprintf('Training Budgeted OS-ELM (W2) model...\n');
G=[];T=[];
	for pp=1:mm
        t1=cputime;
       model_BOSELM = k_BW2OSELM2_train(x_tr',y_tr',model_bak); 
       G1= k_test(x_test,y_test,model_BOSELM);
       t2=cputime-t1;
       T=[T t2];
       G=[G G1];
    end
     Gmeans=sum(G)/mm
    Time=sum(T)/mm
fprintf('Done!\n');
% train Budget LSSVM
model_bak.type = 1;

% model_bak.nu = 1;

fprintf('Training LSSVM model...\n');
G=[];T=[];
	for pp=1:mm
        t1=cputime;
        model_bak.block = 10;  %
        model_LSSVM = k_LSSVM_train(x_tr,y_tr',model_bak);
       G1= k_test4(x_test',y_test,model_LSSVM);
       t2=cputime-t1;
       T=[T t2];
       G=[G G1];
    end
     Gmeans=sum(G)/mm
    Time=sum(T)/mm
fprintf('Done!\n');
end
    

