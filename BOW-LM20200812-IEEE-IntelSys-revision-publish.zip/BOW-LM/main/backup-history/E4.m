% DEMO for budget algorithms
% The following algorithms are used: 
% - k_forgetron_st
% - k_perceptron_train
% - k_BOGD_train
% - BudgetedSVM_train
% - k_LSSVM_train

clc;clear;close all;
 




mmm=xlsread('sea.xlsx');
mmm(find(mmm==0))=-1;


x=mmm(1:500,1:3);
y=mmm(1:500,4);

x_test=mmm(501:600,1:3);
y_test=mmm(501:600,4);

maxSVs=[300]; %600 600 600];


for kk=1:length(maxSVs)    
         
    
    
    maxSV = maxSVs(kk); gamma=1/size(x,2);

        
[n m] = size(x); rp = randperm(n);x = x(rp,:);y = y(rp,:);
tra_num = n;
x_tr = x(1:tra_num,:)'; 
y_tr = y(1:tra_num)';
mm=1;

% select kernel
hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
hp.gamma = gamma;

% inizialize an empty model
model_bak = model_init(@compute_kernel,hp);
model_bak.nu = 1;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV;  start  = model_bak.maxSV+100;




                                    
% train BudgetedSVM model

fprintf('Training BSGD model...\n');
G=[];T=[];
	for pp=1:mm
        t1=cputime;
        model_BudgetedSVM = k_BSGD_train(x_tr,y_tr,model_bak);
       G1= k_test3(x_test',y_test',model_BudgetedSVM);
       t2=cputime-t1;
       T=[T t2];
       G=[G G1];
    end
     Gmeans=sum(G)/mm
    Time=sum(T)/mm
fprintf('Done!\n');


% train BOGD
fprintf('Training BOGD...\n');
G=[];T=[];
	for pp=1:mm
        t1=cputime;
       model_BOGD = k_BOGD_train(x_tr,y_tr,model_bak);
       G1= k_test3(x_test',y_test',model_BOGD);
       t2=cputime-t1;
       T=[T t2];
       G=[G G1];
    end
     Gmeans=sum(G)/mm
    Time=sum(T)/mm
fprintf('Done!\n');

% train Random Bduget Perceptron algorithm
fprintf('Training Random Bduget Perceptron model...\n');
G=[];T=[];
	for pp=1:mm
        t1=cputime;
       model_perceptron = k_perceptron_train(x_tr,y_tr,model_bak);
       G1= k_test2(x_test',y_test', model_perceptron);
       t2=cputime-t1;
       T=[T t2];
       G=[G G1];
    end
     Gmeans=sum(G)/mm
    Time=sum(T)/mm
%fprintf('Number of support vectors last solution:%d\n',numel(model_perceptron.beta));
fprintf('Done!\n');


% train BOS-ELM algorithm
fprintf('Training Budgeted OS-ELM (W1) model...\n');
G=[];T=[];
	for pp=1:mm
        t1=cputime;
       model_BOSELM = k_BWOSELM2_train(x_tr',y_tr',model_bak);  
       G1= k_test(x_test,y_test,model_BOSELM);
       t2=cputime-t1;
       T=[T t2];
       G=[G G1];
    end
     Gmeans=sum(G)/mm
    Time=sum(T)/mm
fprintf('Done!\n');

fprintf('Training Budgeted OS-ELM (W2) model...\n');
G=[];T=[];
	for pp=1:mm
        t1=cputime;
       model_BOSELM = k_BW2OSELM2_train(x_tr',y_tr',model_bak); 
       G1= k_test(x_test,y_test,model_BOSELM);
       t2=cputime-t1;
       T=[T t2];
       G=[G G1];
    end
     Gmeans=sum(G)/mm
    Time=sum(T)/mm
fprintf('Done!\n');
% train Budget LSSVM
model_bak.type = 1;

% model_bak.nu = 1;


fprintf('Training LSSVM model...\n');
G=[];T=[];
	for pp=1:mm
        t1=cputime;
        model_bak.block = 10;  %
        model_LSSVM = k_LSSVM_train(x_tr,y_tr',model_bak);
       G1= k_test4(x_test',y_test,model_LSSVM);
       t2=cputime-t1;
       T=[T t2];
       G=[G G1];
    end
     Gmeans=sum(G)/mm
    Time=sum(T)/mm
fprintf('Done!\n');


fprintf('Training WOS-ELM  model...\n');
G=[];T=[];
	for pp=1:mm
        t1=cputime;
       model_BOSELM = k_WOSELM_train(x_tr',y_tr',model_bak);  
       G1= k_test(x_test,y_test,model_BOSELM);
       t2=cputime-t1;
       T=[T t2];
       G=[G G1];
    end
     Gmeans=sum(G)/mm
    Time=sum(T)/mm
fprintf('Done!\n');

 
fprintf('Training Budgeted OS-ELM (W1) model...\n');
G=[];T=[];
	for pp=1:mm
        t1=cputime;
       model_BOSELM = k_BWOSELM2_train(x_tr',y_tr',model_bak);  
       G1= k_test(x_test,y_test,model_BOSELM);
       t2=cputime-t1;
       T=[T t2];
       G=[G G1];
    end
     Gmeans=sum(G)/mm
    Time=sum(T)/mm
fprintf('Done!\n');
end
    

