clc;clear;close all;
mm=1;
fid=fopen('D:\Matlab\bin\Myworks\online Extreme Learning Machine\BW-ELM-program\data4.2\vehicle0-5-5tra.dat','r');
a=textscan(fid,'%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s','HeaderLines',23);
fclose(fid);

x=[str2num(char(a{1,1})) str2num(char(a{1,2})) str2num(char(a{1,3}))  str2num(char(a{1,4})) str2num(char(a{1,5})) str2num(char(a{1,6})) str2num(char(a{1,7}))  str2num(char(a{1,8})) str2num(char(a{1,9})) str2num(char(a{1,10})) str2num(char(a{1,11}))  str2num(char(a{1,12})) str2num(char(a{1,13})) str2num(char(a{1,14})) str2num(char(a{1,15})) str2num(char(a{1,16}))  str2num(char(a{1,17})) str2num(char(a{1,18}))];
negative=-1;
positive=1;
y=cellfun(@eval,a{1,19});


maxSV=[300];  gamma=1/size(x,2);
% select kernel
hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
hp.gamma = gamma;

% inizialize an empty model
model_bak = model_init(@compute_kernel,hp);
model_bak.nu = 1;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV;  start  = model_bak.maxSV+100;

 rule=0;
 fprintf('Training BWOSELM model...\n');
 gmean=[]; bm=[];  kappa=[]; auc=[]; T=[];
	for pp=1:mm
         tic;
         [model,acc] = k_BWOSELM(x, y, model_bak,rule,0); 
         t=toc;
         gmean=[gmean acc.gmean ]; 
         bm=[bm  acc.bm];  
         kappa=[kappa   acc.kappa]; 
         auc=[auc   acc.auc];
         T=[T t];
    end
    gmean=sum(gmean)/mm;
     bm=sum(bm)/mm;
     kappa=sum(kappa)/mm;
      auc=sum(auc)/mm;
    four_accuracyIndex_value= [gmean  bm kappa  auc]
    Time=sum(T)/mm
    
    
 rule=1;
 fprintf('Training BWOSELM model...\n');
 gmean=[]; bm=[];  kappa=[]; auc=[]; T=[];
	for pp=1:mm
         tic;
         [model,acc] = k_BWOSELM(x, y, model_bak,rule,0); 
         t=toc;
         gmean=[gmean acc.gmean ]; 
         bm=[bm  acc.bm];  
         kappa=[kappa   acc.kappa]; 
         auc=[auc   acc.auc];
         T=[T t];
    end
    gmean=sum(gmean)/mm;
     bm=sum(bm)/mm;
     kappa=sum(kappa)/mm;
      auc=sum(auc)/mm;
    four_accuracyIndex_value= [gmean  bm kappa  auc]
    Time=sum(T)/mm
    
    
    
 rule=2;
 fprintf('Training BWOSELM model...\n');
 gmean=[]; bm=[];  kappa=[]; auc=[]; T=[];
	for pp=1:mm
         tic;
         [model,acc] = k_BWOSELM(x, y, model_bak,rule,0); 
         t=toc;
         gmean=[gmean acc.gmean ]; 
         bm=[bm  acc.bm];  
         kappa=[kappa   acc.kappa]; 
         auc=[auc   acc.auc];
         T=[T t];
    end
    gmean=sum(gmean)/mm;
     bm=sum(bm)/mm;
     kappa=sum(kappa)/mm;
      auc=sum(auc)/mm;
    four_accuracyIndex_value= [gmean  bm kappa  auc]
    Time=sum(T)/mm
    
 rule=3;
 fprintf('Training BWOSELM model...\n');
 gmean=[]; bm=[];  kappa=[]; auc=[]; T=[];
	for pp=1:mm
         tic;
         [model,acc] = k_BWOSELM(x, y, model_bak,rule,0); 
         t=toc;
         gmean=[gmean acc.gmean ]; 
         bm=[bm  acc.bm];  
         kappa=[kappa   acc.kappa]; 
         auc=[auc   acc.auc];
         T=[T t];
    end
    gmean=sum(gmean)/mm;
     bm=sum(bm)/mm;
     kappa=sum(kappa)/mm;
      auc=sum(auc)/mm;
    four_accuracyIndex_value= [gmean  bm kappa  auc]
    Time=sum(T)/mm