clc;clear;close all;
mm=20;

xlsx_name='C:\Users\dell\Desktop\MOA & Qi\MOA data for paper\RandomRBF_10_imbalance_1.csv';
[num]=xlsread(xlsx_name); 
num(1,:)=[];

[n,m]=size(num);
x=num(:, 1:m-1);
y=num(:, m);
clear num;

maxSV=6000;  gamma=1/size(x,2);
Acc=[];AAcc=[];Time=[]; ac=[];T=[];ACC=[];
% select kernel
hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
hp.gamma = gamma;

% inizialize an empty model
model_bak = model_init(@compute_kernel,hp);
model_bak.nu = 1;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV;  start  = model_bak.maxSV+100;
[n_sample,InputDim] = size(x);
model_bak.kerparam =struct('type','rbf','gamma',1/InputDim);

% train WOS-ELM  model
 rule=-1;
 fprintf('Training BWOSELM model...\n');
 gmean=[]; bm=[];  kappa=[]; auc=[]; T=[];va=[];
	for pp=1:mm
         tic;
         [model,acc,num] = k_BWOSELM_for_e6(x, y, model_bak,rule,0); 
         t=toc;
         acc=struct2cell(acc)';
         Acc=[Acc; acc];
         T=[T t];
         value=num.FP+num.FN-maxSV;
         va=[va value];
    end
Acc=cell2mat(Acc);
A_save=[Acc T'];
A_save=sum(A_save)/mm;
vaa=sum(va);
A_save=[A_save  vaa];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data1.csv', A_save )

% train BOW-ELM  model 
 Acc=[];T=[]; A_save=[];
 rule=2;
 fprintf('Training BOW-ELM model...\n');
 gmean=[]; bm=[];  kappa=[]; auc=[]; T=[];
	for pp=1:mm
         tic;
         [model,acc,num] = k_BWOSELM_for_e6(x, y, model_bak,rule,0); 
         t=toc;
          acc=struct2cell(acc)';
          Acc=[Acc; acc];
          T=[T t];
         value=num.FP+num.FN-maxSV;
         va=[va value];
    end
Acc=cell2mat(Acc);
A_save=[Acc T'];
A_save=sum(A_save)/mm;
vaa=sum(va);
A_save=[A_save  vaa];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data2.csv', A_save )

clc;clear;close all;
mm=20;

xlsx_name='C:\Users\dell\Desktop\MOA & Qi\MOA data for paper\RandomRBF_10_imbalance_2.csv';
[num]=xlsread(xlsx_name); 
num(1,:)=[];

[n,m]=size(num);
x=num(:, 1:m-1);
y=num(:, m);
clear num;

maxSV=6000;  gamma=1/size(x,2);
Acc=[];AAcc=[];Time=[]; ac=[];T=[];ACC=[];
% select kernel
hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
hp.gamma = gamma;

% inizialize an empty model
model_bak = model_init(@compute_kernel,hp);
model_bak.nu = 1;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV;  start  = model_bak.maxSV+100;
[n_sample,InputDim] = size(x);
model_bak.kerparam =struct('type','rbf','gamma',1/InputDim);

% train WOS-ELM  model
 rule=-1;
 fprintf('Training BWOSELM model...\n');
 gmean=[]; bm=[];  kappa=[]; auc=[]; T=[];va=[];
	for pp=1:mm
         tic;
         [model,acc,num] = k_BWOSELM_for_e6(x, y, model_bak,rule,0); 
         t=toc;
         acc=struct2cell(acc)';
         Acc=[Acc; acc];
         T=[T t];
         value=num.FP+num.FN-maxSV;
         va=[va value];
    end
Acc=cell2mat(Acc);
A_save=[Acc T'];
A_save=sum(A_save)/mm;
vaa=sum(va);
A_save=[A_save  vaa];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data3.csv', A_save )

% train BOW-ELM  model 
 Acc=[];T=[]; A_save=[];
 rule=2;
 fprintf('Training BOW-ELM model...\n');
 gmean=[]; bm=[];  kappa=[]; auc=[]; T=[];
	for pp=1:mm
         tic;
         [model,acc,num] = k_BWOSELM_for_e6(x, y, model_bak,rule,0); 
         t=toc;
          acc=struct2cell(acc)';
          Acc=[Acc; acc];
          T=[T t];
         value=num.FP+num.FN-maxSV;
         va=[va value];
    end
Acc=cell2mat(Acc);
A_save=[Acc T'];
A_save=sum(A_save)/mm;
vaa=sum(va);
A_save=[A_save  vaa];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data4.csv', A_save )


clc;clear;close all;
mm=20;

xlsx_name='C:\Users\dell\Desktop\MOA & Qi\MOA data for paper\RandomTree_10_imbalance_1.csv';
[num]=xlsread(xlsx_name); 
num(1,:)=[];

[n,m]=size(num);
x=num(:, 1:m-1);
y=num(:, m);
clear num;

maxSV=6000;  gamma=1/size(x,2);
Acc=[];AAcc=[];Time=[]; ac=[];T=[];ACC=[];
% select kernel
hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
hp.gamma = gamma;

% inizialize an empty model
model_bak = model_init(@compute_kernel,hp);
model_bak.nu = 1;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV;  start  = model_bak.maxSV+100;
[n_sample,InputDim] = size(x);
model_bak.kerparam =struct('type','rbf','gamma',1/InputDim);

% train WOS-ELM  model
 rule=-1;
 fprintf('Training BWOSELM model...\n');
 gmean=[]; bm=[];  kappa=[]; auc=[]; T=[];va=[];
	for pp=1:mm
         tic;
         [model,acc,num] = k_BWOSELM_for_e6(x, y, model_bak,rule,0); 
         t=toc;
         acc=struct2cell(acc)';
         Acc=[Acc; acc];
         T=[T t];
         value=num.FP+num.FN-maxSV;
         va=[va value];
    end
Acc=cell2mat(Acc);
A_save=[Acc T'];
A_save=sum(A_save)/mm;
vaa=sum(va);
A_save=[A_save  vaa];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data5.csv', A_save )

% train BOW-ELM  model 
 Acc=[];T=[]; A_save=[];
 rule=2;
 fprintf('Training BOW-ELM model...\n');
 gmean=[]; bm=[];  kappa=[]; auc=[]; T=[];
	for pp=1:mm
         tic;
         [model,acc,num] = k_BWOSELM_for_e6(x, y, model_bak,rule,0); 
         t=toc;
          acc=struct2cell(acc)';
          Acc=[Acc; acc];
          T=[T t];
         value=num.FP+num.FN-maxSV;
         va=[va value];
    end
Acc=cell2mat(Acc);
A_save=[Acc T'];
A_save=sum(A_save)/mm;
vaa=sum(va);
A_save=[A_save  vaa];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data6.csv', A_save )



clc;clear;close all;
mm=20;

xlsx_name='C:\Users\dell\Desktop\MOA & Qi\MOA data for paper\RandomTree_10_imbalance_2.csv';
[num]=xlsread(xlsx_name); 
num(1,:)=[];

[n,m]=size(num);
x=num(:, 1:m-1);
y=num(:, m);
clear num;

maxSV=6000;  gamma=1/size(x,2);
Acc=[];AAcc=[];Time=[]; ac=[];T=[];ACC=[];
% select kernel
hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
hp.gamma = gamma;

% inizialize an empty model
model_bak = model_init(@compute_kernel,hp);
model_bak.nu = 1;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV;  start  = model_bak.maxSV+100;
[n_sample,InputDim] = size(x);
model_bak.kerparam =struct('type','rbf','gamma',1/InputDim);

% train WOS-ELM  model
 rule=-1;
 fprintf('Training BWOSELM model...\n');
 gmean=[]; bm=[];  kappa=[]; auc=[]; T=[];va=[];
	for pp=1:mm
         tic;
         [model,acc,num] = k_BWOSELM_for_e6(x, y, model_bak,rule,0); 
         t=toc;
         acc=struct2cell(acc)';
         Acc=[Acc; acc];
         T=[T t];
         value=num.FP+num.FN-maxSV;
         va=[va value];
    end
Acc=cell2mat(Acc);
A_save=[Acc T'];
A_save=sum(A_save)/mm;
vaa=sum(va);
A_save=[A_save  vaa];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data7.csv', A_save )

% train BOW-ELM  model 
 Acc=[];T=[]; A_save=[];
 rule=2;
 fprintf('Training BOW-ELM model...\n');
 gmean=[]; bm=[];  kappa=[]; auc=[]; T=[];
	for pp=1:mm
         tic;
         [model,acc,num] = k_BWOSELM_for_e6(x, y, model_bak,rule,0); 
         t=toc;
          acc=struct2cell(acc)';
          Acc=[Acc; acc];
          T=[T t];
         value=num.FP+num.FN-maxSV;
         va=[va value];
    end
Acc=cell2mat(Acc);
A_save=[Acc T'];
A_save=sum(A_save)/mm;
vaa=sum(va);
A_save=[A_save  vaa];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data8.csv', A_save )




clc;clear;close all;
mm=20;
model_bak.para=400;
xlsx_name='C:\Users\dell\Desktop\MOA & Qi\MOA data for paper\RandomTree_105_imblance_1.csv';
[num]=xlsread(xlsx_name); 
num(1,:)=[];

[n,m]=size(num);
x=num(:, 1:m-1);
y=num(:, m);
clear num;

maxSV=6000;  gamma=1/size(x,2);
Acc=[];AAcc=[];Time=[]; ac=[];T=[];ACC=[];
% select kernel
hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
hp.gamma = gamma;

% inizialize an empty model
model_bak = model_init(@compute_kernel,hp);
model_bak.nu = 1;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV;  start  = model_bak.maxSV+100;
[n_sample,InputDim] = size(x);
model_bak.kerparam =struct('type','rbf','gamma',1/InputDim);

% train WOS-ELM  model
 rule=-1;
 fprintf('Training BWOSELM model...\n');
 gmean=[]; bm=[];  kappa=[]; auc=[]; T=[];va=[];
	for pp=1:mm
         tic;
         [model,acc,num] = k_BWOSELM_for_e6(x, y, model_bak,rule,0); 
         t=toc;
         acc=struct2cell(acc)';
         Acc=[Acc; acc];
         T=[T t];
         value=num.FP+num.FN-maxSV;
         va=[va value];
    end
Acc=cell2mat(Acc);
A_save=[Acc T'];
A_save=sum(A_save)/mm;
vaa=sum(va);
A_save=[A_save  vaa];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data9.csv', A_save )

% train BOW-ELM  model 
 Acc=[];T=[]; A_save=[];
 rule=2;
 fprintf('Training BOW-ELM model...\n');
 gmean=[]; bm=[];  kappa=[]; auc=[]; T=[];
	for pp=1:mm
         tic;
         [model,acc,num] = k_BWOSELM_for_e6(x, y, model_bak,rule,0); 
         t=toc;
          acc=struct2cell(acc)';
          Acc=[Acc; acc];
          T=[T t];
         value=num.FP+num.FN-maxSV;
         va=[va value];
    end
Acc=cell2mat(Acc);
A_save=[Acc T'];
A_save=sum(A_save)/mm;
vaa=sum(va);
A_save=[A_save  vaa];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data10.csv', A_save )




clc;clear;close all;
mm=20;
model_bak.para=400;
xlsx_name='C:\Users\dell\Desktop\MOA & Qi\MOA data for paper\RandomTree_105_imblance_2.csv';
[num]=xlsread(xlsx_name); 
num(1,:)=[];

[n,m]=size(num);
x=num(:, 1:m-1);
y=num(:, m);
clear num;

maxSV=6000;  gamma=1/size(x,2);
Acc=[];AAcc=[];Time=[]; ac=[];T=[];ACC=[];
% select kernel
hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
hp.gamma = gamma;

% inizialize an empty model
model_bak = model_init(@compute_kernel,hp);
model_bak.nu = 1;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV;  start  = model_bak.maxSV+100;
[n_sample,InputDim] = size(x);
model_bak.kerparam =struct('type','rbf','gamma',1/InputDim);

% train WOS-ELM  model
 rule=-1;
 fprintf('Training BWOSELM model...\n');
 gmean=[]; bm=[];  kappa=[]; auc=[]; T=[];va=[];
	for pp=1:mm
         tic;
         [model,acc,num] = k_BWOSELM_for_e6(x, y, model_bak,rule,0); 
         t=toc;
         acc=struct2cell(acc)';
         Acc=[Acc; acc];
         T=[T t];
         value=num.FP+num.FN-maxSV;
         va=[va value];
    end
Acc=cell2mat(Acc);
A_save=[Acc T'];
A_save=sum(A_save)/mm;
vaa=sum(va);
A_save=[A_save  vaa];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data11.csv', A_save )

% train BOW-ELM  model 
 Acc=[];T=[]; A_save=[];
 rule=2;
 fprintf('Training BOW-ELM model...\n');
 gmean=[]; bm=[];  kappa=[]; auc=[]; T=[];
	for pp=1:mm
         tic;
         [model,acc,num] = k_BWOSELM_for_e6(x, y, model_bak,rule,0); 
         t=toc;
          acc=struct2cell(acc)';
          Acc=[Acc; acc];
          T=[T t];
         value=num.FP+num.FN-maxSV;
         va=[va value];
    end
Acc=cell2mat(Acc);
A_save=[Acc T'];
A_save=sum(A_save)/mm;
vaa=sum(va);
A_save=[A_save  vaa];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data12.csv', A_save )



clc;clear;close all;
mm=20;

xlsx_name='C:\Users\dell\Desktop\MOA & Qi\MOA data for paper\STAG_imbalance_1.csv';
[num]=xlsread(xlsx_name); 
num(1,:)=[];

[n,m]=size(num);
x=num(:, 1:m-1);
y=num(:, m);
clear num;

maxSV=6000;  gamma=1/size(x,2);
Acc=[];AAcc=[];Time=[]; ac=[];T=[];ACC=[];
% select kernel
hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
hp.gamma = gamma;

% inizialize an empty model
model_bak = model_init(@compute_kernel,hp);
model_bak.nu = 1;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV;  start  = model_bak.maxSV+100;
[n_sample,InputDim] = size(x);
model_bak.kerparam =struct('type','rbf','gamma',1/InputDim);

% train WOS-ELM  model
 rule=-1;
 fprintf('Training BWOSELM model...\n');
 gmean=[]; bm=[];  kappa=[]; auc=[]; T=[];va=[];
	for pp=1:mm
         tic;
         [model,acc,num] = k_BWOSELM_for_e6(x, y, model_bak,rule,0); 
         t=toc;
         acc=struct2cell(acc)';
         Acc=[Acc; acc];
         T=[T t];
         value=num.FP+num.FN-maxSV;
         va=[va value];
    end
Acc=cell2mat(Acc);
A_save=[Acc T'];
A_save=sum(A_save)/mm;
vaa=sum(va);
A_save=[A_save  vaa];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data13.csv', A_save )

% train BOW-ELM  model 
 Acc=[];T=[]; A_save=[];
 rule=2;
 fprintf('Training BOW-ELM model...\n');
 gmean=[]; bm=[];  kappa=[]; auc=[]; T=[];
	for pp=1:mm
         tic;
         [model,acc,num] = k_BWOSELM_for_e6(x, y, model_bak,rule,0); 
         t=toc;
          acc=struct2cell(acc)';
          Acc=[Acc; acc];
          T=[T t];
         value=num.FP+num.FN-maxSV;
         va=[va value];
    end
Acc=cell2mat(Acc);
A_save=[Acc T'];
A_save=sum(A_save)/mm;
vaa=sum(va);
A_save=[A_save  vaa];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data14.csv', A_save )




clc;clear;close all;
mm=20;

xlsx_name='C:\Users\dell\Desktop\MOA & Qi\MOA data for paper\STAG_imbalance_2.csv';
[num]=xlsread(xlsx_name); 
num(1,:)=[];

[n,m]=size(num);
x=num(:, 1:m-1);
y=num(:, m);
clear num;

maxSV=6000;  gamma=1/size(x,2);
Acc=[];AAcc=[];Time=[]; ac=[];T=[];ACC=[];
% select kernel
hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
hp.gamma = gamma;

% inizialize an empty model
model_bak = model_init(@compute_kernel,hp);
model_bak.nu = 1;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV;  start  = model_bak.maxSV+100;
[n_sample,InputDim] = size(x);
model_bak.kerparam =struct('type','rbf','gamma',1/InputDim);

% train WOS-ELM  model
 rule=-1;
 fprintf('Training BWOSELM model...\n');
 gmean=[]; bm=[];  kappa=[]; auc=[]; T=[];va=[];
	for pp=1:mm
         tic;
         [model,acc,num] = k_BWOSELM_for_e6(x, y, model_bak,rule,0); 
         t=toc;
         acc=struct2cell(acc)';
         Acc=[Acc; acc];
         T=[T t];
         value=num.FP+num.FN-maxSV;
         va=[va value];
    end
Acc=cell2mat(Acc);
A_save=[Acc T'];
A_save=sum(A_save)/mm;
vaa=sum(va);
A_save=[A_save  vaa];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data15.csv', A_save )

% train BOW-ELM  model 
 Acc=[];T=[]; A_save=[];
 rule=2;
 fprintf('Training BOW-ELM model...\n');
 gmean=[]; bm=[];  kappa=[]; auc=[]; T=[];
	for pp=1:mm
         tic;
         [model,acc,num] = k_BWOSELM_for_e6(x, y, model_bak,rule,0); 
         t=toc;
          acc=struct2cell(acc)';
          Acc=[Acc; acc];
          T=[T t];
         value=num.FP+num.FN-maxSV;
         va=[va value];
    end
Acc=cell2mat(Acc);
A_save=[Acc T'];
A_save=sum(A_save)/mm;
vaa=sum(va);
A_save=[A_save  vaa];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data16.csv', A_save )




