% clc;clear;close all;
% 
% % num=[];
% % [num1]=xlsread('C:\Users\dell\Desktop\MOA & Qi\KDD for paper\data1.csv'); 
% % num1(1,:)=[];
% % num=[num;num1];
% % clear num1
% % 
% % [num2]=xlsread('C:\Users\dell\Desktop\MOA & Qi\KDD for paper\data2.csv'); 
% % num=[num;num2];
% % clear num2
% % [num3]=xlsread('C:\Users\dell\Desktop\MOA & Qi\KDD for paper\data3.csv'); 
% % num=[num;num3];
% % clear num3
% % [num4]=xlsread('C:\Users\dell\Desktop\MOA & Qi\KDD for paper\data4.csv'); 
% % num=[num;num4];
% % clear num4
% % 
% % clear a b num num_save1 ans m n num1
% % clear y
% % save kdd;
% 

% clc;clear;close all;
% mm=10;
% load kdd
% num(1,:)=[];
% 
% rowrank = randperm(size(num, 1)); % ������ҵ����֣���1~��������
% num = num(rowrank, :);%%����rowrank���Ҿ��������
% 
% [n,m]=size(num);
% x=num(:, 1:m-1);
% y=num(:, m);
% clear num;
% 
% maxSV=6000;  gamma=1/size(x,2);
% Acc=[];
% % select kernel
% hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
% hp.gamma = gamma;
% 
% % inizialize an empty model
% model_bak = model_init(@compute_kernel,hp);
% model_bak.nu = 1;  model_bak.para=400;
% %%%%%%%%%%%%%%%%%%%%
% % set maximum number of support vectors for Forgetron
% model_bak.maxSV = maxSV;  start  = model_bak.maxSV+100;
% [n_sample,InputDim] = size(x);
% model_bak.kerparam =struct('type','rbf','gamma',1/InputDim);
% 
% model_bak.nu = 1;
% %%%%%%%%%%%%%%%%%%%%
% % set maximum number of support vectors for Forgetron
% model_bak.maxSV = maxSV; 
% start  = model_bak.maxSV+100;
% model_bak.verbose = 1; %2;
% model_bak.cleanPeriod = 20;
% model_bak.repeat = 20;
% model_bak.block = 1;
% rule=2;
% model_bak.parfor=1;
% i_rule_addin=0;
% tic;
% acc_t = k_BWOSELM(x,y,model_bak,rule,i_rule_addin); 
% time=toc;
% for i=1:model_bak.repeat 
%     acc=struct2cell(acc_t(i));
%     acc=cell2mat(acc);
%     Acc=[Acc; acc'];  
% end
% zero_fill=repmat(0,model_bak.repeat,1);
% average_Acc=sum(Acc)/model_bak.repeat;
% A_s=[average_Acc  time/model_bak.repeat];
% Acc= [Acc  zero_fill];
% A_save=[Acc;A_s];
% csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data2.csv', A_save);


% 
% clc;clear;close all;
% % num=[];
% % [num1]=xlsread('C:\Users\dell\Desktop\MOA & Qi\IntalLabs - for paper\inteldata_1.csv'); 
% % num1(1,:)=[];
% % num=[num;num1];
% % clear num1
% % 
% % [num2]=xlsread('C:\Users\dell\Desktop\MOA & Qi\IntalLabs - for paper\inteldata_2.csv'); 
% % num=[num;num2];
% % clear num2
% % [num3]=xlsread('C:\Users\dell\Desktop\MOA & Qi\IntalLabs - for paper\inteldata_3.csv'); 
% % num=[num;num3];
% % clear num3
% % 
% % [n,m]=size(num);  
% % 
% % num1=num(:,[1 3 4 5]);
% % y=num(:,6);
% % num1(isnan(num1))=0;
% % 
% % [num_save1,a,b] = zscore(num1);
% % inteldata=[num_save1 y];
% % clear a b num num_save1 ans m n num1
% % clear y
% % save inteldata;
% 
load inteldata;
inteldata(1,:)=[];
rowrank = randperm(size(inteldata, 1)); % ������ҵ����֣���1~��������
inteldata = inteldata(rowrank, :);%%����rowrank���Ҿ��������

[n,m]=size(inteldata);       
x=inteldata(:, 1:m-1);   
y=inteldata(:, m);
clear inteldata;

maxSV=20000;  gamma=1/size(x,2);
Acc=[];
% select kernel
hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
hp.gamma = gamma;

% inizialize an empty model
model_bak = model_init(@compute_kernel,hp);
model_bak.nu = 1;model_bak.para=400;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV;  start  = model_bak.maxSV+100;
[n_sample,InputDim] = size(x);
model_bak.kerparam =struct('type','rbf','gamma',1/InputDim);

model_bak.nu = 1;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV; 
start  = model_bak.maxSV+100;
model_bak.verbose = 1; %2;
model_bak.cleanPeriod = 20;
model_bak.repeat = 20;
model_bak.block = 1;
model_bak.parfor = 1;
rule=2;
i_rule_addin=0;
tic;
acc_t = k_BWOSELM(x,y,model_bak,rule,i_rule_addin); 
time=toc;
for i=1:model_bak.repeat 
    acc=struct2cell(acc_t(i));
    acc=cell2mat(acc);
    Acc=[Acc; acc'];  
end
zero_fill=repmat(0,model_bak.repeat,1);
average_Acc=sum(Acc)/model_bak.repeat;
A_s=[average_Acc  time/model_bak.repeat];
Acc= [Acc  zero_fill];
A_save=[Acc;A_s];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data3.csv', A_save);



