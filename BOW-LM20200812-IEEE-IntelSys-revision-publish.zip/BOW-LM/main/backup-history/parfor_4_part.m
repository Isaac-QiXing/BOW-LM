clc;clear;close all;
xlsx_name='C:\Users\dell\Desktop\MOA & Qi\MOA data for paper\RandomRBF_10.csv';
[num]=xlsread(xlsx_name); 
num(1,:)=[];

[n,m]=size(num);    
x=num(:, 1:m-1);   
y=num(:, m);
clear num;

maxSV=6000;  gamma=1/size(x,2);
Acc=[];
% select kernel
hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
hp.gamma = gamma;

% inizialize an empty model
model_bak = model_init(@compute_kernel,hp);
model_bak.nu = 1;model_bak.para=400;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV;  start  = model_bak.maxSV+100;
[n_sample,InputDim] = size(x);
model_bak.kerparam =struct('type','rbf','gamma',1/InputDim);

model_bak.nu = 1;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV; 
start  = model_bak.maxSV+100;
model_bak.verbose = 1; %2;
model_bak.cleanPeriod = 20;
model_bak.repeat = 20;
model_bak.block = 1;
rule=2;
i_rule_addin=0;
tic;
acc_t = k_BWOSELM(x,y,model_bak,rule,i_rule_addin); 
time=toc;
for i=1:model_bak.repeat 
    acc=struct2cell(acc_t(i));
    acc=cell2mat(acc);
    Acc=[Acc; acc'];  
end
zero_fill=repmat(0,model_bak.repeat,1);
average_Acc=sum(Acc)/model_bak.repeat;
A_s=[average_Acc  time/model_bak.repeat];
Acc= [Acc  zero_fill];
A_save=[Acc;A_s];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data1.csv', A_save);



clc;clear;close all;
xlsx_name='C:\Users\dell\Desktop\MOA & Qi\MOA data for paper\RandomRBF_10_imbalance_2.csv';
[num]=xlsread(xlsx_name); 
num(1,:)=[];

[n,m]=size(num);    
x=num(:, 1:m-1);   
y=num(:, m);
clear num;

maxSV=6000;  gamma=1/size(x,2);
Acc=[];
% select kernel
hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
hp.gamma = gamma;

% inizialize an empty model
model_bak = model_init(@compute_kernel,hp);
model_bak.nu = 1;model_bak.para=400;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV;  start  = model_bak.maxSV+100;
[n_sample,InputDim] = size(x);
model_bak.kerparam =struct('type','rbf','gamma',1/InputDim);

model_bak.nu = 1;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV; 
start  = model_bak.maxSV+100;
model_bak.verbose = 1; %2;
model_bak.cleanPeriod = 20;
model_bak.repeat = 20;
model_bak.block = 1;
rule=2;
i_rule_addin=0;
tic;
acc_t = k_BWOSELM(x,y,model_bak,rule,i_rule_addin); 
time=toc;
for i=1:model_bak.repeat 
    acc=struct2cell(acc_t(i));
    acc=cell2mat(acc);
    Acc=[Acc; acc'];  
end
zero_fill=repmat(0,model_bak.repeat,1);
average_Acc=sum(Acc)/model_bak.repeat;
A_s=[average_Acc  time/model_bak.repeat];
Acc= [Acc  zero_fill];
A_save=[Acc;A_s];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data2.csv', A_save);






clc;clear;close all;
xlsx_name='C:\Users\dell\Desktop\MOA & Qi\MOA data for paper\RandomRBF_200.csv';
[num]=xlsread(xlsx_name); 
num(1,:)=[];

[n,m]=size(num);    
x=num(:, 1:m-1);   
y=num(:, m);
clear num;

maxSV=6000;  gamma=1/size(x,2);
Acc=[];
% select kernel
hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
hp.gamma = gamma;

% inizialize an empty model
model_bak = model_init(@compute_kernel,hp);
model_bak.nu = 1;model_bak.para=400;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV;  start  = model_bak.maxSV+100;
[n_sample,InputDim] = size(x);
model_bak.kerparam =struct('type','rbf','gamma',1/InputDim);

model_bak.nu = 1;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV; 
start  = model_bak.maxSV+100;
model_bak.verbose = 1; %2;
model_bak.cleanPeriod = 20;
model_bak.repeat = 20;
model_bak.block = 1;
rule=2;
i_rule_addin=0;
tic;
acc_t = k_BWOSELM(x,y,model_bak,rule,i_rule_addin); 
time=toc;
for i=1:model_bak.repeat 
    acc=struct2cell(acc_t(i));
    acc=cell2mat(acc);
    Acc=[Acc; acc'];  
end
zero_fill=repmat(0,model_bak.repeat,1);
average_Acc=sum(Acc)/model_bak.repeat;
A_s=[average_Acc  time/model_bak.repeat];
Acc= [Acc  zero_fill];
A_save=[Acc;A_s];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data3.csv', A_save);



clc;clear;close all;
xlsx_name='C:\Users\dell\Desktop\MOA & Qi\MOA data for paper\RandomRBF_200_imbalance_2.csv';
[num]=xlsread(xlsx_name); 
num(1,:)=[];

[n,m]=size(num);    
x=num(:, 1:m-1);   
y=num(:, m);
clear num;

maxSV=6000;  gamma=1/size(x,2);
Acc=[];
% select kernel
hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
hp.gamma = gamma;

% inizialize an empty model
model_bak = model_init(@compute_kernel,hp);
model_bak.nu = 1;model_bak.para=400;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV;  start  = model_bak.maxSV+100;
[n_sample,InputDim] = size(x);
model_bak.kerparam =struct('type','rbf','gamma',1/InputDim);

model_bak.nu = 1;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV; 
start  = model_bak.maxSV+100;
model_bak.verbose = 1; %2;
model_bak.cleanPeriod = 20;
model_bak.repeat = 20;
model_bak.block = 1;
rule=2;
i_rule_addin=0;
tic;
acc_t = k_BWOSELM(x,y,model_bak,rule,i_rule_addin); 
time=toc;
for i=1:model_bak.repeat 
    acc=struct2cell(acc_t(i));
    acc=cell2mat(acc);
    Acc=[Acc; acc'];  
end
zero_fill=repmat(0,model_bak.repeat,1);
average_Acc=sum(Acc)/model_bak.repeat;
A_s=[average_Acc  time/model_bak.repeat];
Acc= [Acc  zero_fill];
A_save=[Acc;A_s];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data4.csv', A_save);



clc;clear;close all;
xlsx_name='C:\Users\dell\Desktop\MOA & Qi\MOA data for paper\TextGenerator.csv';
[num]=xlsread(xlsx_name); 
num(1,:)=[];

[n,m]=size(num);    
x=num(:, 1:m-1);   
y=num(:, m);
clear num;

maxSV=6000;  gamma=1/size(x,2);
Acc=[];
% select kernel
hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
hp.gamma = gamma;

% inizialize an empty model
model_bak = model_init(@compute_kernel,hp);
model_bak.nu = 1;model_bak.para=600;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV;  start  = model_bak.maxSV+100;
[n_sample,InputDim] = size(x);
model_bak.kerparam =struct('type','rbf','gamma',1/InputDim);

model_bak.nu = 1;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV; 
start  = model_bak.maxSV+100;
model_bak.verbose = 1; %2;
model_bak.cleanPeriod = 20;
model_bak.repeat = 20;
model_bak.block = 1;
rule=2;
i_rule_addin=0;
tic;
acc_t = k_BWOSELM(x,y,model_bak,rule,i_rule_addin); 
time=toc;
for i=1:model_bak.repeat 
    acc=struct2cell(acc_t(i));
    acc=cell2mat(acc);
    Acc=[Acc; acc'];  
end
zero_fill=repmat(0,model_bak.repeat,1);
average_Acc=sum(Acc)/model_bak.repeat;
A_s=[average_Acc  time/model_bak.repeat];
Acc= [Acc  zero_fill];
A_save=[Acc;A_s];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data5.csv', A_save);



clc;clear;close all;
xlsx_name='C:\Users\dell\Desktop\MOA & Qi\MOA data for paper\TextGenerator_imbalance_2.csv';
[num]=xlsread(xlsx_name); 
num(1,:)=[];

[n,m]=size(num);    
x=num(:, 1:m-1);   
y=num(:, m);
clear num;

maxSV=6000;  gamma=1/size(x,2);
Acc=[];
% select kernel
hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
hp.gamma = gamma;

% inizialize an empty model
model_bak = model_init(@compute_kernel,hp);
model_bak.nu = 1;model_bak.para=600;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV;  start  = model_bak.maxSV+100;
[n_sample,InputDim] = size(x);
model_bak.kerparam =struct('type','rbf','gamma',1/InputDim);

model_bak.nu = 1;
%%%%%%%%%%%%%%%%%%%%
% set maximum number of support vectors for Forgetron
model_bak.maxSV = maxSV; 
start  = model_bak.maxSV+100;
model_bak.verbose = 1; %2;
model_bak.cleanPeriod = 20;
model_bak.repeat = 20;
model_bak.block = 1;
rule=2;
i_rule_addin=0;
tic;
acc_t = k_BWOSELM(x,y,model_bak,rule,i_rule_addin); 
time=toc;
for i=1:model_bak.repeat 
    acc=struct2cell(acc_t(i));
    acc=cell2mat(acc);
    Acc=[Acc; acc'];  
end
zero_fill=repmat(0,model_bak.repeat,1);
average_Acc=sum(Acc)/model_bak.repeat;
A_s=[average_Acc  time/model_bak.repeat];
Acc= [Acc  zero_fill];
A_save=[Acc;A_s];
csvwrite('C:\Users\dell\Desktop\MOA & Qi\result\data6.csv', A_save);



