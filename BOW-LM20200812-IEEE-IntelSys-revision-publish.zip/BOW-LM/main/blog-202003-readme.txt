.\backup-history��folder consisting of main functions given by Qi-Kai,
Song  XiaoXin 
main_accuracy_bar: draw accuracy figures
main_baseline_method: main function to call BSGD, BOGD, Percepttron, LS-SVM
main_dataset_characteristic: get dataset characteristic 
main_k_BWOSELM: main function to call BOW-LM
 
main_readExcelData_as_mat.m�� excel raw data -> mat data format
main_readTxtData_as_mat.m�� excel Txt data -> mat data format
main_watch_H�� show the properties of H 

