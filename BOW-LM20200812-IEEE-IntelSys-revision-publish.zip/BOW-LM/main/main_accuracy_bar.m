% main_accuracy_bar
clear
clc

resultPath =  '..\result-summary\';

figurePath = '..\figure\';

fileName_c = {...
    'result_summary_BSGD_20200227T221342.mat',...
    'result_summary_BOGD_20200228T025918.mat',...
    'result_summary_perceptron_20200228T074639.mat',...
    'result_summary_LS-SVM_20200228T105737.mat',...
    'result_summary_BOW_LM_20200302T224953.mat',...
    };

alg_name_c = {'BSGD','BOGD','RBP','BOLSSVM','BOW-LM'};
alg_nickName_c = {'BSGD','BOGD','RBP','BOLS','BOW'};

debug_on = 0; %1;

% dataset_c = {...
%     'RandomRBF_10',...
%     'RandomRBF_10_imbalance_2',...
%     'RandomRBF_200',...
%     'RandomRBF_200_imbalance_2',...
%     'TextGenerator',...
%     'TextGenerator_imbalance_2',...
%     'STAG',...
%     'STAG_imbalance_2',...
%     'kdd',...
%     'yeast1',...
%     'yeast3',...
%     'yeast4',...
%     'yeast5',...
%     'yeast6',...
%     'abalone19',...
%     'page-blocks0',...
%     'shuttle-c0-vs-c4',...
%     };
dataset_c = {  'RBF_1',...
    'RBF_1b',...
    'RBF_2',...
    'RBF_2b',...
    'Text',...
    'Text_b',...
    'STAG',...
    'STAG_b',...
    'Kdd',...
    'Yeast1',...
    'Yeast3',...
    'Yeast4',...
    'Yeast5',...
    'Yeast6',...
    'Abalone',...
    'Page0',...
    'Shuttle0',...
    };

id_data_show_v = [10:17  1:9 ];
% id_data_show_v = [10:17  1:8 ];
ratio_outlier_v = [0, 0.02, 0.1,0.2];
ratio_outlier_c = {'0.0','0.02','0.1','0.2'};
%myFontSize = 24;
TickLabelFontSize = 18;
LabelFontSizeMultiplier = 1.4;
%zoomFactor = 0.4;


if debug_on
    dataset_c = {  'RBF_1'};
    id_data_show_v = 1;
end

% 1. load results
for i_data = 1:length(fileName_c)
    fileName = [ resultPath, fileName_c{i_data}];
    d_t(i_data) = load(fileName,'average_acc_array','average_acc_measure_c');
end

% fix incorrect results
d_t(4).average_acc_array(1:9,:,:) = NaN;
% BOLS-SVM results on these datasets are not true,
%     the saved results are mistakely those of RBP (perceptron)


% average_acc_array:
%   size: n_data * n_acc * n_ratio
% average_acc_measure_c:
%   accruracy names

obj_acc_s = 'gmean';
ismember_v = ismember(d_t(1).average_acc_measure_c,{obj_acc_s});
ind_acc = find(ismember_v);
if isempty(ind_acc)
    error('Do Not find the %s  accuracy.',obj_acc_s);
end
fwritef(1,'ind_acc',ind_acc,'%d');

% put the accuracies to a 3-dimentional matrix A
[n_data,n_acc,n_ratio]= size(d_t(1).average_acc_array);
n_alg = length(alg_name_c);
A = zeros(n_data,n_alg,n_ratio);
for i_alg = 1:n_alg
    A(:,i_alg,:) = d_t(i_alg).average_acc_array(:,ind_acc,:);
end

% shift dimenstion
A = shiftdim(A,1);
% A:   n_alg * n_ratio * n_data

% 2. plot bar figure
n_col = 4;
n_row = ceil(n_data/n_col);
% for i_data = length(id_data_show_v)  :length(id_data_show_v)
for i_data = 1:length(id_data_show_v)
    ind = id_data_show_v(i_data);
    dataName_s = dataset_c{ind};
    fwritef(1,'i_data',i_data,'','',dataName_s,'');
    % remove NaN
    A0 = A(:,:,ind); % A0: size: n_alg * n_ratio
    i_A = isnan(A0);
    %A0(i_A) = [];
    
    is_alg_show =  sum(i_A,2)==0 ;
    
    A1 = A0(is_alg_show,:);
    
    % bar plot
    %subplot(n_row,n_col,i_data);
    h = bar3(A1);
    %title(dataName_s);
    
    xlabel('r_o');
    zlabel(obj_acc_s);
    
    %set(gca,'YTickLabel', alg_nickName_c(is_alg_show));
    set(gca,'YTickLabel', alg_nickName_c(is_alg_show),'FontSize',TickLabelFontSize);
    set(gca,'XTickLabel', ratio_outlier_c);
    set(gca,'LabelFontSizeMultiplier',LabelFontSizeMultiplier);
    
% % %     % zoom   
% % %     zoom(zoomFactor);
    
    % clip the margin
    set(gca, 'Position', get(gca, 'OuterPosition') - ...
        get(gca, 'TightInset') * [-1 0 1 0; 0 -1 0 1; 0 0 1 0; 0 0 0 1]);
    
% % %     % set Tick Label font size
% % %     ax = ancestor(h, 'axes');
% % %     yrule = ax.YAxis;
% % %     xrule = ax.XAxis;
% % %     yrule.FontSize = myFontSize;
% % %     xrule.FontSize = myFontSize;
    %set(gca,'YLabel','$r_o$')
    % set(gca,'ZLabel',obj_acc_s);
    % save figure
    %pause
    % clip margin
    savefig(gcf,[figurePath dataName_s '.fig']);
    saveas(gcf,[figurePath dataName_s '.png']);
    
    close(figure(gcf)); % close the current figure
end

