% main_baseline_method.m
% The following algorithms are tested:
%  BSGD, BOGD, RBP(perceptron),  BOLS (LS-SVM)  ,

clc;
clear;

debug_on = 1; %1;
flag_save_to_xls = 0; %1; %0; % whether saved to xls files

%  datasets
dataPath = 'D:\data_BOW_LM\data_mat\';
resultPath = 'D:\result_BOW_LM\';

% dataPath = 'E:\BOW-LM202002\data_mat\';
% resultPath = 'E:\BOW-LM202002\result\';

if ~exist(resultPath,'dir')
    mkdir(resultPath);
end
fileName_c = {...
'RandomRBF_10.mat', 'RandomRBF_10_imbalance_2.mat',...
    'RandomRBF_200.mat', 'RandomRBF_200_imbalance_2.mat',...
    'TextGenerator.mat', 'TextGenerator_imbalance_2.mat',...
    'STAG.mat',  'STAG_imbalance_2.mat',...
    'kdd.mat',...    
'yeast1-5-1tra.mat','yeast3-5-1tra.mat','yeast4-5-1tra.mat','yeast5-5-1tra.mat','yeast6-5-1tra.mat',...
    'abalone19-5-1tra.mat', ...
    'page-blocks0-5-1tra.mat', ...
    'shuttle-c0-vs-c4-5-1tra.mat', ...
    };
if debug_on
%     fileName_c = {  'page-blocks0-5-1tra.mat', ...
%         'RandomRBF_200.mat', ...
%         };
    fileName_c = {   'kdd.mat'};
end

if debug_on
    %solver_str_c = {'LS-SVM'};
    solver_str_c = {'BSGD'};
    %solver_str_c = {'BSGD', 'BOGD', 'perceptron','LS-SVM'};
else
    solver_str_c = {'BSGD', 'BOGD', 'perceptron','LS-SVM'};
end    
solver_small_dataset_c = {'LS-SVM'}; 
    % solvers merely applied to small datasets
    
% parameters for adding outliers
arg_getData.dataFile = ''; %[dataPath 'abalone19-5-1tra.mat'];
arg_getData.variable_outlier = 'x';
arg_getData.variable_std = 'x';
arg_getData.variable_shuffle = {'x','y'}; % shuffle the order of the data records
%arg_getData.ratio_outlier = 0.1;
if debug_on
    ratio_outlier_v = 0.1 ; %[0.1,0.3];
else
    ratio_outlier_v = [0, 0.02, 0.1,0.2];
end
arg_getData.mean_outlier = 1.0;
arg_getData.variance_outlier = 16.0; %4.0;

% algorithm parameters
maxSV= 1000; %6000; % active set capacity (of LS-SVM)
nu = 1;
verbose = 1; %2;

if debug_on
    repeat = 1;
    repeat_large_set = repeat;
else
    repeat = 20; %20;
    repeat_large_set = 10; % repeat time on large data set 
end

block = 1;
% get number of samples and features of each dataset
n_dataset = length(fileName_c);
n_sample_v = zeros(1,n_dataset); % number of samples of each dataset
n_feature_v = zeros(1,n_dataset); % number of dimensions of each dataset
for i_data=1:n_dataset
    fileName = fileName_c{i_data};
    dataFile =  [dataPath fileName];
    dt  = load(dataFile,'n_sample_total','n_feature');
    n_sample_v(i_data) = dt.n_sample_total;
    n_feature_v(i_data) = dt.n_feature;
end
% * set arg_repeat_t

arg_repeat_t.repeat = repeat;
arg_repeat_t.parfor = [];
arg_repeat_t.gcp_delete = 0; % do not close parpool after calling each method
% set parfor_v for arg_repeat_t.parfor
is_large_dataset_v = n_sample_v.*n_feature_v >= 1E5;
    % determine whether it is a large dataset 

parfor_v =  is_large_dataset_v;  % whether employ parfor for repeat multiple calls
%%%
parfor_v = 0 ;
%%%
n_solver = length(solver_str_c);
n_ratio = length(ratio_outlier_v);

for i_solver = 1:n_solver    
    solver_str = solver_str_c{i_solver};     
    flag_solver_small_dataset = ismember({solver_str},solver_small_dataset_c);
        % whether the current solver only suits for small datasets     
    timeStamp0 = datestr(now,30);
    resultFile_summary_mat = [resultPath 'result_summary_' solver_str '_' timeStamp0 '.mat'];
    resultFile_summary_xls = [resultPath 'result_summary_' solver_str '_' timeStamp0 '.xlsx'];
    % result file containing summary of the results on various datasets    
    for i_ratio = 1:n_ratio
        for i_data = 1:n_dataset
            fprintf(1,'i_solver: %d/%d, \t i_ratio: %d/%d,\t i_data: %d/%d\n',...
                i_solver,n_solver, i_ratio,n_ratio,     i_data, n_dataset);
            %  1.1 set   parameters for getDataRecords
            fileName = fileName_c{i_data};
            arg_getData.dataFile =  [dataPath fileName];
            arg_getData.ratio_outlier = ratio_outlier_v(i_ratio);
            
            % 1.2 set model_bak
            n_feature = n_feature_v(i_data); % number of features
            hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2)
            hp.gamma = 1/n_feature;
            model_bak = model_init(@compute_kernel,hp);  % inizialize an empty model
            model_bak.nu = nu;
            model_bak.maxSV = maxSV;
            model_bak.block = block;
            model_bak.solver = solver_str; %          
            % 1.3 set arg_repeat_t
            arg_repeat_t.parfor = parfor_v(i_data);
            if is_large_dataset_v
                arg_repeat_t.repeat = repeat_large_set;
            else
                arg_repeat_t.repeat = repeat;
            end
            % 2. online learning
            if  flag_solver_small_dataset && is_large_dataset_v(i_data)
                continue;
            end
            [acc_t,seconds_v ]= repeatCall(@getDataRecords,@fun_OLM,{model_bak},...
                arg_repeat_t,arg_getData);
            % 3. output accuracies
            ratio_str = ['ratio_' num2str(i_ratio)];
            [~,name_str] = fileparts(fileName);
            timeStamp = datestr(now,30);
            resultFile_mat = [resultPath 'result_repeat_' name_str '_' ratio_str '_' timeStamp '.mat'];
            resultFile_xls= [resultPath 'result_repeat_' name_str '_' ratio_str '_' timeStamp '.xlsx'];
                      
            seconds_c = num2cell(seconds_v);
            [acc_t(:).seconds ] = deal(seconds_c{:});
            acc_b = struct2table(acc_t);
            Acc =   table2array(acc_b);
            average_acc = mean(Acc);
            A_save=[Acc;average_acc ];
            average_acc_measure0_c = fieldnames(acc_t);
            average_acc_measure_c =   average_acc_measure0_c'  ;
            %  measures of accuracies corresponding to average_acc            
           
            % 3.1 save the detailed accuracies on current dataset
            save(resultFile_mat,'acc_t','Acc','average_acc','average_acc_measure_c','timeStamp',...
                'model_bak','arg_getData','arg_repeat_t');
            if flag_save_to_xls
                fwritexls(resultFile_xls, '',model_bak,'A1','model_bak'); % save model_bak
                fwritexls(resultFile_xls, '',arg_getData,'A1','arg_getData'); % save arg_getData
                fwritexls(resultFile_xls, '',timeStamp,'A1','sheet1'); % save timeStamp
                fwritexls(resultFile_xls, average_acc_measure_c,A_save,'B2','sheet1'); % save the accuracies
            end
            % 3.2 save the mean accuracies on current dataset to a common specified file
            % 3.2.1 put out to Excel files
            if i_data ==1 &&   flag_save_to_xls
                % put out the title row
                fwritexls(resultFile_summary_xls, '',{'dataset','time stamp'},'A1',  ratio_str);
                fwritexls(resultFile_summary_xls, '',average_acc_measure_c,'C1',  ratio_str);
            end
            if   flag_save_to_xls
                cellA_str = ['A' num2str(i_data+1)];
                cellB_str = ['C' num2str(i_data+1)];
                fwritexls(resultFile_summary_xls, '',{name_str,timeStamp},cellA_str, ratio_str);
                fwritexls(resultFile_summary_xls, '',average_acc,cellB_str, ratio_str);
            end
            % 3.2.2 putput to mat files
            InfDataSet_c(i_data,1:2,i_ratio) =    {name_str,timeStamp};
            average_acc_array(i_data,:,i_ratio) = average_acc; % the 3-rd dimension is the ratio of outlier
            save(resultFile_summary_mat,'InfDataSet_c','average_acc_array','average_acc_measure_c');
        end
    end
end

% close parpool
if ~isempty(gcp('nocreate'))
    delete(gcp('nocreate'))
end

