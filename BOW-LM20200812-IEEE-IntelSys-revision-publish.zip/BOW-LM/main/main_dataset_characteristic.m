%main_dataset_characteristic 
clear 
clc

dataPath = 'D:\data_BOW_LM\data_mat\';

lst_st = dir(dataPath);

for ii=1:length(lst_st)
    if ~lst_st(ii).isdir
        fileName = lst_st(ii).name;
        [~,~,ext]= fileparts(fileName);
        if strcmpi(ext,'.mat')
            dt(ii) = load([dataPath fileName],'n_sample_total','n_feature','n_positive','n_negative');
            
            dt2(ii).fileName = fileName; 
        end
    end
end

dt3= assign_struct(dt,[],dt2);

dt_tb = struct2table(dt3);
varName_c = dt_tb.Properties.VariableNames ;
C = table2cell(dt_tb);
 fwritexls('table_characteristic.xls',varName_c ,C);
