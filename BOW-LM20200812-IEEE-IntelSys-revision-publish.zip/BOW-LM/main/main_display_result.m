%main_display_result.m

% transform the results for display

flag =0 ; % result 1
if flag==1
    resultFile = 'result_count_outlier_20200810T114331.mat';
else
    resultFile = 'result_role_alpha_quantile_20200810T154252.mat';
end

dt = load(resultFile,'result_display_c');

result_c = dt.result_display_c;
n_field = length(result_c);
n_dataset = size(result_c{1},1);

% reorder the datasets for display
% fileName_display_c = {...
%     'yeast1-5-1tra.mat','yeast3-5-1tra.mat','yeast4-5-1tra.mat','yeast5-5-1tra.mat','yeast6-5-1tra.mat',...
%     'abalone19-5-1tra.mat', ...
%     'page-blocks0-5-1tra.mat', ...
%     'shuttle-c0-vs-c4-5-1tra.mat', ...
%     'RandomRBF_10.mat', 'RandomRBF_10_imbalance_2.mat',...
%     'RandomRBF_200.mat', 'RandomRBF_200_imbalance_2.mat',...
%     'TextGenerator.mat', 'TextGenerator_imbalance_2.mat',...
%     'STAG.mat',  'STAG_imbalance_2.mat',...
%     'kdd.mat',...
%     };
fileName_display_c = {'Yeast1','Yeast3','Yeast4','Yeast5','Yeast6',...
    'Abalone','Page0','Shuttle0',...
   'RBF_1','RBF_1b','RBF_2','RBF_2b','Text','Text_b','STAG','STAG_b','KDD'};

dataset_id_v = (1:n_dataset)';

if flag==1
    field_legend_c  = {'$r_0 = 0\%$','$r_0 = 2\%$','$r_0 = 10\%$','$r_0 = 20\%$'};
else
    field_legend_c  = {'$\alpha_{\textnormal{quantile}} = 0.0$',...
        '$\alpha_{\textnormal{quantile}} = 1.5$',...
        '$\alpha_{\textnormal{quantile}} = 3.0$',...
        '$\alpha_{\textnormal{quantile}} = 5.0$',...
        '$\alpha_{\textnormal{quantile}} = 8.0$'        };
end
       % [0, 1.5,  3.0,  5.0,  8.0]; 

% add dataset name and the field legend for each group of results
for i_field = 1:n_field
    result_tb = result_c{i_field};
    field_s = field_legend_c{i_field};
    result_tb.dataset = fileName_display_c';
    result_tb.field =   repmat(string(field_s), n_dataset, 1);
    result_tb.id = (dataset_id_v-1)*n_field+i_field-1;
    result_c{i_field} = result_tb;
end

% merge the group of tables
result_tb = [];
for i_field = 1:n_field
    result0 = result_c{i_field};
    if isempty(result_tb)
        result_tb = result0;
    else
        result_tb = [result_tb; result0];
    end
end


% display
field_numeric_display_c  = {'TP','FP','TN','FN','TPR','FPR','TNR','FDR'};
result2_tb = sortrows(result_tb,'id');
result2_tb{:,field_numeric_display_c}(isnan(result2_tb{:,field_numeric_display_c})) = 0 ; %repalce NaN as 0
result_merge_tb = result2_tb(:,{'dataset','field','TP','FP','TN','FN','TPR','FPR','TNR','FDR'});
save(resultFile,'result_merge_tb','-append');






