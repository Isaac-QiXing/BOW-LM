%function main_identify_outlier()
% count the number of correctly/incorrectly identified outliers
%  * versions:
%   2020.8.7 first version


clear
clc

debug_on = 0;

% 0. load data

% 0.1 parameters
dataPath = 'E:\data_BOW_LM\data_mat\';
resultPath = 'E:\result_BOW_LM\';
% dataPath = 'D:\data_BOW_LM\data_mat\';
% resultPath = 'D:\result_BOW_LM\';
timeStr = datestr(now,30);
fileName_mat = ['result_count_outlier_' timeStr '.mat'];
% fileName_c = {
%     'RandomRBF_10.mat',...
%    'page-blocks0-5-1tra.mat', ...
%    'abalone19-5-1tra.mat', ...
%     };
fileName_c = {...
    'RandomRBF_10.mat', 'RandomRBF_10_imbalance_2.mat',...
    'RandomRBF_200.mat', 'RandomRBF_200_imbalance_2.mat',...
    'TextGenerator.mat', 'TextGenerator_imbalance_2.mat',...
    'STAG.mat',  'STAG_imbalance_2.mat',...
    'kdd.mat',...
    'yeast1-5-1tra.mat','yeast3-5-1tra.mat','yeast4-5-1tra.mat','yeast5-5-1tra.mat','yeast6-5-1tra.mat',...
    'abalone19-5-1tra.mat', ...
    'page-blocks0-5-1tra.mat', ...
    'shuttle-c0-vs-c4-5-1tra.mat', ...
    };

arg.variable_outlier = 'x';
arg.variable_std = 'x';
arg.variable_shuffle = {'x','y'}; % shuffle the order of the data records

if debug_on
    ratio_outlier_v = [0, 0.1];
    n_repeat = 2; 
else
    ratio_outlier_v = [0, 0.02, 0.1,0.2];
    n_repeat = 20;  
end
% arg.ratio_outlier = 0.1 ;

arg.mean_outlier = 1.0; %1.0;
arg.variance_outlier = 4.0; %4.0;

arg.dim = 2;
arg.iqr = 5;
arg.dist = 'norm1';

n_data = length(fileName_c);
inf_outlier_t = struct(); % struct of outlier numbers


if debug_on
    flag_downsampling = 1;
    n_downsampling = 5000;
else
    flag_downsampling = 0;
    n_downsampling = 0;
end

n_row_down_H = 6000;

%i_watch = 0;
for i_data = 1:n_data
    fwritef(1,'i_data',i_data,'');
    
    for i_ratio = 1:length(ratio_outlier_v)
        
        for i_repeat = 1:n_repeat
            
            ratio_outlier = ratio_outlier_v(i_ratio);
            arg.ratio_outlier = ratio_outlier;
            fwritef(1,'ratio_outlier',ratio_outlier,'');
            
            fileName = fileName_c{i_data};
            arg.dataFile =  [dataPath fileName];
            [data_st] = getDataRecords(arg);
            
            % 0.2 downsampling
            data_st.is_outlier = false(data_st.n_sample_total,1);
            data_st.is_outlier(data_st.index_outlier) = 1;
            
            if flag_downsampling && data_st.n_sample_total > n_downsampling
                data_st   = downsampling(data_st,{'x','y','is_outlier'},n_downsampling);
            end
            is_outlier_true = data_st.is_outlier;
            [n_sample,InputDim] = size(data_st.x);
            
            % 2. count the number of identified  outliers based on the matrix H
            
            % 2.1. calculate matrix H
            para = 400;
            % para = 10; %400;
            nn = length('TextGenerator');
            if strncmpi('TextGenerator',fileName,nn)
                para = 600;
            end
            
            nHiddenNeurons = para;
            
            model_p.IW = rand(nHiddenNeurons,InputDim)*2-1;
            model_p.Bias= rand(1,nHiddenNeurons)*2-1;
            
            H= SigActFun(data_st.x,model_p.IW ,model_p.Bias);
            
            H= 1./H ;  % transformation , a kep operation
            
            % 2.2. find outliers based on the matrix H
            
            % (1) calculate the center
            if n_row_down_H< n_sample
                H_downsample = H(1:n_row_down_H,:);
            else
                H_downsample = H;
            end
            
            [ H_center, thresh_outlier,dist_v] = getThresh_outlier(H_downsample,arg);
            fwritef(1,'thresh_outlier',thresh_outlier,'');
            % (2) find outliers
            arg.center = H_center;
            arg.thresh = thresh_outlier;
            [prob_outlier] = isOutlier(H,arg);
            
            true_outlier_v = -1*ones(size(is_outlier_true));
            true_outlier_v(is_outlier_true) = 1;
            % set pred_is_outlier_v: 1: prediced as outlier; -1: normal instance
            pred_is_outlier_v = ones(size(prob_outlier))*(-1);
            pred_is_outlier_v((prob_outlier*1.0)>0.5) = 1;            
            %[acc_t(i_data,i_ratio,i_repeat),num_outlier_t(i_data,i_ratio,i_repeat) ]=accuracyIndex_0(pred_is_outlier_v,true_outlier_v);
            [acc0_t(i_repeat), num_outlier0_t(i_repeat) ]=accuracyIndex_0(pred_is_outlier_v,true_outlier_v);     
        end
        acc_t(i_data,i_ratio) =  structArrayFun(acc0_t,@mean);
        num_outlier_t(i_data,i_ratio) =  structArrayFun(num_outlier0_t,@mean);
        save(fileName_mat,'num_outlier_t','acc_t','arg');
    end
end

% output: transform the struct array to Table

% reorder the datasets for display 
fileName_display_c = {...
    'yeast1-5-1tra.mat','yeast3-5-1tra.mat','yeast4-5-1tra.mat','yeast5-5-1tra.mat','yeast6-5-1tra.mat',...    
    'abalone19-5-1tra.mat', ...
    'page-blocks0-5-1tra.mat', ...
    'shuttle-c0-vs-c4-5-1tra.mat', ...
    'RandomRBF_10.mat', 'RandomRBF_10_imbalance_2.mat',...
    'RandomRBF_200.mat', 'RandomRBF_200_imbalance_2.mat',...
    'TextGenerator.mat', 'TextGenerator_imbalance_2.mat',...
    'STAG.mat',  'STAG_imbalance_2.mat',...
    'kdd.mat',...    
  }; 

[lia,locb] = ismember(fileName_display_c,fileName_c);
n_ratio = length(ratio_outlier_v);
result_c =cell(1,n_ratio);
result_display_c =cell(1,n_ratio);

varIsInMat = @(name) ~isempty(who( name,'-file',fileName_mat));
for i_ratio = 1:length(ratio_outlier_v)
    acc_b = struct2table(acc_t(:,i_ratio));
    num_outlier_b = struct2table(num_outlier_t(:,i_ratio));
    result_b = join(acc_b,num_outlier_b); 
    result_c{i_ratio} = result_b ;     
    result_display_c{i_ratio}= result_b(locb,:); 
end
% if 'result_c'  or 'result_dispaly_c' existed, then creat a new file 
%  to store result_c, result_display_c 
if varIsInMat('result_c') || varIsInMat('result_dispaly_c')
    timeStr = datestr(now,30);
    fileName2_mat = ['result_count_outlier_' timeStr '.mat'];
else
    fileName2_mat = fileName_mat; 
end  
save(fileName2_mat,'result_c','result_display_c','-append');






