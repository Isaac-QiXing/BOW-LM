%function main_identify_outlier()
% check the role of arg.iqr (defaut 5.0) for counting the number of
%    correctly/incorrectly identified outliers 
%  * versions:
%   2020.8.10 first version


clear
clc

debug_on = 0;  %1; %

% 0. load data

% 0.1 parameters
dataPath = 'E:\data_BOW_LM\data_mat\';
resultPath = 'E:\result_BOW_LM\';
% dataPath = 'D:\data_BOW_LM\data_mat\';
% resultPath = 'D:\result_BOW_LM\';
timeStr = datestr(now,30);
fileName_mat = ['result_role_alpha_quantile_' timeStr '.mat'];

fileName_c = {...
    'RandomRBF_10.mat', 'RandomRBF_10_imbalance_2.mat',...
    'RandomRBF_200.mat', 'RandomRBF_200_imbalance_2.mat',...
    'TextGenerator.mat', 'TextGenerator_imbalance_2.mat',...
    'STAG.mat',  'STAG_imbalance_2.mat',...
    'kdd.mat',...
    'yeast1-5-1tra.mat','yeast3-5-1tra.mat','yeast4-5-1tra.mat','yeast5-5-1tra.mat','yeast6-5-1tra.mat',...
    'abalone19-5-1tra.mat', ...
    'page-blocks0-5-1tra.mat', ...
    'shuttle-c0-vs-c4-5-1tra.mat', ...
    };

% if debug_on 
%     fileName_c = {
%     'RandomRBF_10.mat',...
%     'page-blocks0-5-1tra.mat', ...
%     'abalone19-5-1tra.mat', ...
%     };
% end

arg.variable_outlier = 'x';
arg.variable_std = 'x';
arg.variable_shuffle = {'x','y'}; % shuffle the order of the data records

% set arg.ratio_outlier
% if debug_on
%     ratio_outlier_v = [0, 0.1];
%     n_repeat = 2; 
% else
%     ratio_outlier_v = [0, 0.02, 0.1,0.2];
%     n_repeat = 20;  
% end
arg.ratio_outlier = 0.1 ;

% set iqr 
if debug_on
    iqr_v = [1.5, 3.0];    
else
    iqr_v = [0, 1.5,  3.0,  5.0,  8.0];    
end
n_iqr = length(iqr_v);
% set n_repeat
if debug_on
    n_repeat = 2;
else
    n_repeat = 20;
end

arg.mean_outlier = 1.0; %1.0;
arg.variance_outlier = 4.0; %4.0;

arg.dim = 2;
%arg.iqr = 5;
arg.dist = 'norm1';

n_data = length(fileName_c);
inf_outlier_t = struct(); % struct of outlier numbers


if debug_on
    flag_downsampling = 1;
    n_downsampling = 5000;
else
    flag_downsampling = 0;
    n_downsampling = 0;
end

n_row_down_H = 6000;

%i_watch = 0;
for i_data = 1:n_data
    fwritef(1,'i_data',i_data,''); 
    for i_iqr = 1:n_iqr        
        for i_repeat = 1:n_repeat   
            iqr = iqr_v(i_iqr);
            arg.iqr = iqr;
            fwritef(1,'iqr',iqr,'');            
            fileName = fileName_c{i_data};
            arg.dataFile =  [dataPath fileName];
            [data_st] = getDataRecords(arg);
            
            % 0.2 downsampling
            data_st.is_outlier = false(data_st.n_sample_total,1);
            data_st.is_outlier(data_st.index_outlier) = 1;
            
            if flag_downsampling && data_st.n_sample_total > n_downsampling
                data_st   = downsampling(data_st,{'x','y','is_outlier'},n_downsampling);
            end
            is_outlier_true = data_st.is_outlier;
            [n_sample,InputDim] = size(data_st.x);
            
            % 2. count the number of identified  outliers based on the matrix H            
            % 2.1. calculate matrix H
            para = 400;
            % para = 10; %400;
            nn = length('TextGenerator');
            if strncmpi('TextGenerator',fileName,nn)
                para = 600;
            end
            
            nHiddenNeurons = para;            
            model_p.IW = rand(nHiddenNeurons,InputDim)*2-1;
            model_p.Bias= rand(1,nHiddenNeurons)*2-1;            
            H= SigActFun(data_st.x,model_p.IW ,model_p.Bias);            
            H= 1./H ;  % transformation , a kep operation
            
            % 2.2. find outliers based on the matrix H            
            % (1) calculate the center
            if n_row_down_H< n_sample
                H_downsample = H(1:n_row_down_H,:);
            else
                H_downsample = H;
            end
            
            [ H_center, thresh_outlier,dist_v] = getThresh_outlier(H_downsample,arg);
            fwritef(1,'thresh_outlier',thresh_outlier,'');
            % (2) find outliers
            arg.center = H_center;
            arg.thresh = thresh_outlier;
            [prob_outlier] = isOutlier(H,arg);
            
            true_outlier_v = -1*ones(size(is_outlier_true));
            true_outlier_v(is_outlier_true) = 1;
            % set pred_is_outlier_v: 1: prediced as outlier; -1: normal instance
            pred_is_outlier_v = ones(size(prob_outlier))*(-1);
            pred_is_outlier_v((prob_outlier*1.0)>0.5) = 1;            
           [acc0_t(i_repeat), num_outlier0_t(i_repeat) ]=accuracyIndex_0(pred_is_outlier_v,true_outlier_v);     
        end
        acc_t(i_data,i_iqr) =  structArrayFun(acc0_t,@mean);
        num_outlier_t(i_data,i_iqr) =  structArrayFun(num_outlier0_t,@mean);
        save(fileName_mat,'num_outlier_t','acc_t','arg');
    end
end

% reorder the datasets for display 
fileName_display_c = {...
    'yeast1-5-1tra.mat','yeast3-5-1tra.mat','yeast4-5-1tra.mat','yeast5-5-1tra.mat','yeast6-5-1tra.mat',...    
    'abalone19-5-1tra.mat', ...
    'page-blocks0-5-1tra.mat', ...
    'shuttle-c0-vs-c4-5-1tra.mat', ...
    'RandomRBF_10.mat', 'RandomRBF_10_imbalance_2.mat',...
    'RandomRBF_200.mat', 'RandomRBF_200_imbalance_2.mat',...
    'TextGenerator.mat', 'TextGenerator_imbalance_2.mat',...
    'STAG.mat',  'STAG_imbalance_2.mat',...
    'kdd.mat',...    
  }; 

[lia,locb] = ismember(fileName_display_c,fileName_c);
 
result_c =cell(1,n_iqr);
result_display_c =cell(1,n_iqr);
 
for i_iqr = 1:n_iqr
    acc_b = struct2table(acc_t(:,i_iqr));
    num_outlier_b = struct2table(num_outlier_t(:,i_iqr));
    result_b = join(acc_b,num_outlier_b); 
    result_c{i_iqr} = result_b ;     
    result_display_c{i_iqr}= result_b(locb,:); 
end 
save(fileName_mat,'result_c','result_display_c','-append');
