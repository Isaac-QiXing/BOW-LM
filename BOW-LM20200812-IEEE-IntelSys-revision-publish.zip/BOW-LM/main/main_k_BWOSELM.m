% main_k_BWOSELM.m

% call k_BWOSELM.m on various datasets with rule =2  (maximum judgement
% criterion)
clc;
clear;

debug_on =  0; %1; %2;% 1; %1;
% 2: go throgh all the datasets rapidly 

if debug_on 
    flag_save_to_xls = 0; %0; % whether saved to xls files
else
    flag_save_to_xls = 1; 
end
flag_downsampling = 0; %debug_on;
n_row_down = 7000;

if debug_on==2
    flag_downsampling = 1;  
    n_row_down = 700;
end

%  datasets
%dataPath = 'D:\data_BOW_LM\data_mat\';
%resultPath = 'D:\result_BOW_LM\';
dataPath = 'E:\data_BOW_LM\data_mat\';
resultPath = 'E:\result_BOW_LM\';


if ~exist(resultPath,'dir')
    mkdir(resultPath);
end
fileName_c = {...
    'RandomRBF_10.mat', 'RandomRBF_10_imbalance_2.mat',...
    'RandomRBF_200.mat', 'RandomRBF_200_imbalance_2.mat',...
    'TextGenerator.mat', 'TextGenerator_imbalance_2.mat',...
    'STAG.mat',  'STAG_imbalance_2.mat',...
    'kdd.mat',...
    'yeast1-5-1tra.mat','yeast3-5-1tra.mat','yeast4-5-1tra.mat','yeast5-5-1tra.mat','yeast6-5-1tra.mat',...
    'abalone19-5-1tra.mat', ...
    'page-blocks0-5-1tra.mat', ...
    'shuttle-c0-vs-c4-5-1tra.mat', ...
    };
if debug_on==1
    %fileName_c = {  'RandomRBF_200.mat',    'kdd.mat'};
    fileName_c = {  'RandomRBF_200.mat'};
% fileName_c = {  'kdd.mat'};
end
solver_str = 'BOW_LM';

mode_update_w = 0; %1; % 0 ; 
%          0: normal mode
%               w_ii = 1/num_P, if y_i==1;  
%               w_ii = 1/num_N, if y_i==-1;  
%          1: active online-weighted mode (proposed by Hualong Yu  TNNLS 30(4),2019)
%               w_ii = num_P/(num_P+num_N) if y_i ==-1; 
%               w_ii = num_N/(num_P+num_N) if y_i ==1; 
if mode_update_w == 0    
    C = 2^(-20); 
else 
    %C = 2^(-30); 
    C = 2^(-20); 
end

% parameters for adding outliers
arg.dataFile = ''; %[dataPath 'abalone19-5-1tra.mat'];
arg.variable_outlier = 'x';
arg.variable_std = 'x';
arg.variable_shuffle = {'x','y'}; % shuffle the order of the data records
%arg.ratio_outlier = 0.1;
if debug_on
    ratio_outlier_v = 0.1 ; %[0.1,0.3];
else
 %   ratio_outlier_v = [0, 0.02, 0.1,0.2];
     ratio_outlier_v = 0.1 ;
end
arg.mean_outlier = 1.0;
arg.variance_outlier = 4.0;


% algorithm parameters
maxSV=6000; % active set capacity
if debug_on==2
    maxSV=300;
end

hp.type = 'rbf'; % gaussian kernel: exp(-gamma * |x_i-x_j|^2) 
nu = 1;

cleanPeriod = 500;
if debug_on==1
    verbose = 3; %1; %2;
    repeat = 1; %1;    
    repeat_large_set = repeat;
elseif debug_on==2
    verbose = 1; %1; %2;
    repeat = 2;    
    repeat_large_set = repeat;   
else %debug_on==0
    verbose = 1; %1; %2;
    repeat = 20; %5; %20;%100; %20; %20;
    repeat_large_set = 10; %5;% 10;%20; %10; % repeat time on large data set
end

block = 1;
para = 400;
% number of nodes, L in the paper;
% L=600 for TextGenerator and TextGenerator_imbalance_2��
% L=400 for other dataset.

% rule=2;
rule=1;

i_rule_addin=0;
gcp_delete = 0; % do not close parpool after calling each method
% parameters to deal with outliers
noiseResilient = 1;
%  1 or 0, whether to detect and deal with outliers;
 
iqr_outlier = 5.0 ; %8.0; % 1.5; 


% get number of samples and features of each dataset
n_dataset = length(fileName_c);
n_sample_v = zeros(1,n_dataset); % number of samples of each dataset
n_feature_v = zeros(1,n_dataset); % number of dimensions of each dataset
for i_data=1:n_dataset
    fileName = fileName_c{i_data};
    dataFile =  [dataPath fileName];
    dt  = load(dataFile,'n_sample_total','n_feature');
    n_sample_v(i_data) = dt.n_sample_total;
    n_feature_v(i_data) = dt.n_feature;
end
% set parfor_v for model_bak.parfor
is_large_dataset_v = n_sample_v.*n_feature_v >= 1E5;
% determine whether it is a large dataset
parfor_v =  is_large_dataset_v & (repeat>20);
% whether employ parfor for repeat multiple calls
timeStamp0 = datestr(now,30);

resultFile_summary_mat = [resultPath 'result_summary_BOW_LM_' timeStamp0  '.mat']; % result file containing summary of the results on various datasets
resultFile_summary_xls= [resultPath 'result_summary_BOW_LM_' timeStamp0  '.xlsx']; % result file containing summary of the results on various datasets

for i_ratio = 1:length(ratio_outlier_v)
    for i_data = 1:length(fileName_c)        
        fprintf(1,'  i_ratio: %d/%d,\t i_data: %d/%d\n',...
                  i_ratio,length(ratio_outlier_v),     i_data,length(fileName_c)   );
        %  1.1 read data and add outliers
        fileName = fileName_c{i_data};
        arg.dataFile =  [dataPath fileName];
        arg.ratio_outlier = ratio_outlier_v(i_ratio);
        [data_st] = getDataRecords(arg);
        data_st.is_outlier_v = false(length(data_st.y),1);
        data_st.is_outlier_v(data_st.index_outlier) = true;         
%         coef_prctile = arg.ratio_outlier * 100; 
        % downsampling
        if flag_downsampling
            data_st   = downsampling(data_st,{'x','y','is_outlier_v'},n_row_down);
        end
        x = data_st.x;
        y = data_st.y;
        is_outlier_v = data_st.is_outlier_v;
        if ~debug_on
            clear('data_st');
        end
        % 1.2 reset parameters        
        % set model_bak          
        model_bak.is_outlier_v = is_outlier_v; 
        model_bak.nu = nu;
        model_bak.maxSV = maxSV;
        model_bak.C = C;
        model_bak.verbose = verbose; %2;
        model_bak.cleanPeriod = cleanPeriod;
        model_bak.repeat = repeat;
        model_bak.block = block;
        model_bak.para = para;
        model_bak.mode_update_w = mode_update_w;
        % set  model_bak.para
        nn = length('TextGenerator');
        if strncmpi('TextGenerator',fileName,nn)
            model_bak.para = 600;
        end
        % set model_bak.gcp_delete
        model_bak.gcp_delete = gcp_delete; % do not close parpool after calling each method
        % set model_bak.noiseResilient
        model_bak.noiseResilient = noiseResilient;
        %  set model_bak.repeat
        model_bak.parfor = parfor_v(i_data);
        if is_large_dataset_v
            model_bak.repeat = repeat_large_set;
        else
            model_bak.repeat = repeat;
        end
        % set  model.iqr_outlier
        model_bak.iqr_outlier = iqr_outlier;  
 
        % 2. online learning
        [acc_t,num_t,seconds_v,num_outlier_t]= k_BWOSELM(x,y,model_bak,rule,i_rule_addin);
 
        % 3. output accuracies
        %%%acc_t = assign_struct(acc_t,'',num_t);
        ratio_str = ['ratio_' num2str(i_ratio)];
        [~,name_str] = fileparts(fileName);
        timeStamp = datestr(now,30);
        resultFile_mat = [resultPath 'result_repeat_' name_str '_' ratio_str '_' timeStamp '.mat'];
        resultFile_xls= [resultPath 'result_repeat_' name_str '_' ratio_str '_' timeStamp '.xlsx'];
        
        
        %  measures of accuracies corresponding to average_acc        
        acc_t = assign_struct(acc_t,'',num_outlier_t);
        
        % assign seconds to acc_t
        seconds_c = num2cell(seconds_v);
        [acc_t(:).seconds ] = deal(seconds_c{:});
        acc_b = struct2table(acc_t);
        Acc =   table2array(acc_b);
        average_acc = mean(Acc,1);
        A_save=[Acc;average_acc ];
        average_acc_measure0_c = fieldnames(acc_t);
        average_acc_measure_c =   average_acc_measure0_c'  ;
        %  measures of accuracies corresponding to average_acc
        
        %csvwrite(resultFile_csv, A_save,1,0);
        % 3.1 save the detailed accuracies on current dataset
        save(resultFile_mat,'num_outlier_t','acc_t','num_t','Acc','average_acc','average_acc_measure_c','timeStamp',...
            'model_bak','arg','rule','i_rule_addin');
        if flag_save_to_xls
            fwritexls(resultFile_xls, '',model_bak,'A1','model_bak'); % save model_bak
            fwritexls(resultFile_xls, '',arg,'A1','arg'); % save arg
            fwritexls(resultFile_xls, '',timeStamp,'A1','sheet1'); % save timeStamp
            fwritexls(resultFile_xls, average_acc_measure_c,A_save,'B2','sheet1'); % save the accuracies
        end
        % 3.2 save the mean accuracies on current dataset to a common specified file
        % 3.2.1 put out to Excel files
        if i_data ==1 &&   flag_save_to_xls
            % put out the title row
            fwritexls(resultFile_summary_xls, '',{'dataset','time stamp'},'A1',  ratio_str);
            fwritexls(resultFile_summary_xls, '',average_acc_measure_c,'C1',  ratio_str);
        end
        if   flag_save_to_xls
            cellA_str = ['A' num2str(i_data+1)];
            cellB_str = ['C' num2str(i_data+1)];
            fwritexls(resultFile_summary_xls, '',{name_str,timeStamp},cellA_str, ratio_str);
            fwritexls(resultFile_summary_xls, '',average_acc,cellB_str, ratio_str);
            % save  model_bak
            %   Note that only model_bak depends on the datasets and i_ratio,
            %       here we only saves one group of the parameters
            fwritexls(resultFile_xls, '',model_bak,'A1','model_bak'); % save model_bak
        end        
        % 3.2.2 putput to mat files
        InfDataSet_c(i_data,1:2,i_ratio) =    {name_str,timeStamp};
        average_acc_array(i_data,:,i_ratio) = average_acc; % the 3-rd dimension is the ratio of outlier
        save(resultFile_summary_mat,'InfDataSet_c','average_acc_array','average_acc_measure_c');
    end    
end
 
if ~isempty(gcp('nocreate'))
    delete(gcp('nocreate'));
end

