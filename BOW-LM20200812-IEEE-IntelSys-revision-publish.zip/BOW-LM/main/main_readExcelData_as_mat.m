% main_readTxTData_as_mat.m
% read data as Mat files
%
% Read the following datasets, and save as Mat files
%
%   RandomRBF-10, RandomRBF-10-imbalance-2, RandomRBF-200, RandomRBF-200-imbalance-2
%
%   TextGenerator, TextGenerator-imbalance-2,
%
%   STAG, STAG-imbalance-2
  

clc
clear

dataPath_Mat = 'D:\data_BOW_LM\data_mat\';
dataPath = 'D:\data_BOW_LM\MOA\';
% mkdir
if ~exist(dataPath_Mat,'dir')
    mkdir(dataPath_Mat);
end

fileName_c = {'RandomRBF_10.csv','RandomRBF_10_imbalance_1.csv','RandomRBF_10_imbalance_2.csv',...
   'RandomRBF_200.csv','RandomRBF_200_imbalance_1.csv','RandomRBF_200_imbalance_2.csv',...
   'TextGenerator.csv','TextGenerator_imbalance_1.csv','TextGenerator_imbalance_2.csv',...
   'STAG.csv', 'STAG_imbalance_1.csv','STAG_imbalance_2.csv'}; 

for ii = 1:length(fileName_c)
    fileName = [dataPath fileName_c{ii}];
    [num]=xlsread(fileName);
    num(1,:)=[];
    
    [n,m]=size(num);
    x=num(:, 1:m-1);
    y=num(:, m);
    clear num;
    
    % save into mat files
    n_sample_total = length(y);
    n_positive = nnz(y==1);
    n_negative = nnz(y==-1);
    n_feature = m-1;
    timeStamp = datestr(now,31);
    [~,fileName_bare,ext] = fileparts(fileName);
    save([dataPath_Mat fileName_bare '.mat'],'x','y','n_sample_total','n_feature','n_positive','n_negative','timeStamp');
    fwritef(1,'ii',ii,'','',fileName_c{ii},'','n_sample_total',n_sample_total,'','n_positive',n_positive,'');
end







