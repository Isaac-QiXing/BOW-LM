% main_readTxTData_as_mat.m
% read data as Mat files
%
% Read the following datasets, and save as Mat files
%
%   yeast1, yeast3, yeast4, yeast5, yeast6,
%
%   shuttle-C0-vs-C4, abalone19,   page-blocks0,


clc
clear

dataPath_Mat = 'D:\data_BOW_LM\data_mat\';

% mkdir
if ~exist(dataPath_Mat,'dir')
    mkdir(dataPath_Mat);
end

i_group = 2; % one group each time 
% =============================
switch i_group
    case 1 
        % group 1, yeast dataset
        dataPath = 'D:\data_BOW_LM\data4.3\';
        fileName_c = {'yeast1-5-1tra.dat','yeast3-5-1tra.dat','yeast4-5-1tra.dat','yeast5-5-1tra.dat','yeast6-5-1tra.dat',...
            'yeast1-5-1tst.dat','yeast3-5-1tst.dat','yeast4-5-1tst.dat','yeast5-5-1tst.dat','yeast6-5-1tst.dat'};

        n_headerlines_v = 13*ones(size(fileName_1_c));
        n_feature_v = [8,8,8,8,8,...
            8,8,8,8,8]; % total number of features (excluding the label)

        ind_label_v = n_feature_v +1; % index of the label
        value_label_positive_c = {'positive'};  %  values of the positive label
        ind_string_c = num2cell(n_feature_v +1); % indices of the string features
        Delimiter = ',';
    case 2 % group 2 
        % group 2 : abalone19,   page-blocks0, shuttle-C0-vs-C4
        dataPath = 'D:\data_BOW_LM\data4.3\';
        fileName_c = {'abalone19-5-1tra.dat','abalone19-5-1tst.dat',...
            'page-blocks0-5-1tra.dat','page-blocks0-5-1tst.dat',...
            'shuttle-c0-vs-c4-5-1tra.dat','shuttle-c0-vs-c4-5-1tst.dat'};
        n_headerlines_v = [13,13, 15,15,14,14];
        n_feature_v = [8,8,...
            10,10,...
            9,9]; % total number of features (excluding the label)

        ind_label_v = n_feature_v +1; % index of the label
        value_label_positive_c = {'positive'};  %  values of the positive label
        ind_string_c = {[1,9],[1,9],...
            11,11, ...
            10,10}; % indices of the string features
        Delimiter = ',';
      
end
 
    
    for ii = 1:length(fileName_c)
        fileName = [dataPath fileName_c{ii}];
        n_headerlines = n_headerlines_v(ii);
        n_feature = n_feature_v(ii);
        ind_label = ind_label_v(ii);
        ind_string = ind_string_c{ii};
        ind_numeric = setdiff(1:n_feature+1,ind_string);
        format_str = repmat('%f',[1  n_feature+1]);
        format_str(  2*ind_string) = 's';
        % read data
        fid=fopen(fileName,'r');
        a=textscan(fid, format_str,'HeaderLines',n_headerlines,'Delimiter',Delimiter);
        fclose(fid);
        
        % numeric features
        x = cell2mat(a(ind_numeric));
        % labels
        y_0_1  =   strcmpi(value_label_positive_c{1},a{ind_label});
        y = ones(size(y_0_1));
        y(y_0_1) = -1;
        
        % save into mat files
        n_sample_total = length(y);
        n_positive = nnz(y==1);
        n_negative = nnz(y==-1);
        timeStamp = datestr(now,31);
        [~,fileName_bare,ext] = fileparts(fileName);
        save([dataPath_Mat fileName_bare '.mat'],'x','y','n_sample_total','n_feature','n_positive','n_negative','timeStamp');
        fwritef(1,'ii',ii,'','',fileName_c{ii},'','n_sample_total',n_sample_total,'','n_positive',n_positive,'');
    end
    
    
 




