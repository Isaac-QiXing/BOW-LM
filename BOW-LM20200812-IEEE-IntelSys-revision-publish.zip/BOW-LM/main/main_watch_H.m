function main_watch_H()
% look at the matrix of H
%  * versions:
%   2020.3.9 compare with the distance of the original data samples

clear
clc


% 0. load data

% 0.1 parameters

dataPath = 'D:\data_BOW_LM\data_mat\';
resultPath = 'D:\result_BOW_LM\';
% fileName_c = {      %'RandomRBF_10.mat',...
%     'RandomRBF_200.mat',...   % 'RandomRBF_200_imbalance_2.mat',...   % 'TextGenerator.mat',... 
%     'yeast1-5-1tra.mat',...
%     'page-blocks0-5-1tra.mat', ...
%     'abalone19-5-1tra.mat', ...
%     'shuttle-c0-vs-c4-5-1tra.mat',
%     };
fileName_c = {     
    'RandomRBF_10.mat',...          
   'page-blocks0-5-1tra.mat', ...
   'abalone19-5-1tra.mat', ...
    };
% fileName_c = {...
%     'RandomRBF_10.mat', 'RandomRBF_10_imbalance_2.mat',...
%     'RandomRBF_200.mat', 'RandomRBF_200_imbalance_2.mat',...
%     'TextGenerator.mat', 'TextGenerator_imbalance_2.mat',...
%     'STAG.mat',  'STAG_imbalance_2.mat',...
%     'kdd.mat',...
%     'yeast1-5-1tra.mat','yeast3-5-1tra.mat','yeast4-5-1tra.mat','yeast5-5-1tra.mat','yeast6-5-1tra.mat',...
%     'abalone19-5-1tra.mat', ...
%     'page-blocks0-5-1tra.mat', ...
%     'shuttle-c0-vs-c4-5-1tra.mat', ...
%     };
% fileName_c = {   'TextGenerator.mat'};
%fileName = 'RandomRBF_200.mat';
%dataset = 'RandomRBF_200';

arg.variable_outlier = 'x';
arg.variable_std = 'x';
arg.variable_shuffle = {'x','y'}; % shuffle the order of the data records


arg.ratio_outlier = 0.1 ;

% arg.mean_outlier = 2.0; %1.0;
% arg.variance_outlier = 16.0; %4.0;
arg.mean_outlier = 1.0; %1.0;
arg.variance_outlier = 4.0; %4.0;

arg.dim = 2;
% arg.iqr = 500;
arg.iqr = 5;
arg.dist = 'norm1';

n_data = length(fileName_c);
inf_outlier_t = struct(); % struct of outlier numbers


flag_draw_figure = 1;
flag_downsampling = 1;
flag_compare_original_x = 1; % whether to compare with the original data space

n_downsampling = 10000;
n_row_down_H = 6000;
if flag_compare_original_x
    n_watch = n_data * 2;
else
    n_watch = n_data;  % n_watch: number of cheching the datasets for outliers
end

i_watch = 0;
for i_data = 1:n_data
    fwritef(1,'i_data',i_data,'');
    fileName = fileName_c{i_data};
    arg.dataFile =  [dataPath fileName];
    [data_st] = getDataRecords(arg);
    
    % 0.2 downsampling
    
    % % %     [n_sample,InputDim] = size(data_st.x);
    data_st.is_outlier = false(data_st.n_sample_total,1);
    data_st.is_outlier(data_st.index_outlier) = 1;
    
    if flag_downsampling && data_st.n_sample_total > n_downsampling
        data_st   = downsampling(data_st,{'x','y','is_outlier'},n_downsampling);
        %%%x = data_st2.x;
        %%%y = data_st2.y;
    end
    
    is_outlier_true = data_st.is_outlier;
    [n_sample,InputDim] = size(data_st.x);
    
    % 1. watch outliers based on the
    if flag_compare_original_x
        watchOutlier(data_st.x);
    end
    
    
    % 2. watch outliers based on the matrix H
    
    % 2.1. calculate matrix H
    para = 400;
    % para = 10; %400;
    nHiddenNeurons = para;
    
    model_p.IW = rand(nHiddenNeurons,InputDim)*2-1;
    model_p.Bias= rand(1,nHiddenNeurons)*2-1;
    
    H= SigActFun(data_st.x,model_p.IW ,model_p.Bias);
    
    H= 1./H ;  % transformation , a kep operation
    
    % 2.2. watch outliers based on the matrix H
    watchOutlier(H);
    
end

if flag_draw_figure
    fileName = ['distance_H_4_dataset_0309'];
    savefig(h,[fileName '.fig']);
    saveas(h,[fileName '.png']);
end

    function watchOutlier(H)
        i_watch = i_watch +1;
        % 1. find outliers
        % calculate the center
        if n_row_down_H< n_sample
            H_downsample = H(1:n_row_down_H,:);
        else
            H_downsample = H;
        end
        
        [ H_center, thresh_outlier,dist_v] = getThresh_outlier(H_downsample,arg);
        %[ H_center, thresh_outlier,dist_v] = getThresh_outlier(H,arg);
        fwritef(1,'thresh_outlier',thresh_outlier,'');
        % find outliers
        arg.center = H_center;
        arg.thresh = thresh_outlier;
        [is_outlier_v,dist_v] = isOutlier(H,arg);
        
        inf_outlier_t(i_watch).n_outlier_identify =  nnz(is_outlier_v);
        inf_outlier_t(i_watch).n_outlier_identify_correct =  nnz(is_outlier_v & is_outlier_true);
        inf_outlier_t(i_watch).n_outlier_total =  nnz(is_outlier_true);
        
        % 2. draw the figure
        if flag_draw_figure
            
            d_normal = dist_v(~is_outlier_true);
            d_outlier = dist_v(is_outlier_true);
            dist_thresh_draw = prctile(d_outlier,33); % median(d_outlier);
            if  flag_compare_original_x && mod(i_watch,2)==1            	
                dist_thresh_draw = max(dist_thresh_draw,thresh_outlier * 3);
            else
                dist_thresh_draw = max(dist_thresh_draw,thresh_outlier * 50);
            end
            
            n_col  = 2;
            n_row = ceil(n_watch/n_col);
            subplot(n_row,n_col,i_watch);
            [h,n_outlier] = plotNumer(d_outlier,'.r',d_normal,'.b');
%              [h,n_outlier] = plotNumer(d_normal,'.b',d_outlier,'.r');
            set(gca,'XLim',[0,dist_thresh_draw]);
            title_str = ['(' char('a' + i_watch - 1) ')']; 
            title(title_str);
        end
        fileName_mat = 'result_watch_H_0309.mat';
        save(fileName_mat,'inf_outlier_t','arg');
    end

end


