% stat_outlier_temp2020_02_29.m

load('temp20190619_repeat1.mat');
aa = iteInf.prob_outlier;

n = length(aa);
ind_outlier = data_st.index_outlier;
 
is_outlier_v = ismember(1:n,ind_outlier);
is_outlier_v = columnVec(is_outlier_v);
is_normal_v = ~is_outlier_v;

nnz(aa)
nnz(is_outlier_v & aa)
nnz(is_outlier_v)
